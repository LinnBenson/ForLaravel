<?php

namespace App\Plugins\TikHubMedia\Support;
use Illuminate\Support\Facades\Http;

class ShareService {
    /**
     * 解析入口
     * @param string $share 分享链接
     * @return bool|array 解析结果
     */
    public static function shareToLinks( string $share ): bool|array {
        // 支持的域名列表
        $domains = [
            'tiktok.com' => 'getLinkByTiktok', // TikTok
            'douyin.com' => 'getLinkByDouyin', // 抖音
            'instagram.com' => 'getLinkByInstagram', // Instagram
            'twitter.com' => 'getLinkByX', // Twitter
            'x.com' => 'getLinkByX', // X
        ];
        foreach ( $domains as $domain => $method ) {
            if ( str_contains( $share, $domain ) ) {
                return self::{$method}( $share );
            }
        }
        // 未知的分享链接
        return false;
    }
    // 媒体链接解析入口: Tiktok
    private static function getLinkByTiktok( string $share ): bool|array {
        return self::getLinkByDouyin( $share );
    }
    // 媒体链接解析入口: 抖音
    private static function getLinkByDouyin( string $share ): bool|array {
        $res = Http::acceptJson()
            ->asJson()
            ->connectTimeout( 5 )
            ->timeout( 15 )
            ->withToken( plugin( 'TikHubMedia' )->config( 'api' ) )
            ->get( plugin( 'TikHubMedia' )->config( 'host' )."/api/v1/hybrid/video_data", [
                'url' => $share
            ]);
        if ( $res->status() !== 200 ) { return false; }
        $res = $res->json();
        if ( empty( $res['code'] ) || $res['code'] !== 200 || empty( $res['data'] ) || empty( $res['data'] ) ) { return false; }
        $data = $res['data'] ?? []; $result = []; $type = null;
        if ( isset( $data['images'] ) && is_array( $data['images'] ) && !empty( $data['images'] ) && is_array( $data['images'] ) ) {
            $type = 'photo';
            foreach( $data['images'] as $image ) {
                if ( isset( $image['url_list'] ) && is_array( $image['url_list'] ) && !empty( $image['url_list'] ) ) {
                    $url = $image['url_list'][count( $image['url_list'] ) - 1] ?? null;
                    if ( $url ) { $result[] = [ 'type' => $type, 'url' => $url ]; }
                }
            }
        }else if ( isset( $data['video'] ) && is_array( $data['video'] ) && !empty( $data['video']['play_addr'] ) ) {
            $type = 'video';
            $media = $data['video']['play_addr'] ?? [];
            $url = $media['url_list'][0] ?? null;
            if ( $url ) { $result[] = [ 'type' => $type, 'url' => $url ]; }
        }
        return $result;
    }
    // 媒体链接解析入口: Instagram
    private static function getLinkByInstagram( string $share ): bool|array {
        $res = Http::acceptJson()
            ->asJson()
            ->connectTimeout( 5 )
            ->timeout( 15 )
            ->withToken( plugin( 'TikHubMedia' )->config( 'api' ) )
            ->get( plugin( 'TikHubMedia' )->config( 'host' )."/api/v1/instagram/v1/fetch_post_by_url_v2", [
                'post_url' => $share
            ]);
        if ( $res->status() !== 200 ) { return false; }
        $res = $res->json();
        if ( empty( $res['code'] ) || $res['code'] !== 200 || empty( $res['data'] ) || empty( $res['data'] ) ) { return false; }
        $media = $res['data']['data']['medias'] ?? []; $result = [];
        foreach ( $media as $item ) {
            if ( !is_array( $item ) ) { continue; }
            $type = strtolower( $item['type'] ?? 'unknown' );
            if ( $type === 'image' ) { $type = 'photo'; }
            $url = $item['link'] ?? null;
            if ( $url ) { $result[] = [ 'type' => $type, 'url' => $url ]; }
        }
        return $result;
    }
    // 媒体链接解析入口: X/Twitter
    private static function getLinkByX( string $share ): bool|array {
        $tweet_id = null;
        if ( preg_match( '/\/status\/(\d+)/', $share, $matches ) ) { $tweet_id = $matches[1]; }
        if ( !$tweet_id ) { return false; }
        $res = Http::acceptJson()
            ->asJson()
            ->connectTimeout( 5 )
            ->timeout( 15 )
            ->withToken( plugin( 'TikHubMedia' )->config( 'api' ) )
            ->get( plugin( 'TikHubMedia' )->config( 'host' )."/api/v1/twitter/web/fetch_tweet_detail", [
                'tweet_id' => $tweet_id
            ]);
        if ( $res->status() !== 200 ) { return false; }
        $res = $res->json();
        if ( empty( $res['code'] ) || $res['code'] !== 200 || empty( $res['data'] ) || empty( $res['data'] ) ) { return false; }
        $media = $res['data']['media'] ?? []; $result = [];
        foreach ( $media as $type => $items ) {
            if ( !is_array( $items ) ) { continue; }
            $url = null;
            switch ( $type ) {
                case 'photo':
                    foreach ( $items as $item ) {
                        $url = $item['media_url_https'] ?? null;
                        if ( $url ) { $result[] = [ 'type' => 'photo', 'url' => $url ]; }
                    }
                    break;
                case 'video':
                    foreach ( $items as $item ) {
                        $variants = isset( $item['variants'] ) && is_array( $item['variants'] ) ? $item['variants'] : [];
                        $url = $variants[count( $variants ) - 1]['url'] ?? null;
                        if ( $url ) { $result[] = [ 'type' => 'video', 'url' => $url ]; }
                    }
                    break;

                default: break;
            }
        }
        return $result;
    }
}