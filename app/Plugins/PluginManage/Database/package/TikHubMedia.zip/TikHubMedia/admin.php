{{-- TikHub 媒体解析管理页面 --}}
<div
    class="tikhub-media-admin"
    x-data="{
        share: '',
        running: false,
        results: [],
        message: '',
        copied: null,
        copyFallback( value ) {
            const input = document.createElement( 'textarea' );
            input.value = value;
            input.readOnly = true;
            input.style.position = 'fixed';
            input.style.opacity = '0';
            document.body.appendChild( input );
            input.select();
            const copied = document.execCommand( 'copy' );
            input.remove();
            return copied;
        },
        async copy( value, index ) {
            let copied = false;
            if ( window.isSecureContext && window.navigator.clipboard ) {
                try {
                    await window.navigator.clipboard.writeText( value );
                    copied = true;
                }catch ( error ) {}
            }
            if ( !copied ) { copied = this.copyFallback( value ); }
            if ( !copied ) { return; }
            this.copied = index;
            window.setTimeout( () => this.copied = null, 1800 );
        },
        async parse() {
            const share = this.share.trim();
            if ( this.running ) { return; }
            if ( share === '' ) {
                this.message = '请先填写分享链接。';
                this.results = [];
                return;
            }
            this.running = true;
            this.message = '';
            this.results = [];
            try {
                const response = await fetch( '{{ route( 'plugins.tik-hub-media.parse' ) }}', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': this.$refs.token.value,
                    },
                    body: JSON.stringify( { share } ),
                } );
                const data = await response.json();
                if ( !response.ok || data.status !== 'success' ) {
                    this.message = data.data?.message || data.message || '解析失败，请检查分享链接。';
                    return;
                }
                this.results = Array.isArray( data.data ) ? data.data : [];
                if ( this.results.length === 0 ) { this.message = '没有找到可用的媒体链接。'; }
            }catch ( error ) {
                this.message = '请求失败，请检查网络连接后重试。';
            }finally {
                this.running = false;
            }
        },
    }"
>
    <input x-ref="token" type="hidden" value="{{ csrf_token() }}">

    <section class="tikhub-media-card">
        <div class="tikhub-media-intro">
            <div>
                <h2>粘贴链接，一键解析</h2>
                <p>从支持的平台提取原始图片或视频地址。</p>
            </div>
            <div class="tikhub-media-platforms" aria-label="支持的平台">
                <span>TikTok</span>
                <span>抖音</span>
                <span>Instagram</span>
                <span>X</span>
            </div>
        </div>

        <div class="tikhub-media-form">
            <div class="tikhub-media-label-row">
                <label for="tikhub-media-share">分享链接</label>
                <span>支持直接粘贴完整分享文案</span>
            </div>
            <div class="tikhub-media-input-box">
                <textarea
                    id="tikhub-media-share"
                    x-model="share"
                    rows="4"
                    maxlength="5000"
                    placeholder="在这里粘贴分享链接…"
                    x-bind:disabled="running"
                ></textarea>
                <div class="tikhub-media-actions">
                    <span>下载地址具有时效性，解析后请及时保存</span>
                    <button type="button" x-on:click="parse()" x-bind:disabled="running || share.trim() === ''">
                        <span x-show="running" class="tikhub-media-spinner"></span>
                        <span x-text="running ? '正在解析' : '解析链接'">解析链接</span>
                        <svg x-show="!running" viewBox="0 0 20 20" fill="none" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m7.5 5 5 5-5 5" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </section>

    <div class="tikhub-media-message" x-cloak x-show="message !== ''" x-text="message"></div>

    <section class="tikhub-media-results" x-cloak x-show="results.length > 0">
        <header>
            <h3>解析结果</h3>
            <span x-text="`${results.length} 个媒体文件`"></span>
        </header>
        <div class="tikhub-media-result-list">
            <template x-for="( item, index ) in results" x-bind:key="`${item.url}-${index}`">
                <article class="tikhub-media-result">
                    <div class="tikhub-media-result-info">
                        <span class="tikhub-media-type" x-text="item.type === 'video' ? '视频' : ( item.type === 'photo' ? '图片' : '媒体' )"></span>
                        <strong x-text="`媒体 ${index + 1}`"></strong>
                    </div>
                    <input type="text" x-bind:value="item.url" readonly aria-label="媒体下载链接">
                    <div class="tikhub-media-result-actions">
                        <button class="is-secondary" type="button" x-on:click="copy( item.url, index )">
                            <span x-text="copied === index ? '已复制' : '复制链接'">复制链接</span>
                        </button>
                        <a x-bind:href="item.url" target="_blank" rel="noopener noreferrer">打开链接</a>
                    </div>
                </article>
            </template>
        </div>
    </section>
</div>

<style>
    /* TikHub 媒体解析管理页面 */
    .tikhub-media-admin { display: flex; width: 100%; flex-direction: column; gap: 1rem; color: var(--gray-700); }
    .dark .tikhub-media-admin { color: var(--gray-300); }
    .tikhub-media-card,
    .tikhub-media-results { padding: 1.35rem; border: 1px solid var(--gray-200); border-radius: 0.85rem; background: white; }
    .dark .tikhub-media-card,
    .dark .tikhub-media-results { border-color: var(--gray-700); background: var(--gray-900); }
    .tikhub-media-intro { display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; }
    .tikhub-media-intro h2 { color: var(--gray-950); font-size: 1.1rem; font-weight: 700; letter-spacing: -0.015em; }
    .dark .tikhub-media-intro h2 { color: white; }
    .tikhub-media-intro p { margin-top: 0.3rem; color: var(--gray-500); font-size: 0.8rem; }
    .tikhub-media-platforms { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.35rem; }
    .tikhub-media-platforms span { padding: 0.25rem 0.5rem; border: 1px solid color-mix(in srgb, var(--primary-500) 16%, transparent); border-radius: 9999px; background: color-mix(in srgb, var(--primary-500) 7%, transparent); color: var(--primary-700); font-size: 0.68rem; font-weight: 650; }
    .dark .tikhub-media-platforms span { color: var(--primary-400); }
    .tikhub-media-admin .tikhub-media-form { display: flex; width: 100%; margin-top: 1.25rem; flex-direction: column; align-items: stretch; gap: 0.55rem; }
    .tikhub-media-label-row { display: flex; width: 100%; align-items: center; justify-content: space-between; gap: 1rem; }
    .tikhub-media-label-row label { color: var(--gray-800); font-size: 0.8rem; font-weight: 650; }
    .tikhub-media-label-row span { color: var(--gray-500); font-size: 0.7rem; }
    .dark .tikhub-media-form label { color: var(--gray-200); }
    .tikhub-media-input-box { display: flex; width: 100%; overflow: hidden; border: 1px solid var(--gray-300); border-radius: 0.75rem; background: var(--gray-50); flex-direction: column; transition: border-color 0.15s, box-shadow 0.15s; }
    .dark .tikhub-media-input-box { border-color: var(--gray-700); background: var(--gray-950); }
    .tikhub-media-input-box:focus-within { border-color: var(--primary-500); box-shadow: 0 0 0 3px color-mix(in srgb, var(--primary-500) 12%, transparent); }
    .tikhub-media-admin .tikhub-media-input-box textarea { display: block !important; width: 100% !important; min-width: 100% !important; min-height: 7.25rem !important; resize: vertical; padding: 0.85rem 0.95rem !important; border: 0 !important; border-radius: 0 !important; outline: none !important; background: transparent !important; color: var(--gray-900); font-size: 0.84rem; line-height: 1.55; box-shadow: none !important; }
    .dark .tikhub-media-admin .tikhub-media-input-box textarea { color: var(--gray-100); }
    .tikhub-media-actions { display: flex; width: 100%; padding: 0.65rem; border-top: 1px solid var(--gray-200); align-items: center; justify-content: space-between; gap: 1rem; }
    .dark .tikhub-media-actions { border-color: var(--gray-800); }
    .tikhub-media-actions > span { color: var(--gray-500); font-size: 0.72rem; }
    .tikhub-media-actions button,
    .tikhub-media-result-actions button,
    .tikhub-media-result-actions a { display: inline-flex; min-height: 2.35rem; padding: 0.55rem 0.9rem; border: 0; border-radius: 0.6rem; background: var(--primary-600); color: white; align-items: center; justify-content: center; gap: 0.45rem; font-size: 0.8rem; font-weight: 650; text-decoration: none; cursor: pointer; }
    .tikhub-media-actions button:disabled { cursor: wait; opacity: 0.6; }
    .tikhub-media-actions button svg { width: 0.9rem; height: 0.9rem; }
    .tikhub-media-spinner { width: 0.9rem; height: 0.9rem; border: 2px solid rgba(255, 255, 255, 0.4); border-top-color: white; border-radius: 50%; animation: tikhub-media-spin 0.7s linear infinite; }
    .tikhub-media-message { padding: 0.75rem 0.9rem; border-radius: 0.65rem; background: color-mix(in srgb, var(--danger-500) 12%, transparent); color: var(--danger-700); font-size: 0.82rem; }
    .dark .tikhub-media-message { color: var(--danger-400); }
    .tikhub-media-results > header { display: flex; margin-bottom: 0.85rem; align-items: center; justify-content: space-between; gap: 1rem; }
    .tikhub-media-results h3 { color: var(--gray-950); font-size: 0.95rem; font-weight: 700; }
    .dark .tikhub-media-results h3 { color: white; }
    .tikhub-media-results > header span { color: var(--gray-500); font-size: 0.75rem; }
    .tikhub-media-result-list { display: flex; flex-direction: column; gap: 0.75rem; }
    .tikhub-media-result { display: grid; padding: 0.8rem; border: 1px solid var(--gray-200); border-radius: 0.75rem; background: var(--gray-50); grid-template-columns: auto minmax(0, 1fr) auto; align-items: center; gap: 0.75rem; }
    .dark .tikhub-media-result { border-color: var(--gray-700); background: var(--gray-950); }
    .tikhub-media-result-info { display: flex; align-items: center; gap: 0.45rem; white-space: nowrap; }
    .tikhub-media-result-info strong { color: var(--gray-800); font-size: 0.8rem; }
    .dark .tikhub-media-result-info strong { color: var(--gray-200); }
    .tikhub-media-type { padding: 0.2rem 0.4rem; border-radius: 9999px; background: color-mix(in srgb, var(--primary-500) 13%, transparent); color: var(--primary-700); font-size: 0.68rem; font-weight: 700; }
    .tikhub-media-result input { width: 100%; min-width: 0; padding: 0.5rem 0.65rem; border: 1px solid var(--gray-300); border-radius: 0.5rem; background: white; color: var(--gray-700); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.72rem; }
    .dark .tikhub-media-result input { border-color: var(--gray-700); background: var(--gray-900); color: var(--gray-300); }
    .tikhub-media-result-actions { display: flex; gap: 0.45rem; }
    .tikhub-media-result-actions button,
    .tikhub-media-result-actions a { min-height: 2rem; padding: 0.4rem 0.65rem; font-size: 0.72rem; }
    .tikhub-media-result-actions button.is-secondary { border: 1px solid var(--gray-300); background: white; color: var(--gray-700); }
    .dark .tikhub-media-result-actions button.is-secondary { border-color: var(--gray-600); background: var(--gray-800); color: var(--gray-200); }
    @keyframes tikhub-media-spin { to { transform: rotate(360deg); } }
    @media (max-width: 768px) {
        .tikhub-media-result { grid-template-columns: 1fr; }
        .tikhub-media-result-actions { width: 100%; }
        .tikhub-media-result-actions button,
        .tikhub-media-result-actions a { flex: 1; }
    }
    @media (max-width: 640px) {
        .tikhub-media-card,
        .tikhub-media-results { padding: 1rem; }
        .tikhub-media-intro { flex-direction: column; }
        .tikhub-media-platforms { justify-content: flex-start; }
        .tikhub-media-label-row span { display: none; }
        .tikhub-media-actions { align-items: stretch; flex-direction: column; }
        .tikhub-media-actions button { width: 100%; }
    }
</style>
