<?php
return [
    'entrance' => 'tik-hub-media',
    'token' => '123456',
    'host' => 'https://api.tikhub.io',
    'api' => 'nMwcPN4y5nmvmFCtMq+t/TTnETuIYcl6zxfzmkqsesCo0kW4NHe8Vj2AGQ=='
];