<?php

namespace App\Plugins\TikHubMedia\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Throwable;

class ShareController extends Controller {
    /**
     * 解析入口
     * @param Request $request 请求对象
     * @return JsonResponse JSON 响应
     */
    public function index( Request $request ): JsonResponse {
        // 验证 Token
        $token = $request->input( 'token', null );
        if ( !$token || $token !== plugin( 'TikHubMedia' )->config( 'token' ) ) {
            return echoJson( 3, ['base.error.403'], 403 );
        }
        // 获取分享链接
        $share = $request->input( 'share', null );
        if ( !$share || !is_string( $share ) || $share === '' ) {
            return echoJson( 2, ['base.error.null'], 400 );
        }
        // 解析分享链接
        $result = plugin( 'TikHubMedia' )->shareToLinks( $share );
        if ( !$result ) {
            return echoJson( 2, ['base.error.prohibit'], 400 );
        }
        $result = is_array( $result ) ? $result : [];
        $rid = md5( uuid() );
        foreach ( $result as $key => $item ) {
            $result[$key]['filename'] = "{$rid}_{$key}";
        }
        return echoJson( 0, $result );
    }

    /**
     * 后台解析分享链接
     * 仅供已登录且具备后台权限的插件管理页面调用。
     * @param Request $request 请求对象
     * @return JsonResponse JSON 响应
     */
    public function admin( Request $request ): JsonResponse {
        $validated = $request->validate([
            'share' => ['required', 'string', 'max:5000'],
        ]);
        try {
            $result = plugin( 'TikHubMedia' )->shareToLinks( trim( $validated['share'] ) );
        }catch ( Throwable $exception ) {
            report( $exception );
            return echoJson( 2, ['message' => '解析服务暂时不可用，请稍后重试。'], 502 );
        }
        if ( !$result ) {
            return echoJson( 2, ['message' => '未获取到媒体链接，请检查分享链接是否有效或受支持。'], 422 );
        }
        return echoJson( 0, $result );
    }
}
