<?php

use App\Providers\PluginProvider;
use App\Filament\Concerns\AdminLevel;
use App\Plugins\TikHubMedia\Support\ShareService;
use App\Plugins\TikHubMedia\Controllers\ShareController;
use Illuminate\Support\Facades\Route;

/**
 * TikHub 解析工具
 * 借助 tikhub.io 解析各类媒体下载链接。
 */
return new class extends PluginProvider {
    /**
     * 插件信息
     */
    public function __construct() {
        $this->name = 'TikHub 解析工具';
        $this->description = '借助 tikhub.io 解析各类媒体下载链接。';
        $this->version = '1.0.0';
        $this->author = 'Todu.io';
    }

    /**
     * 注册插件 Hook。
     * @return void
     */
    public function boot(): void {
        $this->hook( 'APP_SERVICE_PROVIDER_BOOT', 'register' );
    }

    /**
     * 注册插件管理路由。
     * @return void
     */
    public function register(): void {
        Route::any( $this->config( 'entrance' ), [ShareController::class, 'index'] )->name( 'plugin.tik-hub-media.index' );
        Route::post( '/'.config( 'app.admin_path' ).'/plugins/tik-hub-media/parse', [ShareController::class, 'admin'] )
            ->middleware( AdminLevel::class )
            ->name( 'plugins.tik-hub-media.parse' );
    }

    /**
     * 解析入口
     * @param string $share 分享链接
     * @return bool|array 解析结果
     */
    public function shareToLinks( string $share ): bool|array { return ShareService::shareToLinks( $share ); }
};
