# NodeSubscription

> 支持 `ss`、`ssr`、`vmess`、`vless`、`trojan`、`http`、`https`。

## config 写法
```
{
    "uuid": "11111111-1111-4111-8111-111111111111",
    "alterId": 0,
    "password": "password",
    "cipher": "auto",
    "network": "ws",
    "tls": "tls",
    "server-name": "example.com",
    "skip-cert-verify": false,
    "client-fingerprint": "chrome",
    "udp": true
    ...
}
```

公共字段说明：
| 字段 | 类型 | 用途 |
| --- | --- | --- |
| `uuid` | string | VMess、VLESS 用户 ID |
| `password` | string | SS、SSR、Trojan、HTTP(S) 密码 |
| `username` | string | HTTP(S) 用户名 |
| `cipher` | string | SS/SSR 加密方式；VMess 可用 `auto` |
| `network` | string | 传输类型：`tcp`、`ws`、`grpc`、`h2`、`http`、`kcp`、`quic` |
| `tls` | bool/string | `true` 或 `"tls"` 启用 TLS，VLESS Reality 使用 `"reality"` |
| `alterId` | int | VMess 额外 ID，通常填写 `0` |
| `server-name` | string | TLS SNI；Trojan 会自动映射为 SNI |
| `skip-cert-verify` | bool | 是否跳过证书验证 |
| `client-fingerprint` | string | 客户端 TLS 指纹，例如 `chrome` |
| `udp` | bool | Clash 是否启用 UDP |
| `alpn` | array/string | TLS ALPN，例如 `["h2", "http/1.1"]` |

## 传输方式
### WebSocket
```json
{
    "network": "ws",
    "ws-opts": {
        "path": "/proxy",
        "headers": {
            "host": "example.com"
        },
        "early-data-header-name": "Sec-WebSocket-Protocol"
    }
}
```

### gRPC
```json
{
    "network": "grpc",
    "grpc-opts": {
        "grpc-service-name": "service-name"
    }
}
```

### HTTP/2
```json
{
    "network": "h2",
    "h2-opts": {
        "host": ["example.com"],
        "path": "/proxy"
    }
}
```

未填写 `network` 时默认使用 `tcp`。

## 常用可选字段
| 字段 | 说明 |
| --- | --- |
| `udp` | 是否启用 UDP |
| `tls` | 填写 `tls` 或 `reality` |
| `server-name` | TLS 使用的域名，也就是 SNI |
| `skip-cert-verify` | 是否忽略证书错误 |
| `client-fingerprint` | 客户端指纹，例如 `chrome` |
| `alpn` | ALPN 列表，例如 `["h2", "http/1.1"]` |
| `flow` | VLESS 流控，例如 `xtls-rprx-vision` |

## 高级扩展
`clash` 可以补充或覆盖 Clash 节点字段：
```json
{
    "uuid": "11111111-1111-4111-8111-111111111111",
    "clash": {
        "packet-encoding": "xudp"
    }
}
```

`uri-query` 可以补充或覆盖 VLESS、Trojan 分享链接参数：
```json
{
    "uuid": "11111111-1111-4111-8111-111111111111",
    "uri-query": {
        "encryption": "none"
    }
}
```
