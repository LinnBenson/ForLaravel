<?php

return [
    'entrance' => 'node-subscription',
    'title' => setting( 'app.title' ),
    'subtitle' => '{{title}} For {{username}}',
    'addItem' => [
        'support' => true,
        'update' => true,
    ],
    'view' => [
        'background' => '/assets/images/Default.jpg'
    ]
];