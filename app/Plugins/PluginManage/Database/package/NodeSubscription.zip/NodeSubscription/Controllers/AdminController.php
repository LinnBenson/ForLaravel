<?php

namespace App\Plugins\NodeSubscription\Controllers;

use App\Http\Controllers\Controller;
use App\Plugins\NodeSubscription\Models\Node;
use App\Plugins\NodeSubscription\Models\Subscription;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * AdminController
 * 代理订阅工具数据表管理控制器。
 * @package App\Plugins\NodeSubscription\Controllers
 */
class AdminController extends Controller {
    /**
     * 重建插件的所有数据表。
     * 删除现有数据表及数据后重新创建当前版本结构。
     * @return JsonResponse JSON 响应
     */
    public function rebuild(): JsonResponse {
        try {
            DB::connection( Node::CONNECTION )->transaction( function (): void {
                Subscription::down();
                Node::down();
                Node::up();
                Subscription::up();
            } );
            return echoJson( true, ['message' => '所有数据表重建成功。'] );
        }catch ( Throwable $throwable ) {
            report( $throwable );
            return echoJson( false, ['message' => '数据表重建失败，请查看系统日志。'], 500 );
        }
    }
}
