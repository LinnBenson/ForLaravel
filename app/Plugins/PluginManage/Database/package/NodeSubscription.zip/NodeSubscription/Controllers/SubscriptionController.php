<?php

namespace App\Plugins\NodeSubscription\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;
use App\Plugins\NodeSubscription\Models\Subscription;
use App\Plugins\NodeSubscription\Models\Node;
use App\Plugins\NodeSubscription\Support\NodeService;
use App\Plugins\NodeSubscription\Support\RuleService;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * SubscriptionController
 * 订阅服务入口
 * @package App\Plugins\NodeSubscription\Controllers
 */
class SubscriptionController extends Controller {

    /**
     * 订阅入口
     * @param Request $request
     * @param string $uid
     * @param string $type
     * @return StreamedResponse|Response|string|JsonResponse
     */
    public function index( Request $request, string $uid, string $type ): StreamedResponse|Response|string|JsonResponse {
        $uid = trim( $uid ); $type = trim( $type );
        $token = $request->query( 'token', '' );
        if ( empty( $uid ) || empty( $type ) ) { return echoJson( 1, 'UID 或类型不能为空！' ); }
        // 用户验证
        $user = Subscription::query()
            ->where( 'id', $uid )
            ->where( 'status', true )
            ->where( 'password', $token )
            ->where( function ( $query ): void {
                $query->whereNull( 'expired' )->orWhere( 'expired', '>', now() );
            } )
            ->first();
        if ( empty( $user ) ) { return echoJson( 2, '用户验证失败！' ); }
        // 返回数据
       switch ( $type ) {
            case 'index':
                return $this->indexView( $user );
            case 'clash':
                return $this->substriptionClash( $user );
            case 'v2ray':
                return $this->substriptionV2Ray( $user );
            case 'quantumultx':
                return $this->substriptionQuantumultX( $user );
            default:
                return echoJson( 3, '不支持的订阅类型！' );
        }
    }

    /**
     * 订阅入口页面
     * @param Subscription $user
     * @return Response
     */
    private function indexView( Subscription $user ): Response {
        $plugin = plugin( 'NodeSubscription' );
        $nodes = $user->getNodes()->toArray();
        return response()->view( 'NodeSubscription::index', [
            'user' => $user,
            'nodes' => $nodes,
            'plugin' => $plugin,
            'subscriptionTitle' => $this->getSubtitle( $user ),
        ], 200, [
            'Content-Type' => 'text/html; charset=UTF-8',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
            'Expires' => '0',
        ] );
    }

    /**
     * Clash 订阅
     * @param Subscription $user
     * @return StreamedResponse
     */
    private function substriptionClash( Subscription $user ): StreamedResponse {
        $nodesText = []; $nodesGroup = [];
        $nodes = $user->getNodes()->toArray();
        foreach ( $nodes as $node ) {
            $node['name'] = "{$node['name']} • {$user['name']}";
            $nodeData = NodeService::getClashNode( $node );
            if ( !empty( $nodeData ) ) {
                $nodesText[] = $nodeData;
                $nodesGroup[] = "    - \"{$node['name']}\"";
            }
        }
        $plugin = plugin( 'NodeSubscription' );
        $nodesText = array_merge( $nodesText, $this->addItemSupport( 'getClashNode', $nodesGroup ) );
        $echo = file_get_contents( $plugin->path.'Database/Template/clash.txt' );
        $echo = str_replace( '{{node}}', implode( "\n", $nodesText ), $echo );
        $echo = str_replace( '{{node_group}}', implode( "\n", $nodesGroup ), $echo );
        $echo = str_replace( '{{rule}}', RuleService::getRuleWithClash(), $echo );
        $support = preg_replace( '/[\/\\\\\x00-\x1F\x7F]+/u', '-', trim( $plugin->config( 'title' )."-" ) ) ?: '';
        $fileName = preg_replace( '/[\/\\\\\x00-\x1F\x7F]+/u', '-', trim( $user->name ) ) ?: 'subscription';
        return response()->streamDownload(
            function () use ( $echo ): void { echo $echo; },
            $this->getSubtitle( $user ).".yaml",
            [
                'Content-Type' => 'application/yaml; charset=UTF-8',
                'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
                'Pragma' => 'no-cache',
                'Expires' => '0',
            ],
            'inline',
        );
    }

    /**
     * V2Ray 订阅
     * @param Subscription $user
     * @return Response
     */
    private function substriptionV2Ray( Subscription $user ): Response {
        $echo = [];
        $nodes = $user->getNodes()->toArray();
        foreach ( $nodes as $node ) {
            $node['name'] = "{$node['name']} • {$user['name']}";
            $nodeData = NodeService::getV2RayNode( $node );
            if ( !empty( $nodeData ) ) { $echo[] = $nodeData; }
        }
        $echo = array_merge( $echo, $this->addItemSupport( 'getV2RayNode' ) );
        $content = $echo === [] ? '' : implode( "\n", $echo )."\n";
        return response( $content, 200, [
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
            'Expires' => '0',
        ] );
    }

    /**
     * Quantumult X 订阅。
     * @param Subscription $user 订阅记录
     * @return Response Quantumult X 原生节点列表响应
     */
    private function substriptionQuantumultX( Subscription $user ): Response {
        $echo = [];
        foreach ( $user->getNodes()->toArray() as $node ) {
            $node['name'] = "{$node['name']} • {$user->name}";
            $nodeData = NodeService::getQuantumultXNode( $node );
            if ( $nodeData !== '' ) { $echo[] = $nodeData; }
        }
        $echo = array_merge( $echo, $this->addItemSupport( 'getQuantumultXNode' ) );
        $content = $echo === [] ? '' : implode( "\n", $echo )."\n";
        return response( $content, 200, [
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
            'Expires' => '0',
        ] );
    }

    /**
     * 添加支持节点。
     * @param array|null $nodesGroup 节点组数组
     * @return void
     */
    private function addItemSupport( string $getMethod = '', array &$nodesGroup = [] ): array {
        $plugin = plugin( 'NodeSubscription' ); $nodes = [];
        if ( $plugin->config( 'addItem.support' ) ) {
            $name = "Technical Support: {$plugin->config( 'title' )}";
            $nodes[] = NodeService::$getMethod( [
                'name' => $name,
                'type' => 'vmess',
                'server' => '127.0.0.1',
                'port' => 80,
                'config' => [
                    'uuid' => '00000000-0000-0000-0000-000000000000',
                    'alterId' => 0,
                    'cipher' => 'auto',
                    'tls' => false,
                    'network' => 'tcp',
                ]
            ]);
            $nodesGroup[] = "    - \"{$name}\"";
        }
        if ( $plugin->config( 'addItem.update' ) ) {
            $name = "UPDATED IN ".date( 'Y-m-d H:i' );
            $nodes[] = NodeService::$getMethod( [
                'name' => $name,
                'type' => 'vmess',
                'server' => '127.0.0.1',
                'port' => 80,
                'config' => [
                    'uuid' => '00000000-0000-0000-0000-000000000000',
                    'alterId' => 0,
                    'cipher' => 'auto',
                    'tls' => false,
                    'network' => 'tcp',
                ]
            ]);
            $nodesGroup[] = "    - \"{$name}\"";
        }
        return is_array( $nodes ) && !empty( $nodes ) ? $nodes : [];
    }

    /**
     * 获取订阅标题。
     * @param Subscription $user 订阅记录
     * @return string 订阅标题
     */
    private function getSubtitle( Subscription $user ): string {
        $plugin = plugin( 'NodeSubscription' );
        $subtitle = $plugin->config( 'subtitle' );
        $subtitle = str_replace( '{{title}}', $plugin->config( 'title' ), $subtitle );
        $subtitle = str_replace( '{{username}}', $user->name, $subtitle );
        return $subtitle;
    }
}
