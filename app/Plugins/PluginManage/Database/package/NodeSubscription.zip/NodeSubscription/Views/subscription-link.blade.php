{{-- Clash 和 V2Ray 订阅链接 --}}
<section
    class="node-subscription-links"
    x-data="{
        copied: '',
        async copyLink( type ) {
            const input = this.$refs[type];
            try {
                await navigator.clipboard.writeText( input.value );
            }catch ( error ) {
                input.select();
                document.execCommand( 'copy' );
            }
            this.copied = type;
            setTimeout( () => {
                if ( this.copied === type ) { this.copied = ''; }
            }, 1800 );
        },
    }"
>
    <article>
        <header>
            <div class="node-subscription-links-icon">
                <x-filament::icon icon="heroicon-o-home" />
            </div>
            <div>
                <h3>订阅主页</h3>
                <p>用户查看当前订阅信息</p>
            </div>
        </header>
        <div class="node-subscription-links-value">
            <input x-ref="index" type="text" value="{{ $indexLink }}" readonly aria-label="订阅主页链接">
            <a href="{{ $indexLink }}" target="_blank" rel="noopener noreferrer" aria-label="在新标签页打开订阅主页链接">
                <x-filament::icon icon="heroicon-o-arrow-top-right-on-square" />
                <span>打开</span>
            </a>
            <button type="button" x-on:click="copyLink( 'index' )">
                <x-filament::icon icon="heroicon-o-clipboard-document" />
                <span x-text="copied === 'index' ? '已复制' : '复制'">复制</span>
            </button>
        </div>
    </article>

    <article>
        <header>
            <div class="node-subscription-links-icon">
                <x-filament::icon icon="heroicon-o-command-line" />
            </div>
            <div>
                <h3>Clash 订阅</h3>
                <p>适用于 Mihomo、Clash Meta 等客户端</p>
            </div>
        </header>
        <div class="node-subscription-links-value">
            <input x-ref="clash" type="text" value="{{ $clashLink }}" readonly aria-label="Clash 订阅链接">
            <a href="{{ $clashLink }}" target="_blank" rel="noopener noreferrer" aria-label="在新标签页打开 Clash 订阅链接">
                <x-filament::icon icon="heroicon-o-arrow-top-right-on-square" />
                <span>打开</span>
            </a>
            <button type="button" x-on:click="copyLink( 'clash' )">
                <x-filament::icon icon="heroicon-o-clipboard-document" />
                <span x-text="copied === 'clash' ? '已复制' : '复制'">复制</span>
            </button>
        </div>
    </article>

    <article>
        <header>
            <div class="node-subscription-links-icon">
                <x-filament::icon icon="heroicon-o-link" />
            </div>
            <div>
                <h3>V2Ray 订阅</h3>
                <p>适用于 V2RayN、V2RayNG 等客户端</p>
            </div>
        </header>
        <div class="node-subscription-links-value">
            <input x-ref="v2ray" type="text" value="{{ $v2rayLink }}" readonly aria-label="V2Ray 订阅链接">
            <a href="{{ $v2rayLink }}" target="_blank" rel="noopener noreferrer" aria-label="在新标签页打开 V2Ray 订阅链接">
                <x-filament::icon icon="heroicon-o-arrow-top-right-on-square" />
                <span>打开</span>
            </a>
            <button type="button" x-on:click="copyLink( 'v2ray' )">
                <x-filament::icon icon="heroicon-o-clipboard-document" />
                <span x-text="copied === 'v2ray' ? '已复制' : '复制'">复制</span>
            </button>
        </div>
    </article>

    <article>
        <header>
            <div class="node-subscription-links-icon">
                <x-filament::icon icon="heroicon-o-device-phone-mobile" />
            </div>
            <div>
                <h3>Quantumult X 订阅</h3>
                <p>适用于 iOS Quantumult X 客户端</p>
            </div>
        </header>
        <div class="node-subscription-links-value">
            <input x-ref="quantumultx" type="text" value="{{ $quantumultXLink }}" readonly aria-label="Quantumult X 订阅链接">
            <a href="{{ $quantumultXLink }}" target="_blank" rel="noopener noreferrer" aria-label="在新标签页打开 Quantumult X 订阅链接">
                <x-filament::icon icon="heroicon-o-arrow-top-right-on-square" />
                <span>打开</span>
            </a>
            <button type="button" x-on:click="copyLink( 'quantumultx' )">
                <x-filament::icon icon="heroicon-o-clipboard-document" />
                <span x-text="copied === 'quantumultx' ? '已复制' : '复制'">复制</span>
            </button>
        </div>
    </article>
</section>

<style>
    /* 订阅链接弹窗 */
    .node-subscription-links { display: grid; gap: 1rem; }
    .node-subscription-links article { padding: 1rem; border: 1px solid var(--gray-200); border-radius: 0.8rem; background: var(--gray-50); }
    .dark .node-subscription-links article { border-color: var(--gray-700); background: var(--gray-900); }
    .node-subscription-links article header { display: flex; align-items: center; gap: 0.75rem; }
    .node-subscription-links-icon { display: flex; width: 2.5rem; height: 2.5rem; flex: 0 0 auto; border-radius: 0.65rem; background: color-mix(in srgb, var(--primary-500) 12%, transparent); color: var(--primary-600); align-items: center; justify-content: center; }
    .node-subscription-links-icon svg { width: 1.25rem; height: 1.25rem; }
    .node-subscription-links h3 { color: var(--gray-900); font-size: 0.9rem; font-weight: 700; }
    .dark .node-subscription-links h3 { color: var(--gray-100); }
    .node-subscription-links p { margin-top: 0.1rem; color: var(--gray-500); font-size: 0.75rem; }
    .node-subscription-links-value { display: grid; margin-top: 0.85rem; grid-template-columns: minmax(0, 1fr) auto auto; gap: 0.6rem; }
    .node-subscription-links-value input { width: 100%; min-width: 0; height: 2.6rem; padding: 0 0.75rem; border: 1px solid var(--gray-300); border-radius: 0.6rem; outline: none; background: white; color: var(--gray-700); font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 0.75rem; }
    .dark .node-subscription-links-value input { border-color: var(--gray-700); background: var(--gray-950); color: var(--gray-200); }
    .node-subscription-links-value input:focus { border-color: var(--primary-500); box-shadow: 0 0 0 1px var(--primary-500); }
    .node-subscription-links-value a,
    .node-subscription-links-value button { display: inline-flex; min-width: 5.5rem; min-height: 2.6rem; padding: 0.55rem 0.85rem; border-radius: 0.6rem; align-items: center; justify-content: center; gap: 0.4rem; font-size: 0.8rem; font-weight: 650; }
    .node-subscription-links-value a { border: 1px solid var(--gray-300); background: white; color: var(--gray-700); }
    .dark .node-subscription-links-value a { border-color: var(--gray-700); background: var(--gray-900); color: var(--gray-200); }
    .node-subscription-links-value a:hover { border-color: var(--primary-500); color: var(--primary-600); }
    .node-subscription-links-value button { background: var(--primary-600); color: white; }
    .node-subscription-links-value button:hover { background: var(--primary-500); }
    .node-subscription-links-value a svg,
    .node-subscription-links-value button svg { width: 1rem; height: 1rem; }
    @media (max-width: 640px) {
        .node-subscription-links-value { grid-template-columns: 1fr; }
        .node-subscription-links-value { grid-template-columns: 1fr 1fr; }
        .node-subscription-links-value input { grid-column: 1 / -1; }
        .node-subscription-links-value a,
        .node-subscription-links-value button { width: 100%; }
    }
</style>
