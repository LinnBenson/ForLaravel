<x-filament-panels::page>
    {{-- 节点订阅器栏目切换 --}}
    <nav class="node-subscription-tabs" aria-label="节点订阅器栏目" style="margin-bottom: -16px;">
        <a
            href="{{ \App\Plugins\NodeSubscription\Support\NodeTable::getUrl( ['tab' => 'subscriptions'] ) }}"
            @class(['is-active' => $this->activeTab === 'subscriptions'])
        >
            <x-filament::icon icon="heroicon-o-queue-list" />
            <span><strong>订阅列表</strong><small>管理节点订阅</small></span>
        </a>
        <a
            href="{{ \App\Plugins\NodeSubscription\Support\NodeTable::getUrl( ['tab' => 'nodes'] ) }}"
            @class(['is-active' => $this->activeTab === 'nodes'])
        >
            <x-filament::icon icon="heroicon-o-server-stack" />
            <span><strong>节点列表</strong><small>管理代理节点</small></span>
        </a>
        <a
            href="{{ \App\Plugins\NodeSubscription\Support\NodeTable::getUrl( ['tab' => 'settings'] ) }}"
            @class(['is-active' => $this->activeTab === 'settings'])
        >
            <x-filament::icon icon="heroicon-o-adjustments-horizontal" />
            <span><strong>其它配置</strong><small>编辑模板文件</small></span>
        </a>
    </nav>

    @if ( $this->activeTab !== 'settings' )
        {{-- 当前栏目数据表 --}}
        {{ $this->table }}
    @else
        {{-- TXT 模板文件编辑器 --}}
        <section class="node-subscription-template-editor">
            @if ( $this->templateFiles === [] )
                <div class="node-subscription-template-empty">
                    <x-filament::icon icon="heroicon-o-document-text" />
                    <strong>暂无 TXT 模板</strong>
                    <p>请先在 Support/Template 目录中添加 .txt 文件。</p>
                </div>
            @else
                <aside>
                    <h3>模板文件</h3>
                    @foreach ( $this->templateFiles as $fileName )
                        <button
                            type="button"
                            wire:click="selectTemplate( @js( $fileName ) )"
                            @class(['is-active' => $this->selectedTemplate === $fileName])
                        >
                            <x-filament::icon icon="heroicon-o-document-text" />
                            <span>{{ $fileName }}</span>
                        </button>
                    @endforeach
                </aside>
                <form wire:submit="saveTemplate">
                    <header>
                        <div>
                            <span>当前文件</span>
                            <h3>{{ $this->selectedTemplate }}</h3>
                        </div>
                        <button type="submit" wire:loading.attr="disabled" wire:target="saveTemplate">
                            <x-filament::icon icon="heroicon-o-check-circle" />
                            <span wire:loading.remove wire:target="saveTemplate">保存修改</span>
                            <span wire:loading wire:target="saveTemplate">保存中…</span>
                        </button>
                    </header>
                    <textarea
                        wire:model="templateContent"
                        aria-label="模板文件内容"
                        spellcheck="false"
                    ></textarea>
                    @error( 'templateContent' )
                        <p class="node-subscription-template-error">{{ $message }}</p>
                    @enderror
                </form>
            @endif
        </section>
    @endif
</x-filament-panels::page>

<style>
    /* 节点订阅器栏目切换 */
    .node-subscription-tabs {
        display: grid;
        padding: 0.75rem;
        border: 1px solid var(--gray-200);
        border-radius: 1rem;
        background: white;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 0.75rem;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
    }
    .dark .node-subscription-tabs { border-color: var(--gray-700); background: var(--gray-900); }
    .node-subscription-tabs a {
        display: flex;
        min-width: 0;
        padding: 0.9rem 1rem;
        border: 1px solid transparent;
        border-radius: 0.8rem;
        color: var(--gray-500);
        align-items: center;
        gap: 0.8rem;
        transition: background-color 0.15s, border-color 0.15s, color 0.15s;
    }
    .node-subscription-tabs a:hover { background: var(--gray-50); color: var(--gray-700); }
    .dark .node-subscription-tabs a:hover { background: var(--gray-800); color: var(--gray-200); }
    .node-subscription-tabs a.is-active {
        border-color: color-mix(in srgb, var(--primary-500) 35%, transparent);
        background: color-mix(in srgb, var(--primary-500) 10%, transparent);
        color: var(--primary-600);
    }
    .node-subscription-tabs svg { width: 1.5rem; height: 1.5rem; flex: 0 0 auto; }
    .node-subscription-tabs span { display: flex; min-width: 0; flex-direction: column; }
    .node-subscription-tabs strong { font-size: 0.9rem; font-weight: 700; }
    .node-subscription-tabs small { margin-top: 0.15rem; color: var(--gray-500); font-size: 0.75rem; }
    /* TXT 模板文件编辑器 */
    .node-subscription-template-editor {
        display: grid;
        min-height: 34rem;
        overflow: hidden;
        border: 1px solid var(--gray-200);
        border-radius: 1rem;
        background: white;
        grid-template-columns: 15rem minmax(0, 1fr);
    }
    .dark .node-subscription-template-editor { border-color: var(--gray-700); background: var(--gray-900); }
    .node-subscription-template-editor aside { padding: 1rem; border-right: 1px solid var(--gray-200); }
    .dark .node-subscription-template-editor aside { border-color: var(--gray-700); }
    .node-subscription-template-editor aside h3 { margin: 0 0 0.75rem; color: var(--gray-900); font-size: 0.85rem; font-weight: 700; }
    .dark .node-subscription-template-editor aside h3 { color: var(--gray-100); }
    .node-subscription-template-editor aside button {
        display: flex;
        width: 100%;
        padding: 0.65rem 0.75rem;
        border-radius: 0.65rem;
        color: var(--gray-600);
        align-items: center;
        gap: 0.6rem;
        font-size: 0.82rem;
        text-align: left;
    }
    .node-subscription-template-editor aside button:hover { background: var(--gray-50); }
    .dark .node-subscription-template-editor aside button:hover { background: var(--gray-800); }
    .node-subscription-template-editor aside button.is-active { background: color-mix(in srgb, var(--primary-500) 12%, transparent); color: var(--primary-600); }
    .node-subscription-template-editor aside svg { width: 1.1rem; height: 1.1rem; flex: 0 0 auto; }
    .node-subscription-template-editor form {
        display: flex;
        min-width: 0;
        background: #0d1117;
        color-scheme: dark;
        flex-direction: column;
    }
    .node-subscription-template-editor form header {
        display: flex;
        min-height: 4.7rem;
        padding: 0.8rem 1rem;
        border-bottom: 1px solid #30363d;
        background: #161b22;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }
    .node-subscription-template-editor form header > div > span { color: #8b949e; font-size: 0.72rem; }
    .node-subscription-template-editor form header h3 { color: #e6edf3; font-size: 1rem; font-weight: 700; }
    .node-subscription-template-editor form header button {
        display: inline-flex;
        min-height: 2.35rem;
        padding: 0.55rem 0.9rem;
        border-radius: 0.6rem;
        background: var(--primary-600);
        color: white;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.82rem;
        font-weight: 650;
    }
    .node-subscription-template-editor form header button:disabled { opacity: 0.65; }
    .node-subscription-template-editor form header button svg { width: 1rem; height: 1rem; }
    .node-subscription-template-editor form header button span { color: white; font-size: 0.82rem; }
    .node-subscription-template-editor textarea {
        width: 100%;
        min-height: 27rem;
        flex: 1;
        resize: vertical;
        padding: 1rem 1.1rem;
        border: 0;
        border-radius: 0;
        outline: none;
        background: #0d1117;
        color: #e6edf3;
        caret-color: #58a6ff;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 0.86rem;
        line-height: 1.7;
        tab-size: 4;
    }
    .node-subscription-template-editor textarea:focus { box-shadow: inset 0 0 0 1px #1f6feb; }
    .node-subscription-template-editor textarea::selection { background: rgba(56, 139, 253, 0.4); }
    .node-subscription-template-editor textarea::-webkit-scrollbar { width: 0.75rem; height: 0.75rem; }
    .node-subscription-template-editor textarea::-webkit-scrollbar-track { background: #0d1117; }
    .node-subscription-template-editor textarea::-webkit-scrollbar-thumb { border: 3px solid #0d1117; border-radius: 9999px; background: #484f58; }
    .node-subscription-template-error { margin: 0; padding: 0.5rem 1rem; background: #161b22; color: #f85149; font-size: 0.78rem; }
    .node-subscription-template-empty { display: flex; min-height: 20rem; grid-column: 1 / -1; color: var(--gray-500); align-items: center; justify-content: center; flex-direction: column; }
    .node-subscription-template-empty svg { width: 2.5rem; height: 2.5rem; margin-bottom: 0.75rem; }
    .node-subscription-template-empty strong { color: var(--gray-800); }
    .dark .node-subscription-template-empty strong { color: var(--gray-200); }
    .node-subscription-template-empty p { margin-top: 0.25rem; font-size: 0.8rem; }
    @media (max-width: 640px) {
        .node-subscription-tabs { grid-template-columns: 1fr; }
        .node-subscription-template-editor { grid-template-columns: 1fr; }
        .node-subscription-template-editor aside { border-right: 0; border-bottom: 1px solid var(--gray-200); }
        .dark .node-subscription-template-editor aside { border-color: var(--gray-700); }
    }
</style>
