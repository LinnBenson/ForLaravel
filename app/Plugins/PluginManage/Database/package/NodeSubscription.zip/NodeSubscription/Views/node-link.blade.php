{{-- 节点分享链接及二维码 --}}
<section
    class="node-subscription-link"
    x-data="{
        copied: false,
        async copyLink() {
            try {
                await navigator.clipboard.writeText( this.$refs.link.value );
                this.copied = true;
                setTimeout( () => this.copied = false, 1800 );
            }catch ( error ) {
                this.$refs.link.select();
                document.execCommand( 'copy' );
                this.copied = true;
                setTimeout( () => this.copied = false, 1800 );
            }
        },
    }"
>
    <div class="node-subscription-link-qr">
        <img src="{{ $qrCode }}" alt="节点链接二维码">
        <p>使用代理客户端扫描二维码导入节点</p>
    </div>
    <div class="node-subscription-link-value">
        <label for="node-subscription-link-value">节点链接</label>
        <textarea
            id="node-subscription-link-value"
            x-ref="link"
            readonly
            rows="4"
        >{{ $link }}</textarea>
        <button type="button" x-on:click="copyLink()">
            <x-filament::icon icon="heroicon-o-clipboard-document" />
            <span x-text="copied ? '已复制' : '复制链接'">复制链接</span>
        </button>
    </div>
</section>

<style>
    /* 节点链接弹窗 */
    .node-subscription-link { display: grid; grid-template-columns: 14rem minmax(0, 1fr); gap: 1.5rem; }
    .node-subscription-link-qr { display: flex; align-items: center; flex-direction: column; }
    .node-subscription-link-qr img { width: 13rem; height: 13rem; padding: 0.65rem; border: 1px solid var(--gray-200); border-radius: 0.8rem; background: white; }
    .dark .node-subscription-link-qr img { border-color: var(--gray-700); }
    .node-subscription-link-qr p { margin-top: 0.65rem; color: var(--gray-500); font-size: 0.75rem; text-align: center; }
    .node-subscription-link-value { display: flex; min-width: 0; flex-direction: column; }
    .node-subscription-link-value label { margin-bottom: 0.5rem; color: var(--gray-700); font-size: 0.85rem; font-weight: 600; }
    .dark .node-subscription-link-value label { color: var(--gray-200); }
    .node-subscription-link-value textarea { width: 100%; min-height: 9rem; padding: 0.8rem; border: 1px solid var(--gray-300); border-radius: 0.65rem; outline: none; background: var(--gray-50); color: var(--gray-800); font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 0.76rem; line-height: 1.55; resize: none; word-break: break-all; }
    .dark .node-subscription-link-value textarea { border-color: var(--gray-700); background: var(--gray-900); color: var(--gray-100); }
    .node-subscription-link-value textarea:focus { border-color: var(--primary-500); box-shadow: 0 0 0 1px var(--primary-500); }
    .node-subscription-link-value button { display: inline-flex; min-height: 2.5rem; margin-top: 0.75rem; padding: 0.55rem 0.9rem; border-radius: 0.6rem; background: var(--primary-600); color: white; align-items: center; align-self: flex-end; justify-content: center; gap: 0.45rem; font-size: 0.82rem; font-weight: 650; }
    .node-subscription-link-value button:hover { background: var(--primary-500); }
    .node-subscription-link-value button svg { width: 1rem; height: 1rem; }
    @media (max-width: 640px) {
        .node-subscription-link { grid-template-columns: 1fr; }
        .node-subscription-link-qr img { width: 11rem; height: 11rem; }
        .node-subscription-link-value button { width: 100%; align-self: stretch; }
    }
</style>
