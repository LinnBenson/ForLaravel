@extends( 'View::Frame' )
@section( 'title', "{$plugin->config( 'title' )} [{$user->name}]" )
@push('head')
<style>
    div#box {
        width: var( --vw );
        height: var( --vh );
        background-image: url( "{{$plugin->config( 'view.background' )}}" );
        background-size: cover;
        background-position: center;
    }
    main {
        width: 690px;
        max-width: calc( var( --vw ) - 24px );
        height: auto;
        padding: 32px;
        margin: 160px auto;
        background-color: rgb( var( --r0 ), 0.75 );
        border: 1px solid rgb( var( --r3 ), 0.15 );
        border-radius: var( --radius );
        box-sizing: border-box;
        backdrop-filter: blur( 8px );
        -webkit-backdrop-filter: blur( 8px );
    }
    ul.userinfo {
        margin: 0;
        padding: 0;
        list-style: none;
    }
    ul.userinfo li {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 0;
        border-bottom: 1px solid rgb( var( --r3 ), 0.15 );
    }
    ul.userinfo li:last-child { border-bottom: none; }
    ul.userinfo li span:first-child {
        font-weight: bold;
    }
    ul.nodes {
        display: grid;
        margin: 0;
        padding: 0;
        list-style: none;
        gap: 10px;
    }
    ul.nodes li {
        display: grid;
        min-width: 0;
        padding: 14px 16px;
        border: 1px solid rgb( var( --r3 ), 0.13 );
        border-radius: calc( var( --radius ) + 4px );
        background: rgb( var( --r0 ), 0.72 );
        box-shadow: 0 4px 16px rgb( var( --r1 ), 0.04 );
        grid-template-columns: minmax( 0, 1fr ) auto;
        align-items: center;
        gap: 16px;
        transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
    }
    ul.nodes li div.node-content { min-width: 0; }
    ul.nodes li p.title {
        display: flex;
        margin: 0;
        align-items: center;
        gap: 8px;
    }
    ul.nodes li p.title span.name {
        overflow: hidden;
        font-size: 15px;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    ul.nodes li p.title span.type {
        display: inline-block;
        padding: 3px 7px;
        border-radius: 999px;
        background: rgb( var( --r3 ), 0.13 );
        color: rgb( var( --r3 ) );
        font-size: 10px;
        font-weight: 700;
        line-height: 1;
    }
    ul.nodes li p.host {
        display: flex;
        min-width: 0;
        margin: 7px 0 0;
        color: rgb( var( --r1 ), 0.58 );
        align-items: center;
        gap: 6px;
        font-family: Consolas, Monaco, monospace;
        font-size: 11px;
    }
    ul.nodes li p.host span {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    ul.nodes li div.buttons {
        display: flex;
        flex: 0 0 auto;
        align-items: center;
        justify-content: flex-end;
        gap: 8px;
    }
    ul.nodes li.nodes-empty { display: block !important; padding: 32px 16px !important; color: rgb( var( --r1 ), 0.48 ); text-align: center; }
    ul.nodes li.nodes-empty i { display: block; margin-bottom: 8px; font-size: 24px; }
    div.QRCodeBox {
        display: flex;
        min-height: 300px;
        align-items: center;
        justify-content: center;
    }
    div.QRCodeBox img { display: block; max-width: 100%; height: auto; margin: 0 auto; }
    div.copyright {
        margin-top: 32px;
        text-align: center;
        font-size: 12px;
    }
    section.app p.link {
        margin: 0;
        padding: 6px 12px;
        margin-bottom: 8px;
        border-radius: var( --radius );
        background-color: rgb( var( --r3 ), 0.08 );
        font-family: code;
        font-size: 13px;
        word-break: break-all;
    }
    section.app p.hint {
        padding-left: 8px;
    }
    section.app p.hint::before {
        content: '- ';
    }
    section.app div.buttons {
        margin-top: 16px;
    }
    @media( max-width: 580px ) {
        main {
            padding: 0px;
            margin: 12px auto;
            background-color: rgb( var( --r0 ), 0 );
            border: none;
            backdrop-filter: none;
            -webkit-backdrop-filter: none;
        }
        main section.toview-card {
            background-color: rgb( var( --r0 ), 0.75 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
        }
        ul.nodes li { padding: 14px; grid-template-columns: 1fr; gap: 12px; }
        ul.nodes li div.buttons { justify-content: flex-start; }
        ul.nodes li div.buttons > div { min-width: 0; flex: 1; }
        ul.nodes li div.buttons > div .toview-button-content { width: 100%; justify-content: center; }
        div.QRCodeBox { min-height: 256px; }
        div.copyright {
            padding: 16px 0px;
            margin: 0px;
            background-color: rgb( var( --r0 ), 0.75 );
            border-radius: var( --radius );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
        }
    }
</style>
@endpush

@section('body')
    <div id="box" class="scroll">
        <main>
            <x-View::Card icon="false" open="off">
                <h3>{{$subscriptionTitle}}</h3>
                <hr />
                <ul class="userinfo">
                    <li>
                        <span>订阅名称</span>
                        <span>{{$user->name}}</span>
                    </li>
                    <li>
                        <span>过期时间</span>
                        <span>{{!empty( $user->expired ) ? $user->expired : '无限制'}}</span>
                    </li>
                    <li>
                        <span>可用节点</span>
                        <span>{{count( $nodes )}} 个</span>
                    </li>
                </ul>
            </x-View::Card>
            @php
                $links = [
                    'clash' => route( 'plugins.node-subscription.index', [ 'uid' => $user->id, 'type' => 'clash', 'token' => $user->password ] ),
                    'shadowrocket' => route( 'plugins.node-subscription.index', [ 'uid' => $user->id, 'type' => 'v2ray', 'token' => $user->password ] ),
                    'v2ray' => route( 'plugins.node-subscription.index', [ 'uid' => $user->id, 'type' => 'v2ray', 'token' => $user->password ] ),
                    'quantumultx' => route( 'plugins.node-subscription.index', [ 'uid' => $user->id, 'type' => 'quantumultx', 'token' => $user->password ] )
                ];
                $clash = "clash://install-config?url=".rawurlencode( $links['clash'] )."&name=".rawurlencode( $subscriptionTitle );
                $shadowrocket = 'shadowrocket://add/sub://'.base64_encode( $links['shadowrocket'] ).'?remark='.rawurlencode( $subscriptionTitle );
                $v2ray = 'v2rayng://install-config?url='.rawurlencode( $links['v2ray'] ).'&name='.rawurlencode( $subscriptionTitle );
                $quantumultXResource = json_encode( [
                    'server_remote' => [
                        "{$links['quantumultx']}, tag={$subscriptionTitle}, img-url=smoke.fill.system, update-interval=-1, enabled=true",
                    ],
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
                $quantumultx = 'quantumult-x:///add-resource?remote-resource='.rawurlencode( $quantumultXResource );
            @endphp
            <x-View::Card class="app" icon="bi-award" title="从 Shadowrocket 订阅" open="true">
                <p class="link p6">{{$links['shadowrocket']}}</p>
                <p class="hint p6">支持 Shadowrocket [iPhone/iPad/Mac] 客户端直接订阅。</p>
                <x-View::Layout class="buttons" gap="8px">
                    <x-View::Button icon="bi-box-arrow-up-right" color="r2" href="{{$shadowrocket}}" target="_blank">一键订阅</x-View::Button>
                    <x-View::Button icon="bi-qr-code" color="r3" onClick="view.showNodeQRCode( `Shadowrocket`, `{{$shadowrocket}}` )">二维码</x-View::Button>
                    <x-View::Button icon="bi-copy" color="r3" class="copy" data-clipboard-text="{{$links['shadowrocket']}}">复制链接</x-View::Button>
                </x-View::Layout>
            </x-View::Card>
            <x-View::Card class="app" icon="bi-award" title="从 Clash 订阅" open="true">
                <p class="link p6">{{$links['clash']}}</p>
                <p class="hint p6">支持 Clash/Clash meta 客户端直接订阅。</p>
                <p class="hint p6">支持同步导入分流规则</p>
                <x-View::Layout class="buttons" gap="8px">
                    <x-View::Button icon="bi-box-arrow-up-right" color="r2" href="{{$clash}}" target="_blank">一键订阅</x-View::Button>
                    <x-View::Button icon="bi-qr-code" color="r3" onClick="view.showNodeQRCode( `Clash`, `{{$clash}}` )">二维码</x-View::Button>
                    <x-View::Button icon="bi-copy" color="r3" class="copy" data-clipboard-text="{{$links['clash']}}">复制链接</x-View::Button>
                </x-View::Layout>
            </x-View::Card>
            <x-View::Card class="app" icon="bi-award" title="从 V2Ray 订阅" open="false">
                <p class="link p6">{{$links['v2ray']}}</p>
                <p class="hint p6">链接支持 V2RayN/V2RayNG 客户端进行使用。</p>
                <p class="hint p6" style="color: rgb( var( --r5 ) )">V2Ray 客户端对一键订阅支持并不完善，您可能需要手动复制链接添加订阅。</p>
                <x-View::Layout class="buttons" gap="8px">
                    <x-View::Button icon="bi-box-arrow-up-right" color="r2" href="{{$v2ray}}" target="_blank">一键订阅</x-View::Button>
                    <x-View::Button icon="bi-qr-code" color="r3" onClick="view.showNodeQRCode( `V2Ray`, `{{$v2ray}}` )">二维码</x-View::Button>
                    <x-View::Button icon="bi-copy" color="r3" class="copy" data-clipboard-text="{{$links['v2ray']}}">复制链接</x-View::Button>
                </x-View::Layout>
            </x-View::Card>
            <x-View::Card class="app" icon="bi-award" title="从 QuantumultX 订阅" open="false">
                <p class="link p6">{{$links['quantumultx']}}</p>
                <p class="hint p6">支持 QuantumultX [iPhone/iPad/Mac] 客户端直接订阅。</p>
                <x-View::Layout class="buttons" gap="8px">
                    <x-View::Button icon="bi-box-arrow-up-right" color="r2" href="{{$quantumultx}}" target="_blank">一键订阅</x-View::Button>
                    <x-View::Button icon="bi-qr-code" color="r3" onClick="view.showNodeQRCode( `QuantumultX`, `{{$quantumultx}}` )">二维码</x-View::Button>
                    <x-View::Button icon="bi-copy" color="r3" class="copy" data-clipboard-text="{{$links['quantumultx']}}">复制链接</x-View::Button>
                </x-View::Layout>
            </x-View::Card>
            <x-View::Card icon="bi-link-45deg" title="当前可用节点 [{{count( $nodes )}}]" open="off">
                <ul class="nodes">
                    @forelse( $nodes as $node )
                        @php
                            $rid = "node_{$node['id']}";
                            $nodeType = \App\Plugins\NodeSubscription\Models\Node::TYPES[$node['type']] ?? $node['type'];
                            $nodeLink = \App\Plugins\NodeSubscription\Support\NodeService::getV2RayNode( $node );
                        @endphp
                        <li>
                            <div class="node-content">
                                <p class="title">
                                    <span class="name">{{$node['name']}}</span>
                                    <span class="type">{{$nodeType}}</span>
                                </p>
                                <p class="host"><span><i class="bi-server"></i> {{$node['server']}}:{{$node['port']}}</span></p>
                            </div>
                            <div class="buttons">
                                <x-View::Button icon="bi-copy" color="r3" class="copy" size="small" data-clipboard-text="{{$nodeLink}}">复制</x-View::Button>
                                <x-View::Button icon="bi-qr-code" color="r3" size="small" onClick="view.showNodeQRCode( `{{$rid}}`, `{{$nodeLink}}` )">二维码</x-View::Button>
                            </div>
                        </li>
                    @empty
                        <li class="nodes-empty"><i class="bi bi-inbox"></i><span>当前暂无可用节点</span></li>
                    @endforelse
                </ul>
            </x-View::Card>
            <div class="copyright">
                {!!setting( 'app.copyright' )!!}
            </div>
        </main>
    </div>
@endsection

@push('footer')
<script>
    const view = {
        showNodeQRCode: function( rid, nodeLink ) {
            Core.popup( `<div id="${rid}" class="QRCodeBox"></div>` )
                .rid( rid )
                .icon( 'bi-qr-code' )
                .title( '扫描二维码' )
                .width( '380px' )
                .height( 'auto' )
                .buttons([
                    { title: '复制链接', icon: 'bi-copy', method: async () => { await Core.copy( nodeLink ); } },
                    { title: '关闭', icon: 'bi-x-lg', method: ( popupRid ) => { Core.popupClose( popupRid ); } }
                ])
                .show();
            const element = document.getElementById( rid );
            if ( element ) { Core.QRCode( $( element ), nodeLink, 300 ); }
        }
    };
</script>
@endpush
