<?php

namespace App\Plugins\NodeSubscription\Support;

/**
 * RuleService
 * 订阅规则转换服务
 * @package App\Plugins\NodeSubscription\Support
 */
class RuleService {

    /**
     * 获取规则文件内容
     * @return string 整理后的规则文本
     */
    private static function getRule(): string {
        $rule = trim( file_get_contents( plugin( 'NodeSubscription' )->path.'Database/Template/rule.txt' ) );
        if ( $rule === '' ) { return ''; }
        $rule = str_replace( ["\r\n", "\r"], "\n", $rule );
        $rule = preg_replace( '/^[\t ]*\/\/.*(?:\n|$)/m', '', $rule ) ?? '';
        $rule = preg_replace( '/\n+/', "\n", $rule ) ?? '';
        return trim( $rule );
    }

    /**
     * 获取规则文件内容并转换为 Clash 规则格式
     * @return string 整理后的 Clash 规则文本
     */
    public static function getRuleWithClash(): string {
        $rule = self::getRule();
        $replace = [
            "DOMAIN-SUFFIX," => "  - \"DOMAIN-SUFFIX,",
            "IP-CIDR," => "  - \"IP-CIDR,",
            "IP-CIDR6," => "  - \"IP-CIDR6,",
            "GEOIP," => "  - \"GEOIP,",
            "MATCH," => "  - \"MATCH,",
            ", 国际代理" => ", ♻️ 国际代理",
            ", 回国线路" => ", 🐼 回国线路",
            ", ChatGPT" => ", 📚 ChatGPT",
            ", 社交伪装" => ", ❄️ 社交伪装",
            ", 流媒体连接" => ", 🖥 流媒体连接",
            ", 黑名单" => ", 🚫 黑名单"
        ];
        $replace = str_replace( array_keys( $replace ), array_values( $replace ), $rule );
        $replace = preg_replace( '/$/m', '"', $replace );
        return $replace;
    }

}