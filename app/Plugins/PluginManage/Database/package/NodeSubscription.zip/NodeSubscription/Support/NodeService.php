<?php

namespace App\Plugins\NodeSubscription\Support;

use JsonException;

/**
 * NodeService
 * 代理节点检测及 Clash、V2Ray 分享链接转换服务。
 * @package App\Plugins\NodeSubscription\Support
 */
class NodeService {
    /** @var array<string, array<string, string>> */
    private const CLASH_FIELDS = [
        'ss' => [
            'password' => 'password',
            'cipher' => 'cipher',
            'udp' => 'udp',
            'plugin' => 'plugin',
            'plugin-opts' => 'plugin-opts',
        ],
        'ssr' => [
            'password' => 'password',
            'cipher' => 'cipher',
            'protocol' => 'protocol',
            'protocol-param' => 'protocol-param',
            'obfs' => 'obfs',
            'obfs-param' => 'obfs-param',
            'udp' => 'udp',
        ],
        'vmess' => [
            'uuid' => 'uuid',
            'alterId' => 'alterId',
            'cipher' => 'cipher',
            'udp' => 'udp',
            'network' => 'network',
            'tls' => 'tls',
            'server-name' => 'servername',
            'skip-cert-verify' => 'skip-cert-verify',
            'client-fingerprint' => 'client-fingerprint',
            'ws-opts' => 'ws-opts',
            'grpc-opts' => 'grpc-opts',
            'h2-opts' => 'h2-opts',
        ],
        'vless' => [
            'uuid' => 'uuid',
            'flow' => 'flow',
            'udp' => 'udp',
            'network' => 'network',
            'tls' => 'tls',
            'server-name' => 'servername',
            'skip-cert-verify' => 'skip-cert-verify',
            'client-fingerprint' => 'client-fingerprint',
            'ws-opts' => 'ws-opts',
            'grpc-opts' => 'grpc-opts',
            'h2-opts' => 'h2-opts',
            'reality-opts' => 'reality-opts',
        ],
        'trojan' => [
            'password' => 'password',
            'udp' => 'udp',
            'network' => 'network',
            'server-name' => 'sni',
            'skip-cert-verify' => 'skip-cert-verify',
            'client-fingerprint' => 'client-fingerprint',
            'alpn' => 'alpn',
            'ws-opts' => 'ws-opts',
            'grpc-opts' => 'grpc-opts',
        ],
        'http' => [
            'username' => 'username',
            'password' => 'password',
            'tls' => 'tls',
            'server-name' => 'sni',
            'skip-cert-verify' => 'skip-cert-verify',
        ],
        'https' => [
            'username' => 'username',
            'password' => 'password',
            'tls' => 'tls',
            'server-name' => 'sni',
            'skip-cert-verify' => 'skip-cert-verify',
        ],
    ];

    /**
     * 检查节点 TCP 可达状态。
     * @param string $host 服务器域名或IP地址
     * @param int $port 服务器端口
     * @param float $timeout 连接超时时间，单位秒
     * @return bool 是否可达
     */
    public static function check( string $host, int $port, float $timeout = 3.0 ): bool {
        if ( $host === '' || $port < 1 || $port > 65535 ) { return false; }
        $target = filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 )
            ? "tcp://[{$host}]:{$port}"
            : "tcp://{$host}:{$port}";
        $errorCode = 0;
        $errorMessage = '';
        $connection = @stream_socket_client(
            $target,
            $errorCode,
            $errorMessage,
            $timeout,
            STREAM_CLIENT_CONNECT,
        );
        if ( $connection === false ) { return false; }
        fclose( $connection );
        return true;
    }

    /**
     * 生成 Clash 节点配置。
     * config 可通过 clash 对象追加或覆盖输出字段。
     * @param array<string, mixed> $node 节点数据数组
     * @return string Clash YAML 节点数据
     */
    public static function getClashNode( array $node ): string {
        $type = strtolower( trim( (string) ( $node['type'] ?? '' ) ) );
        if ( !isset( self::CLASH_FIELDS[$type] ) ) { return ''; }
        $config = self::normalizeConfig( $node['config'] ?? [] );
        if ( $type === 'https' ) { $config['tls'] = $config['tls'] ?? true; }
        $proxy = [
            'name' => (string) ( $node['name'] ?? '' ),
            'type' => $type === 'https' ? 'http' : $type,
            'server' => self::host( $node ),
            'port' => (int) ( $node['port'] ?? 0 ),
        ];
        foreach ( self::CLASH_FIELDS[$type] as $source => $target ) {
            if ( !array_key_exists( $source, $config ) || $config[$source] === null || $config[$source] === '' ) { continue; }
            $value = $source === 'tls' ? self::security( $config ) !== '' : $config[$source];
            $proxy[$target] = $value;
        }
        if ( isset( $config['clash'] ) && is_array( $config['clash'] ) ) {
            $proxy = array_replace_recursive( $proxy, $config['clash'] );
        }
        return self::yamlMap( $proxy, 2, true );
    }

    /**
     * 生成 V2Ray 兼容订阅分享链接。
     * @param array<string, mixed> $node 节点数据数组
     * @return string 分享链接
     */
    public static function getV2RayNode( array $node ): string {
        $type = strtolower( trim( (string) ( $node['type'] ?? '' ) ) );
        $config = self::normalizeConfig( $node['config'] ?? [] );
        return match ( $type ) {
            'ss' => self::buildSsUri( $node, $config ),
            'ssr' => self::buildSsrUri( $node, $config ),
            'vmess' => self::buildVmessUri( $node, $config ),
            'vless' => self::buildStandardUri( 'vless', $node, $config, 'uuid' ),
            'trojan' => self::buildStandardUri( 'trojan', $node, $config, 'password' ),
            'http', 'https' => self::buildHttpUri( $type, $node, $config ),
            default => '',
        };
    }

    /**
     * 生成 Quantumult X 原生节点配置。
     * @param array<string, mixed> $node 节点数据数组
     * @return string Quantumult X 节点配置
     */
    public static function getQuantumultXNode( array $node ): string {
        $type = strtolower( trim( (string) ( $node['type'] ?? '' ) ) );
        $config = self::normalizeConfig( $node['config'] ?? [] );
        $parameters = match ( $type ) {
            'ss' => self::quantumultXShadowsocks( $config ),
            'ssr' => self::quantumultXShadowsocksR( $config ),
            'vmess' => self::quantumultXVmess( $config ),
            'vless' => self::quantumultXVless( $config ),
            'trojan' => self::quantumultXTrojan( $config ),
            'http', 'https' => self::quantumultXHttp( $type, $config ),
            default => [],
        };
        if ( $parameters === [] ) { return ''; }
        if ( isset( $config['quantumultx'] ) && is_array( $config['quantumultx'] ) ) {
            $parameters = array_replace( $parameters, $config['quantumultx'] );
        }
        $parameters['tag'] = self::quantumultXValue( (string) ( $node['name'] ?? '' ) );
        $values = [];
        foreach ( $parameters as $key => $value ) {
            if ( $value === null || $value === '' ) { continue; }
            $values[] = "{$key}=".self::quantumultXValue( $value );
        }
        $server = self::formatHost( self::host( $node ) );
        $port = (int) ( $node['port'] ?? 0 );
        $protocol = match ( $type ) {
            'ss', 'ssr' => 'shadowsocks',
            'https' => 'http',
            default => $type,
        };
        return "{$protocol}={$server}:{$port}, ".implode( ', ', $values );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXShadowsocks( array $config ): array {
        return array_replace( [
            'method' => $config['cipher'] ?? 'aes-256-gcm',
            'password' => $config['password'] ?? '',
        ], self::quantumultXTransport( $config ), self::quantumultXCommon( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXShadowsocksR( array $config ): array {
        return array_replace( [
            'method' => $config['cipher'] ?? 'aes-256-cfb',
            'password' => $config['password'] ?? '',
            'ssr-protocol' => $config['protocol'] ?? 'origin',
            'ssr-protocol-param' => $config['protocol-param'] ?? null,
            'obfs' => $config['obfs'] ?? 'plain',
            'obfs-host' => $config['obfs-param'] ?? null,
        ], self::quantumultXCommon( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXVmess( array $config ): array {
        $cipher = (string) ( $config['cipher'] ?? 'none' );
        if ( $cipher === 'auto' ) { $cipher = 'none'; }
        return array_replace( [
            'method' => $cipher,
            'password' => $config['uuid'] ?? '',
        ], self::quantumultXTransport( $config ), self::quantumultXCommon( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXVless( array $config ): array {
        return array_replace( [
            'method' => 'none',
            'password' => $config['uuid'] ?? '',
            'vless-flow' => $config['flow'] ?? null,
        ], self::quantumultXTransport( $config ), self::quantumultXCommon( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXTrojan( array $config ): array {
        $parameters = ['password' => $config['password'] ?? ''];
        if ( ( $config['network'] ?? 'tcp' ) === 'ws' ) {
            $transport = self::quantumultXTransport( $config, true );
        }else {
            $transport = array_replace( [
                'over-tls' => true,
                'tls-host' => $config['server-name'] ?? null,
                'tls-verification' => !(bool) ( $config['skip-cert-verify'] ?? false ),
            ], self::quantumultXReality( $config ) );
        }
        return array_replace( $parameters, $transport, self::quantumultXCommon( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXHttp( string $type, array $config ): array {
        $tls = $type === 'https' || self::security( $config ) !== '';
        return array_replace( [
            'username' => $config['username'] ?? null,
            'password' => $config['password'] ?? null,
            'over-tls' => $tls ?: null,
            'tls-host' => $tls ? ( $config['server-name'] ?? null ) : null,
            'tls-verification' => $tls ? !(bool) ( $config['skip-cert-verify'] ?? false ) : null,
        ], self::quantumultXReality( $config ), self::quantumultXCommon( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXTransport( array $config, bool $trojan = false ): array {
        $network = (string) ( $config['network'] ?? 'tcp' );
        $tls = self::security( $config ) !== '' || $trojan;
        if ( $network === 'ws' ) {
            $options = is_array( $config['ws-opts'] ?? null ) ? $config['ws-opts'] : [];
            $headers = is_array( $options['headers'] ?? null ) ? $options['headers'] : [];
            return array_replace( [
                'obfs' => $tls ? 'wss' : 'ws',
                'obfs-host' => $headers['host'] ?? $headers['Host'] ?? $config['server-name'] ?? null,
                'obfs-uri' => $options['path'] ?? '/',
            ], self::quantumultXReality( $config ) );
        }
        if ( !$tls ) { return []; }
        return array_replace( [
            'obfs' => 'over-tls',
            'obfs-host' => $config['server-name'] ?? null,
            'tls-verification' => !(bool) ( $config['skip-cert-verify'] ?? false ),
        ], self::quantumultXReality( $config ) );
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXReality( array $config ): array {
        return [
            'reality-base64-pubkey' => $config['public-key'] ?? null,
            'reality-hex-shortid' => $config['short-id'] ?? null,
        ];
    }

    /** @param array<string, mixed> $config @return array<string, mixed> */
    private static function quantumultXCommon( array $config ): array {
        return [
            'fast-open' => (bool) ( $config['fast-open'] ?? false ),
            'udp-relay' => (bool) ( $config['udp'] ?? false ),
        ];
    }

    private static function quantumultXValue( mixed $value ): string {
        if ( is_bool( $value ) ) { return self::boolText( $value ); }
        return str_replace( ["\r", "\n", ','], ['', '', '，'], trim( (string) $value ) );
    }

    /**
     * 标准化节点配置。
     * @param mixed $config JSON 字符串或配置数组
     * @return array<string, mixed> 配置数组
     */
    private static function normalizeConfig( mixed $config ): array {
        if ( is_string( $config ) ) {
            try {
                $config = json_decode( $config, true, 512, JSON_THROW_ON_ERROR );
            }catch ( JsonException ) {
                return [];
            }
        }
        if ( !is_array( $config ) ) { return []; }
        $config['network'] = $config['network'] ?? 'tcp';
        if ( isset( $config['public-key'] ) || isset( $config['short-id'] ) ) {
            $reality = array_filter( [
                'public-key' => $config['public-key'] ?? null,
                'short-id' => $config['short-id'] ?? null,
            ], fn ( mixed $value ): bool => $value !== null && $value !== '' );
            $realityOptions = is_array( $config['reality-opts'] ?? null )
                ? $config['reality-opts']
                : [];
            $config['reality-opts'] = array_replace( $reality, $realityOptions );
        }
        return $config;
    }

    /**
     * 生成 Shadowsocks 分享链接。
     * @param array<string, mixed> $node 节点数据
     * @param array<string, mixed> $config 节点配置
     * @return string 分享链接
     */
    private static function buildSsUri( array $node, array $config ): string {
        $userInfo = self::base64UrlEncode( (string) ( $config['cipher'] ?? 'aes-256-gcm' ).':'.(string) ( $config['password'] ?? '' ) );
        $uri = 'ss://'.$userInfo.'@'.self::authority( $node );
        if ( !empty( $config['plugin'] ) ) {
            $options = $config['plugin-opts'] ?? '';
            if ( is_array( $options ) ) {
                $parts = [];
                foreach ( $options as $key => $value ) {
                    $parts[] = is_int( $key ) ? (string) $value : "{$key}={$value}";
                }
                $options = implode( ';', $parts );
            }
            $uri .= '?plugin='.rawurlencode( (string) $config['plugin'].( $options !== '' ? ";{$options}" : '' ) );
        }
        return $uri.'#'.rawurlencode( (string) ( $node['name'] ?? '' ) );
    }

    /**
     * 生成 ShadowsocksR 分享链接。
     * @param array<string, mixed> $node 节点数据
     * @param array<string, mixed> $config 节点配置
     * @return string 分享链接
     */
    private static function buildSsrUri( array $node, array $config ): string {
        $main = implode( ':', [
            self::formatHost( self::host( $node ) ),
            (int) ( $node['port'] ?? 0 ),
            (string) ( $config['protocol'] ?? 'origin' ),
            (string) ( $config['cipher'] ?? 'aes-256-cfb' ),
            (string) ( $config['obfs'] ?? 'plain' ),
            self::base64UrlEncode( (string) ( $config['password'] ?? '' ) ),
        ] );
        $parameters = ['remarks' => self::base64UrlEncode( (string) ( $node['name'] ?? '' ) )];
        if ( !empty( $config['protocol-param'] ) ) {
            $parameters['protoparam'] = self::base64UrlEncode( (string) $config['protocol-param'] );
        }
        if ( !empty( $config['obfs-param'] ) ) {
            $parameters['obfsparam'] = self::base64UrlEncode( (string) $config['obfs-param'] );
        }
        $query = http_build_query( $parameters, '', '&', PHP_QUERY_RFC3986 );
        return 'ssr://'.self::base64UrlEncode( "{$main}/?{$query}" );
    }

    /**
     * 生成 VMess 分享链接。
     * @param array<string, mixed> $node 节点数据
     * @param array<string, mixed> $config 节点配置
     * @return string 分享链接
     */
    private static function buildVmessUri( array $node, array $config ): string {
        $network = (string) ( $config['network'] ?? 'tcp' );
        $transport = self::transportQuery( $network, $config );
        $allowInsecure = (bool) ( $config['skip-cert-verify'] ?? false ) ? '1' : '0';
        $data = [
            'v' => (string) ( $config['v2ray'] ?? $config['v'] ?? '2' ),
            'ps' => (string) ( $node['name'] ?? '' ),
            'add' => self::host( $node ),
            'port' => (string) ( (int) ( $node['port'] ?? 0 ) ),
            'id' => (string) ( $config['uuid'] ?? '' ),
            'aid' => (string) ( (int) ( $config['alterId'] ?? 0 ) ),
            'scy' => (string) ( $config['cipher'] ?? 'auto' ),
            'net' => $network,
            'type' => (string) ( $config['header-type'] ?? $transport['headerType'] ?? 'none' ),
            'host' => (string) ( $transport['host'] ?? '' ),
            'path' => (string) ( $transport['path'] ?? $transport['serviceName'] ?? '' ),
            'tls' => self::security( $config ),
            'sni' => (string) ( $config['server-name'] ?? '' ),
            'alpn' => self::listValue( $config['alpn'] ?? '' ),
            'fp' => (string) ( $config['client-fingerprint'] ?? '' ),
            'allowInsecure' => $allowInsecure,
            'insecure' => $allowInsecure,
        ];
        $json = json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        return $json === false ? '' : 'vmess://'.base64_encode( $json );
    }

    /**
     * 生成 VLESS 或 Trojan 分享链接。
     * @param string $scheme 分享链接协议
     * @param array<string, mixed> $node 节点数据
     * @param array<string, mixed> $config 节点配置
     * @param string $credential 身份凭证字段
     * @return string 分享链接
     */
    private static function buildStandardUri( string $scheme, array $node, array $config, string $credential ): string {
        $network = (string) ( $config['network'] ?? 'tcp' );
        $query = self::transportQuery( $network, $config );
        $query['type'] = $network;
        $security = self::security( $config );
        if ( $scheme === 'trojan' && $security === '' ) { $security = 'tls'; }
        if ( $scheme === 'vless' ) { $query['encryption'] = (string) ( $config['encryption'] ?? 'none' ); }
        if ( $security !== '' ) { $query['security'] = $security; }
        $fields = [
            'flow' => 'flow',
            'server-name' => 'sni',
            'client-fingerprint' => 'fp',
            'public-key' => 'pbk',
            'short-id' => 'sid',
        ];
        foreach ( $fields as $source => $target ) {
            if ( !empty( $config[$source] ) ) { $query[$target] = $config[$source]; }
        }
        if ( isset( $config['skip-cert-verify'] ) ) {
            $query['allowInsecure'] = (bool) $config['skip-cert-verify'] ? '1' : '0';
        }
        if ( !empty( $config['alpn'] ) ) { $query['alpn'] = self::listValue( $config['alpn'] ); }
        if ( isset( $config['uri-query'] ) && is_array( $config['uri-query'] ) ) {
            $query = array_replace( $query, $config['uri-query'] );
        }
        $query = array_filter( $query, fn ( mixed $value ): bool => $value !== null && $value !== '' );
        $queryString = http_build_query( $query, '', '&', PHP_QUERY_RFC3986 );
        $identity = rawurlencode( (string) ( $config[$credential] ?? '' ) );
        $name = rawurlencode( (string) ( $node['name'] ?? '' ) );
        return "{$scheme}://{$identity}@".self::authority( $node )."?{$queryString}#{$name}";
    }

    /**
     * 生成 HTTP 或 HTTPS 分享链接。
     * @param string $scheme 分享链接协议
     * @param array<string, mixed> $node 节点数据
     * @param array<string, mixed> $config 节点配置
     * @return string 分享链接
     */
    private static function buildHttpUri( string $scheme, array $node, array $config ): string {
        $username = (string) ( $config['username'] ?? '' );
        $password = (string) ( $config['password'] ?? '' );
        $credentials = '';
        if ( $username !== '' || $password !== '' ) {
            $credentials = rawurlencode( $username ).':'.rawurlencode( $password ).'@';
        }
        $name = rawurlencode( (string) ( $node['name'] ?? '' ) );
        return "{$scheme}://{$credentials}".self::authority( $node )."#{$name}";
    }

    /**
     * 获取分享链接使用的传输层查询参数。
     * @param string $network 传输类型
     * @param array<string, mixed> $config 节点配置
     * @return array<string, mixed> 查询参数
     */
    private static function transportQuery( string $network, array $config ): array {
        $options = match ( $network ) {
            'ws' => $config['ws-opts'] ?? [],
            'grpc' => $config['grpc-opts'] ?? [],
            'h2', 'http' => $config['h2-opts'] ?? [],
            default => [],
        };
        if ( !is_array( $options ) ) { $options = []; }
        $headers = is_array( $options['headers'] ?? null ) ? $options['headers'] : [];
        return match ( $network ) {
            'ws' => [
                'path' => $options['path'] ?? '/',
                'host' => $headers['host'] ?? $headers['Host'] ?? '',
            ],
            'grpc' => [
                'serviceName' => $options['grpc-service-name'] ?? '',
            ],
            'h2', 'http' => [
                'path' => self::firstPath( $options['path'] ?? '/' ),
                'host' => self::listValue( $options['host'] ?? '' ),
            ],
            'kcp', 'quic' => [
                'headerType' => $config['header-type'] ?? 'none',
            ],
            default => [],
        };
    }

    /**
     * 获取分享链接的安全类型。
     * @param array<string, mixed> $config 节点配置
     * @return string 安全类型，未启用时返回空字符串
     */
    private static function security( array $config ): string {
        $tls = $config['tls'] ?? '';
        if ( $tls === true || $tls === 1 || $tls === '1' ) { return 'tls'; }
        if ( $tls === false || $tls === 0 || $tls === '0' || $tls === 'none' ) { return ''; }
        return (string) $tls;
    }

    /** @param array<string, mixed> $node */
    private static function authority( array $node ): string {
        $port = (int) ( $node['port'] ?? 0 );
        return self::formatHost( self::host( $node ) ).":{$port}";
    }

    /** @param array<string, mixed> $node */
    private static function host( array $node ): string {
        return trim( (string) ( $node['server'] ?? '' ), '[]' );
    }

    private static function formatHost( string $host ): string {
        if ( filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) { return "[{$host}]"; }
        return $host;
    }

    private static function firstPath( mixed $path ): string {
        if ( is_array( $path ) ) { return (string) ( $path[0] ?? '/' ); }
        return (string) $path;
    }

    private static function boolText( bool $value ): string { return $value ? 'true' : 'false'; }

    private static function listValue( mixed $value ): string {
        if ( is_array( $value ) ) { return implode( ',', array_map( 'strval', $value ) ); }
        return (string) $value;
    }

    private static function base64UrlEncode( string $value ): string {
        return rtrim( strtr( base64_encode( $value ), '+/', '-_' ), '=' );
    }

    /**
     * 将关联数组转换成 YAML 映射。
     * @param array<string, mixed> $values 配置数组
     * @param int $indent 缩进空格数
     * @param bool $listItem 是否为列表首项
     * @return string YAML 文本
     */
    private static function yamlMap( array $values, int $indent, bool $listItem = false ): string {
        $lines = [];
        foreach ( $values as $key => $value ) {
            $prefix = str_repeat( ' ', $indent ).( $listItem ? '- ' : '' );
            if ( $listItem ) { $indent += 2; $listItem = false; }
            if ( is_array( $value ) ) {
                $lines[] = "{$prefix}{$key}:";
                $lines[] = array_is_list( $value )
                    ? self::yamlList( $value, $indent + 2 )
                    : self::yamlMap( $value, $indent + 2 );
                continue;
            }
            $lines[] = "{$prefix}{$key}: ".self::yamlScalar( $value );
        }
        return implode( "\n", array_filter( $lines, fn ( string $line ): bool => $line !== '' ) );
    }

    /**
     * 将索引数组转换成 YAML 列表。
     * @param array<int, mixed> $values 配置列表
     * @param int $indent 缩进空格数
     * @return string YAML 文本
     */
    private static function yamlList( array $values, int $indent ): string {
        $lines = [];
        foreach ( $values as $value ) {
            $lines[] = is_array( $value )
                ? self::yamlMap( $value, $indent, true )
                : str_repeat( ' ', $indent ).'- '.self::yamlScalar( $value );
        }
        return implode( "\n", $lines );
    }

    private static function yamlScalar( mixed $value ): string {
        if ( is_bool( $value ) ) { return self::boolText( $value ); }
        if ( is_int( $value ) || is_float( $value ) ) { return (string) $value; }
        if ( $value === null ) { return 'null'; }
        return json_encode( (string) $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ?: '""';
    }
}
