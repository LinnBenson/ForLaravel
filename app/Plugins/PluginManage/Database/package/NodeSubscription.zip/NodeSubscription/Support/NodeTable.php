<?php

namespace App\Plugins\NodeSubscription\Support;

use App\Filament\Concerns\HasNavigationLevel;
use App\Plugins\NodeSubscription\Models\Node;
use App\Plugins\NodeSubscription\Models\Subscription;
use BackedEnum;
use chillerlan\QRCode\QRCode;
use Closure;
use Filament\Actions\Action;
use Filament\Actions\ActionGroup;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\CreateAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use RuntimeException;
use Throwable;
use UnitEnum;

/**
 * NodeTable
 * 节点订阅器统一管理页面。
 * @package App\Plugins\NodeSubscription\Support
 */
class NodeTable extends Page implements HasTable {
    use HasNavigationLevel {
        canAccess as protected canAccessByNavigationLevel;
    }
    use InteractsWithTable;

    protected static string $navigationPermission = 'node_subscription_nodes';
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedServerStack;
    protected static ?string $slug = 'node-subscription';
    protected static ?int $navigationSort = 20;
    protected string $view = 'NodeSubscription::node-table';

    public string $activeTab = 'subscriptions';
    /** @var array<int, string> */
    public array $templateFiles = [];
    public ?string $selectedTemplate = null;
    public string $templateContent = '';

    /**
     * 初始化管理栏目。
     * @return void
     */
    public function mount(): void {
        $tab = (string) request()->query( 'tab', 'subscriptions' );
        $this->activeTab = in_array( $tab, ['subscriptions', 'nodes', 'settings'], true ) ? $tab : 'subscriptions';
        if ( $this->activeTab === 'settings' ) { $this->loadTemplateFiles(); }
    }

    /**
     * 选择模板文件。
     * @param string $fileName TXT 文件名称
     * @return void
     */
    public function selectTemplate( string $fileName ): void {
        $path = $this->resolveTemplatePath( $fileName );
        $content = file_get_contents( $path );
        if ( $content === false ) {
            Notification::make()->title( '模板文件读取失败' )->danger()->send();
            return;
        }
        $this->selectedTemplate = $fileName;
        $this->templateContent = $content;
    }

    /**
     * 保存当前模板文件。
     * 使用同目录临时文件原子替换目标文件。
     * @return void
     */
    public function saveTemplate(): void {
        $this->validate( [
            'selectedTemplate' => ['required', 'string'],
            'templateContent' => ['string', 'max:2097152'],
        ] );
        try {
            $path = $this->resolveTemplatePath( (string) $this->selectedTemplate );
            $temporaryPath = tempnam( $this->templateDirectory(), '.template-' );
            if ( $temporaryPath === false ) { throw new RuntimeException( 'Unable to create the template temporary file.' ); }
            try {
                if ( file_put_contents( $temporaryPath, $this->templateContent, LOCK_EX ) === false ) {
                    throw new RuntimeException( 'Unable to write the template temporary file.' );
                }
                chmod( $temporaryPath, 0660 );
                if ( !rename( $temporaryPath, $path ) ) {
                    throw new RuntimeException( 'Unable to replace the template file.' );
                }
            }finally {
                if ( is_file( $temporaryPath ) ) { unlink( $temporaryPath ); }
            }
            Notification::make()->title( '模板文件保存成功' )->success()->send();
        }catch ( Throwable $throwable ) {
            report( $throwable );
            Notification::make()->title( '模板文件保存失败' )->danger()->send();
        }
    }

    /**
     * 加载可编辑的 TXT 模板文件。
     * @return void
     */
    private function loadTemplateFiles(): void {
        $files = glob( $this->templateDirectory().'/*.txt' );
        $files = is_array( $files ) ? $files : [];
        $this->templateFiles = array_values( array_map( 'basename', $files ) );
        natcasesort( $this->templateFiles );
        $this->templateFiles = array_values( $this->templateFiles );
        if ( $this->templateFiles === [] ) { return; }
        $this->selectTemplate( $this->templateFiles[0] );
    }

    /**
     * 获取模板目录。
     * @return string 模板目录绝对路径
     */
    private function templateDirectory(): string { return dirname( __DIR__ ).'/Database/Template'; }

    /**
     * 解析并校验模板文件路径。
     * @param string $fileName TXT 文件名称
     * @return string 文件绝对路径
     */
    private function resolveTemplatePath( string $fileName ): string {
        if (
            basename( $fileName ) !== $fileName ||
            preg_match( '/^[A-Za-z0-9._-]+\.txt$/i', $fileName ) !== 1 ||
            !in_array( $fileName, $this->templateFiles, true )
        ) {
            throw new RuntimeException( 'Invalid template file.' );
        }
        $directory = realpath( $this->templateDirectory() );
        $path = realpath( $this->templateDirectory().DIRECTORY_SEPARATOR.$fileName );
        if ( $directory === false || $path === false || dirname( $path ) !== $directory || !is_file( $path ) ) {
            throw new RuntimeException( 'Template file not found.' );
        }
        return $path;
    }

    /**
     * 获取页面头部操作。
     * @return array<int, CreateAction> 头部操作按钮
     */
    protected function getHeaderActions(): array {
        if ( $this->activeTab === 'settings' ) { return []; }
        if ( $this->activeTab === 'subscriptions' ) {
            return [
                CreateAction::make()
                    ->label( '新增订阅' )
                    ->icon( Heroicon::OutlinedPlus )
                    ->model( Subscription::class )
                    ->schema( self::subscriptionFormSchema() )
                    ->createAnother( false )
                    ->modalHeading( '新增订阅' )
                    ->modalSubmitActionLabel( '创建' )
                    ->modalCancelActionLabel( '取消' )
                    ->modalWidth( '3xl' )
                    ->successNotificationTitle( '订阅创建成功' ),
            ];
        }
        return [
            CreateAction::make()
                ->label( '新增节点' )
                ->icon( Heroicon::OutlinedPlus )
                ->model( Node::class )
                ->schema( self::nodeFormSchema() )
                ->mutateDataUsing( fn ( array $data ): array => self::normalizeNodeFormData( $data ) )
                ->createAnother( false )
                ->modalHeading( '新增节点' )
                ->modalSubmitActionLabel( '创建' )
                ->modalCancelActionLabel( '取消' )
                ->modalWidth( '3xl' )
                ->successNotificationTitle( '节点创建成功' ),
        ];
    }

    /**
     * 判断是否允许访问管理页面。
     * @return bool 是否允许访问
     */
    public static function canAccess(): bool {
        return Node::schema()->hasTable( 'nodes' ) &&
            Subscription::schema()->hasTable( 'subscriptions' ) &&
            static::canAccessByNavigationLevel();
    }

    /**
     * 配置当前栏目数据表。
     * @param Table $table 表格实例
     * @return Table 表格实例
     */
    public function table( Table $table ): Table {
        return $this->activeTab === 'subscriptions'
            ? $this->subscriptionTable( $table )
            : $this->nodeTable( $table );
    }

    /**
     * 配置订阅列表。
     * @param Table $table 表格实例
     * @return Table 表格实例
     */
    private function subscriptionTable( Table $table ): Table {
        return $table
            ->query( Subscription::query() )
            ->defaultSort( 'id', 'desc' )
            ->columns( [
                TextColumn::make( 'id' )->label( 'ID' )->searchable()->sortable(),
                TextColumn::make( 'name' )->label( '订阅名称' )->searchable()->sortable(),
                TextColumn::make( 'list' )
                    ->label( '节点数量' )
                    ->getStateUsing( fn ( Subscription $record ): int => count( $record->list ?? [] ) ),
                TextColumn::make( 'password' )->label( '访问密码' )->formatStateUsing( fn ( string $state ): string => str_repeat( '•', strlen( $state ) ) ),
                ToggleColumn::make( 'status' )
                    ->label( '启用状态' )
                    ->sortable()
                    ->updateStateUsing( function ( bool $state, Subscription $record ): bool|array {
                        try {
                            $record->status = $state;
                            $record->saveOrFail();
                            Notification::make()
                                ->title( '订阅状态更新成功' )
                                ->body( "订阅 {$record->name} 已".( $state ? '启用' : '禁用' ).'。' )
                                ->success()
                                ->send();
                            return $state;
                        }catch ( Throwable $throwable ) {
                            report( $throwable );
                            Notification::make()
                                ->title( '订阅状态更新失败' )
                                ->body( '请稍后重试或查看系统日志。' )
                                ->danger()
                                ->send();
                            return ['error' => '订阅状态更新失败'];
                        }
                    } ),
                TextColumn::make( 'expired' )
                    ->label( '过期时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->placeholder( '永不过期' )
                    ->color( function ( Subscription $record ): string {
                        if ( $record->expired === null ) { return 'gray'; }
                        return $record->expired->isFuture() ? 'success' : 'danger';
                    } )
                    ->sortable(),
                TextColumn::make( 'created_at' )->label( '创建时间' )->dateTime( 'Y.m.d H:i:s' )->sortable(),
                TextColumn::make( 'updated_at' )
                    ->label( '更新时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable()
                    ->toggleable( isToggledHiddenByDefault: true ),
            ] )
            ->filters( [
                TernaryFilter::make( 'status' )
                    ->label( '启用状态' )
                    ->trueLabel( '仅启用' )
                    ->falseLabel( '仅禁用' )
                    ->placeholder( '全部状态' ),
                self::expirationFilter( '永不过期' ),
            ] )
            ->recordActions( [
                ActionGroup::make( [
                    self::subscriptionLinkAction(),
                    EditAction::make()
                        ->label( '编辑' )
                        ->schema( self::subscriptionFormSchema() )
                        ->modalHeading( '编辑订阅' )
                        ->modalSubmitActionLabel( '保存' )
                        ->modalCancelActionLabel( '取消' )
                        ->modalWidth( '3xl' )
                        ->successNotificationTitle( '订阅更新成功' ),
                    DeleteAction::make()
                        ->label( '删除' )
                        ->successNotificationTitle( '订阅删除成功' ),
                ] ),
            ] )
            ->recordActionsColumnLabel( '操作' )
            ->toolbarActions( [
                BulkActionGroup::make( [DeleteBulkAction::make()->label( '删除所选' )] ),
            ] )
            ->defaultPaginationPageOption( 25 )
            ->paginationPageOptions( [25, 50, 100] )
            ->emptyStateIcon( Heroicon::OutlinedQueueList )
            ->emptyStateHeading( '暂无订阅' )
            ->emptyStateDescription( '点击右上角“新增订阅”创建第一条节点订阅。' );
    }

    /**
     * 创建订阅链接操作。
     * 显示带访问令牌的 Clash 和 V2Ray 订阅地址。
     * @return Action 订阅链接操作
     */
    private static function subscriptionLinkAction(): Action {
        return Action::make( 'subscriptionLink' )
            ->label( '订阅链接' )
            ->icon( Heroicon::OutlinedLink )
            ->color( 'primary' )
            ->modalHeading( fn ( Subscription $record ): string => "{$record->name} · 订阅链接" )
            ->modalContent( fn ( Subscription $record ) => view(
                'NodeSubscription::subscription-link',
                [
                    'indexLink' => self::subscriptionUrl( $record, 'index' ),
                    'clashLink' => self::subscriptionUrl( $record, 'clash' ),
                    'v2rayLink' => self::subscriptionUrl( $record, 'v2ray' ),
                    'quantumultXLink' => self::subscriptionUrl( $record, 'quantumultx' ),
                ],
            ) )
            ->modalWidth( '3xl' )
            ->modalSubmitAction( false )
            ->modalCancelActionLabel( '关闭' );
    }

    /**
     * 生成带访问令牌的订阅地址。
     * @param Subscription $subscription 订阅记录
     * @param string $type 订阅类型
     * @return string 完整订阅地址
     */
    private static function subscriptionUrl( Subscription $subscription, string $type ): string {
        return route( 'plugins.node-subscription.index', [
            'uid' => $subscription->getKey(),
            'type' => $type,
            'token' => $subscription->password,
        ] );
    }

    /**
     * 配置节点列表。
     * @param Table $table 表格实例
     * @return Table 表格实例
     */
    private function nodeTable( Table $table ): Table {
        return $table
            ->query( Node::query() )
            ->defaultSort( 'id', 'desc' )
            ->columns( [
                TextColumn::make( 'id' )->label( 'ID' )->searchable()->sortable(),
                TextColumn::make( 'type' )
                    ->label( '节点类型' )
                    ->formatStateUsing( fn ( string $state ): string => Node::TYPES[$state] ?? strtoupper( $state ) )
                    ->badge()
                    ->sortable(),
                TextColumn::make( 'name' )->label( '节点名称' )->searchable()->sortable(),
                TextColumn::make( 'server' )
                    ->label( '服务器' )
                    ->searchable()
                    ->copyable()
                    ->copyMessage( '服务器地址已复制' ),
                TextColumn::make( 'port' )
                    ->label( '端口' )
                    ->formatStateUsing( fn ( int|string $state ): string => (string) $state )
                    ->searchable()
                    ->sortable(),
                ToggleColumn::make( 'status' )
                    ->label( '启用状态' )
                    ->sortable()
                    ->updateStateUsing( function ( bool $state, Node $record ): bool|array {
                        try {
                            $record->status = $state;
                            $record->saveOrFail();
                            Notification::make()
                                ->title( '节点状态更新成功' )
                                ->body( "节点 {$record->name} 已".( $state ? '启用' : '禁用' ).'。' )
                                ->success()
                                ->send();
                            return $state;
                        }catch ( Throwable $throwable ) {
                            report( $throwable );
                            Notification::make()
                                ->title( '节点状态更新失败' )
                                ->body( '请稍后重试或查看系统日志。' )
                                ->danger()
                                ->send();
                            return ['error' => '节点状态更新失败'];
                        }
                    } ),
                IconColumn::make( 'reachable' )
                    ->label( '节点状态' )
                    ->getStateUsing( fn ( Node $record ): bool => NodeService::check( $record->server, $record->port ) )
                    ->boolean()
                    ->tooltip( fn ( bool $state ): string => $state ? 'TCP 连接成功' : 'TCP 连接失败' ),
                TextColumn::make( 'expired' )
                    ->label( '过期时间' )
                    ->date( 'Y.m.d' )
                    ->placeholder( 'Unknown' )
                    ->color( function ( Node $record ): string {
                        if ( $record->expired === null ) { return 'gray'; }
                        return $record->expired->isFuture() ? 'success' : 'danger';
                    } )
                    ->sortable(),
                TextColumn::make( 'created_at' )
                    ->label( '创建时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable()
                    ->toggleable( isToggledHiddenByDefault: true ),
                TextColumn::make( 'updated_at' )
                    ->label( '更新时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable()
                    ->toggleable( isToggledHiddenByDefault: true ),
            ] )
            ->filters( [
                SelectFilter::make( 'type' )->label( '节点类型' )->options( Node::TYPES )->native( false ),
                TernaryFilter::make( 'status' )
                    ->label( '启用状态' )
                    ->trueLabel( '仅启用' )
                    ->falseLabel( '仅禁用' )
                    ->placeholder( '全部状态' ),
                self::expirationFilter( 'Unknown' ),
            ] )
            ->recordActions( [
                ActionGroup::make( [
                    self::nodeLinkAction(),
                    EditAction::make()
                        ->label( '编辑' )
                        ->schema( self::nodeFormSchema() )
                        ->mutateRecordDataUsing( function ( array $data ): array {
                            $data['config'] = json_encode(
                                $data['config'] ?? [],
                                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT,
                            ) ?: '{}';
                            return $data;
                        } )
                        ->mutateDataUsing( fn ( array $data ): array => self::normalizeNodeFormData( $data ) )
                        ->modalHeading( '编辑节点' )
                        ->modalSubmitActionLabel( '保存' )
                        ->modalCancelActionLabel( '取消' )
                        ->modalWidth( '3xl' )
                        ->successNotificationTitle( '节点更新成功' ),
                    DeleteAction::make()
                        ->label( '删除' )
                        ->successNotificationTitle( '节点删除成功' ),
                ] ),
            ] )
            ->recordActionsColumnLabel( '操作' )
            ->toolbarActions( [
                BulkActionGroup::make( [DeleteBulkAction::make()->label( '删除所选' )] ),
            ] )
            ->defaultPaginationPageOption( 25 )
            ->paginationPageOptions( [25, 50, 100] )
            ->emptyStateIcon( Heroicon::OutlinedServerStack )
            ->emptyStateHeading( '暂无节点' )
            ->emptyStateDescription( '点击右上角“新增节点”创建第一条代理节点。' );
    }

    /**
     * 创建过期时间筛选器。
     * @param string $emptyLabel 空过期时间选项文案
     * @return SelectFilter 过期时间筛选器
     */
    private static function expirationFilter( string $emptyLabel ): SelectFilter {
        return SelectFilter::make( 'expiration' )
            ->label( '过期时间' )
            ->options( [
                'unexpired' => '未过期',
                'expired' => '已过期',
                'empty' => $emptyLabel,
            ] )
            ->native( false )
            ->query( function ( Builder $query, array $data ): Builder {
                return match ( $data['value'] ?? null ) {
                    'unexpired' => $query->whereNotNull( 'expired' )->where( 'expired', '>', now() ),
                    'expired' => $query->whereNotNull( 'expired' )->where( 'expired', '<=', now() ),
                    'empty' => $query->whereNull( 'expired' ),
                    default => $query,
                };
            } );
    }

    /**
     * 创建节点链接操作。
     * 显示节点分享链接、复制按钮及二维码。
     * @return Action 节点链接操作
     */
    private static function nodeLinkAction(): Action {
        return Action::make( 'nodeLink' )
            ->label( '节点链接' )
            ->icon( Heroicon::OutlinedQrCode )
            ->color( 'primary' )
            ->modalHeading( fn ( Node $record ): string => "{$record->name} · 节点链接" )
            ->modalContent( function ( Node $record ) {
                $link = NodeService::getV2RayNode( $record->toArray() );
                return view( 'NodeSubscription::node-link', [
                    'link' => $link,
                    'qrCode' => ( new QRCode() )->render( $link ),
                ] );
            } )
            ->modalWidth( '2xl' )
            ->modalSubmitAction( false )
            ->modalCancelActionLabel( '关闭' );
    }

    /**
     * 获取订阅表单结构。
     * @return array<int, Select|TextInput|DateTimePicker> 表单组件
     */
    private static function subscriptionFormSchema(): array {
        return [
            TextInput::make( 'name' )->label( '订阅名称' )->maxLength( 255 )->required(),
            Select::make( 'list' )
                ->label( '节点列表' )
                ->options( fn (): array => Node::query()->orderBy( 'name' )->pluck( 'name', 'id' )->all() )
                ->multiple()
                ->searchable()
                ->preload()
                ->native( false )
                ->required()
                ->columnSpanFull(),
            TextInput::make( 'password' )
                ->label( '访问密码' )
                ->password()
                ->revealable()
                ->required()
                ->minLength( 6 )
                ->maxLength( 255 ),
            Toggle::make( 'status' )
                ->label( '启用状态' )
                ->default( true )
                ->inline( false ),
            DateTimePicker::make( 'expired' )
                ->label( '过期时间' )
                ->displayFormat( 'Y.m.d H:i:s' )
                ->seconds( true )
                ->native( false )
                ->nullable(),
        ];
    }

    /**
     * 获取节点表单结构。
     * @return array<int, Select|TextInput|Toggle|Textarea|DatePicker> 表单组件
     */
    private static function nodeFormSchema(): array {
        return [
            Select::make( 'type' )->label( '节点类型' )->options( Node::TYPES )->native( false )->required(),
            TextInput::make( 'name' )->label( '节点名称' )->maxLength( 255 )->required(),
            TextInput::make( 'server' )
                ->label( '服务器' )
                ->placeholder( '域名、IPv4 或 IPv6 地址' )
                ->maxLength( 255 )
                ->required(),
            TextInput::make( 'port' )->label( '端口号' )->numeric()->integer()->minValue( 1 )->maxValue( 65535 )->required(),
            Toggle::make( 'status' )->label( '启用状态' )->default( true )->inline( false ),
            DatePicker::make( 'expired' )
                ->label( '过期时间' )
                ->displayFormat( 'Y.m.d' )
                ->native( false )
                ->nullable(),
            Textarea::make( 'config' )
                ->label( '配置信息' )
                ->helperText( '请输入合法的 JSON 对象，例如：{"uuid":"...","network":"ws"}' )
                ->default( '{}' )
                ->rows( 14 )
                ->rules( [
                    'json',
                    function (): Closure {
                        return function ( string $attribute, mixed $value, Closure $fail ): void {
                            if ( !is_string( $value ) || !str_starts_with( ltrim( $value ), '{' ) ) {
                                $fail( '配置信息必须是 JSON 对象。' );
                            }
                        };
                    },
                ] )
                ->validationMessages( ['json' => '配置信息必须是合法的 JSON。'] )
                ->required()
                ->columnSpanFull(),
        ];
    }

    /**
     * 标准化节点表单数据。
     * @param array<string, mixed> $data 表单数据
     * @return array<string, mixed> 标准化数据
     */
    private static function normalizeNodeFormData( array $data ): array {
        $data['config'] = json_decode( (string) ( $data['config'] ?? '{}' ), true, 512, JSON_THROW_ON_ERROR );
        return $data;
    }

    /**
     * 页面信息。
     */
    public function getBreadcrumbs(): array { return [__( 'filament.groups.other' ), '节点订阅器']; }
    public static function getNavigationLabel(): string { return '节点订阅器'; }
    public function getTitle(): string {
        return match( $this->activeTab ) {
            'nodes' => '节点列表',
            'settings' => '其它配置',
            default => '订阅列表',
        };
    }
    public static function getNavigationGroup(): string|UnitEnum|null { return __( 'filament.groups.other' ); }
}
