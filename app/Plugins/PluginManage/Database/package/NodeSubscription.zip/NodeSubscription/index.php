<?php

use App\Filament\Concerns\AdminLevel;
use App\Plugins\NodeSubscription\Controllers\AdminController;
use App\Plugins\NodeSubscription\Controllers\SubscriptionController;
use App\Providers\PluginProvider;
use App\Plugins\NodeSubscription\Models\Node;
use App\Plugins\NodeSubscription\Models\Subscription;
use App\Plugins\NodeSubscription\Support\NodeTable;
use Filament\Panel;
use Illuminate\Support\Facades\Route;

/**
 * Node Subscription Plugin
 * 提供多类型代理节点的保存与订阅能力。
 */
return new class extends PluginProvider {
    /**
     * 插件信息
     */
    public function __construct() {
        $this->name = '节点订阅器';
        $this->description = '多类型可编辑的节点订阅管理工具';
        $this->version = '1.1.7';
        $this->author = 'System';
        $this->source = 'https://github.com/LinnBenson/NodeSubscription/archive/refs/heads/main.zip';
        $this->relyPlugin = [
            'ToView' => '^1.0.7'
        ];
    }

    /**
     * 注册插件 Hook。
     * @return void
     */
    public function boot(): void {
        $this->hook( 'APP_SERVICE_PROVIDER_BOOT', 'register' );
        $this->hook( 'ADMIN_PANEL_PROVIDER_PANEL', 'registerAdminPage' );
    }

    /**
     * 注册插件管理路由。
     * @return void
     */
    public function register(): void {
        $databasePath = "{$this->path}Database/database.sqlite";
        if ( !file_exists( $databasePath ) && file_put_contents( $databasePath, '' ) === false ) {
            throw new RuntimeException( 'Unable to create the SQLite database file.' );
        }
        config()->set( 'database.connections.node_subscription', [
            'driver' => 'sqlite',
            'url' => null,
            'database' => $databasePath,
            'prefix' => 'Todu_',
            'foreign_key_constraints' => true,
            'busy_timeout' => 5000,
            'journal_mode' => 'WAL',
            'synchronous' => 'NORMAL',
        ]);
        app( 'view' )->addNamespace( 'NodeSubscription', "{$this->path}Views" );
        Route::middleware( AdminLevel::class )
            ->prefix( config( 'app.admin_path' ).'/plugins/node-subscription' )
            ->name( 'plugins.node-subscription.' )
            ->group( function (): void {
                Route::post( '/rebuild-tables', [AdminController::class, 'rebuild'] )->name( 'rebuild-tables' );
            } );
        Route::middleware( 'web' )
            ->prefix( $this->config( 'entrance' ) )
            ->name( 'plugins.node-subscription.' )
            ->group( function (): void {
                Route::any( '{uid}/{type}', [SubscriptionController::class, 'index'] )->name( 'index' );
            });
    }

    /**
     * 注册后台节点管理页面。
     * @param Panel $panel Filament 面板
     * @return void
     */
    public function registerAdminPage( Panel $panel ): void {
        config()->set( 'filament.navigation_levels.node_subscription_nodes', config( 'filament.navigation_levels.plugin_management', 99990 ) );
        $panel->pages( [
            NodeTable::class,
        ] );
    }

    /**
     * 安装插件。
     * 创建节点数据表。
     * @return bool 安装成功返回 true
     */
    public function install(): bool {
        $this->register();
        Node::up();
        Subscription::up();
        return true;
    }

    /**
     * 卸载插件。
     * 删除节点数据表。
     * @return bool 卸载成功返回 true
     */
    public function uninstall(): bool {
        $this->register();
        Subscription::down();
        Node::down();
        return true;
    }
};
