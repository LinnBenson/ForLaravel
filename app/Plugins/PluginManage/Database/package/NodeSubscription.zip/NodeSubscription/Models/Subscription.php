<?php

namespace App\Plugins\NodeSubscription\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Eloquent\Collection;

/**
 * Subscription
 * 节点订阅数据模型。
 * @package App\Plugins\NodeSubscription\Models
 */
class Subscription extends Model {
    protected $connection = Node::CONNECTION;

    protected $table = 'subscriptions';

    protected $casts = [
        'list' => 'array',
        'status' => 'boolean',
        'expired' => 'datetime',
    ];

    /** @var array<int, string> */
    protected $fillable = [
        'name',
        'list',
        'password',
        'status',
        'expired',
    ];

    /**
     * 获取插件数据库结构构建器。
     * @return Builder 数据库结构构建器
     */
    public static function schema(): Builder {
        return Schema::connection( Node::CONNECTION );
    }

    /**
     * 获取订阅关联的节点。
     * @return Collection<int, Node> 已启用节点集合
     */
    public function getNodes() {
        $nodeIds = array_values( array_unique( array_map(
            'intval',
            is_array( $this->list ) ? $this->list : []
        )));
        if ( $nodeIds === [] ) { return new Collection(); }
        $nodeOrder = array_flip( $nodeIds );
        return Node::query()
            ->whereIn( 'id', $nodeIds )
            ->where( 'status', true )
            ->get()
            ->sortBy( fn ( Node $node ): int => $nodeOrder[(int) $node->getKey()] ?? PHP_INT_MAX )
            ->values();
    }

    /**
     * 安装订阅数据表。
     * @return void
     */
    public static function up(): void {
        $schema = self::schema();
        if ( $schema->hasTable( 'subscriptions' ) ) { return; }
        $schema->create( 'subscriptions', function ( Blueprint $table ): void {
            $table->id()->comment( '订阅ID' );
            $table->string( 'name' )->comment( '订阅名称' );
            $table->text( 'list' )->comment( '节点ID列表JSON' );
            $table->string( 'password' )->comment( '访问密码' );
            $table->boolean( 'status' )->default( true )->comment( '启用状态：0禁用，1启用' );
            $table->timestamp( 'expired' )->nullable()->comment( '过期时间' );
            $table->timestamp( 'created_at' )->nullable()->comment( '创建时间' );
            $table->timestamp( 'updated_at' )->nullable()->comment( '更新时间' );

            $table->index( 'name' );
            $table->index( 'expired' );
        } );
    }

    /**
     * 卸载订阅数据表。
     * @return void
     */
    public static function down(): void {
        $schema = self::schema();
        if ( !$schema->hasTable( 'subscriptions' ) ) { return; }
        $schema->drop( 'subscriptions' );
    }
}
