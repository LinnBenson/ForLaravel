<?php

namespace App\Plugins\NodeSubscription\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;
use Illuminate\Support\Facades\Schema;

/**
 * Node
 * 代理节点数据模型。
 * @package App\Plugins\NodeSubscription\Models
 */
class Node extends Model {
    public const CONNECTION = 'node_subscription';

    public const TYPES = [
        'ss' => 'Shadowsocks',
        'ssr' => 'ShadowsocksR',
        'vmess' => 'VMess',
        'vless' => 'VLESS',
        'trojan' => 'Trojan',
        'http' => 'HTTP',
        'https' => 'HTTPS',
    ];

    protected $connection = self::CONNECTION;

    protected $table = 'nodes';

    protected $casts = [
        'port' => 'integer',
        'status' => 'boolean',
        'config' => 'array',
        'expired' => 'datetime',
    ];

    /** @var array<int, string> */
    protected $fillable = [
        'type',
        'name',
        'server',
        'port',
        'status',
        'config',
        'expired',
    ];

    /**
     * 获取插件数据库结构构建器。
     * @return Builder 数据库结构构建器
     */
    public static function schema(): Builder {
        return Schema::connection( self::CONNECTION );
    }

    /**
     * 安装节点数据表。
     * @return void
     */
    public static function up(): void {
        $schema = self::schema();
        if ( $schema->hasTable( 'nodes' ) ) { return; }
        $schema->create( 'nodes', function ( Blueprint $table ): void {
            $table->id()->comment( '节点ID' );
            $table->string( 'type', 16 )->comment( '节点类型' );
            $table->string( 'name' )->comment( '节点名称' );
            $table->string( 'server' )->comment( '服务器地址' );
            $table->unsignedInteger( 'port' )->comment( '端口号' );
            $table->boolean( 'status' )->default( true )->comment( '启用状态：0禁用，1启用' );
            $table->text( 'config' )->comment( '节点配置信息JSON' );
            $table->timestamp( 'expired' )->nullable()->comment( '过期时间' );
            $table->timestamp( 'created_at' )->nullable()->comment( '创建时间' );
            $table->timestamp( 'updated_at' )->nullable()->comment( '更新时间' );

            $table->index( ['type', 'status'] );
        } );
    }

    /**
     * 卸载节点数据表。
     * @return void
     */
    public static function down(): void {
        $schema = self::schema();
        if ( !$schema->hasTable( 'nodes' ) ) { return; }
        $schema->drop( 'nodes' );
    }
}
