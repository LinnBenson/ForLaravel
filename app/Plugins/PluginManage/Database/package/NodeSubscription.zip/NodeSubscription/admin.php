@php
    $tables = [
        'nodes' => \App\Plugins\NodeSubscription\Models\Node::schema()->hasTable( 'nodes' ),
        'subscriptions' => \App\Plugins\NodeSubscription\Models\Subscription::schema()->hasTable( 'subscriptions' ),
    ];
    $allInstalled = !in_array( false, $tables, true );
@endphp

{{-- 代理订阅工具数据表管理模块 --}}
<div
    class="node-subscription-database"
    x-data="{
        running: false,
        installed: @js( $allInstalled ),
        message: '',
        messageStatus: '',
        async rebuild() {
            if ( this.running ) { return; }
            if ( !confirm( '确定重建所有数据表吗？\n\n现有节点数据将被永久删除，此操作无法撤销。' ) ) { return; }
            this.running = true;
            this.message = '';
            this.messageStatus = '';
            try {
                const response = await fetch( `{{ url( config( 'app.admin_path' ).'/plugins/node-subscription/rebuild-tables' ) }}`, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': this.$refs.token.value,
                    },
                } );
                const data = await response.json();
                const succeeded = response.ok && data.status === 'success';
                this.installed = succeeded ? true : this.installed;
                this.messageStatus = succeeded ? 'success' : 'error';
                this.message = data.data?.message || data.message || '操作已完成。';
            }catch ( error ) {
                this.messageStatus = 'error';
                this.message = '请求失败，请稍后重试。';
            }finally {
                this.running = false;
            }
        },
    }"
>
    <input x-ref="token" type="hidden" value="{{ csrf_token() }}">

    <section class="node-subscription-database-card">
        <div class="node-subscription-database-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M4.5 6.75C4.5 5.507 7.858 4.5 12 4.5s7.5 1.007 7.5 2.25S16.142 9 12 9 4.5 7.993 4.5 6.75Zm0 0v5.625c0 1.243 3.358 2.25 7.5 2.25s7.5-1.007 7.5-2.25V6.75m-15 5.625V18c0 1.243 3.358 2.25 7.5 2.25s7.5-1.007 7.5-2.25v-5.625" />
            </svg>
        </div>
        <div class="node-subscription-database-content">
            <div class="node-subscription-database-heading">
                <div>
                    <span>数据存储</span>
                    <h2>插件数据表</h2>
                </div>
                <span class="node-subscription-database-status" x-bind:data-installed="installed">
                    <i></i>
                    <span x-text="installed ? '已安装' : '未完整安装'">{{ $allInstalled ? '已安装' : '未完整安装' }}</span>
                </span>
            </div>
            <p>用于保存订阅列表、节点列表及相关配置。重建会删除所有已有订阅和节点。</p>
            <button type="button" x-on:click="rebuild()" x-bind:disabled="running">
                <span x-show="running" class="node-subscription-database-spinner"></span>
                <span x-text="running ? '重建中…' : '重建所有数据表'">重建所有数据表</span>
            </button>
        </div>
    </section>

    <div
        class="node-subscription-database-message"
        x-cloak
        x-show="message !== ''"
        x-bind:data-status="messageStatus"
        x-text="message"
    ></div>
</div>

<style>
    /* 代理订阅工具数据表管理模块 */
    .node-subscription-database { display: flex; flex-direction: column; color: var(--gray-700); }
    .dark .node-subscription-database { color: var(--gray-300); }
    .node-subscription-database-card {
        display: flex;
        padding: 1.25rem;
        border: 1px solid var(--gray-200);
        border-radius: 1rem;
        background: white;
        gap: 1rem;
    }
    .dark .node-subscription-database-card { border-color: var(--gray-700); background: var(--gray-900); }
    .node-subscription-database-icon {
        display: flex;
        width: 3rem;
        height: 3rem;
        flex: 0 0 auto;
        border-radius: 0.8rem;
        background: color-mix(in srgb, var(--primary-500) 14%, transparent);
        color: var(--primary-600);
        align-items: center;
        justify-content: center;
    }
    .node-subscription-database-icon svg { width: 1.6rem; height: 1.6rem; }
    .node-subscription-database-content { min-width: 0; flex: 1; }
    .node-subscription-database-heading { display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; }
    .node-subscription-database-heading > div > span {
        color: var(--primary-600);
        font-size: 0.7rem;
        font-weight: 700;
        letter-spacing: 0.08em;
    }
    .node-subscription-database h2 { margin-top: 0.15rem; color: var(--gray-950); font-size: 1.15rem; font-weight: 700; }
    .dark .node-subscription-database h2 { color: white; }
    .node-subscription-database-content > p { margin: 0.55rem 0 1rem; color: var(--gray-600); font-size: 0.85rem; }
    .dark .node-subscription-database-content > p { color: var(--gray-400); }
    .node-subscription-database-status {
        display: inline-flex;
        padding: 0.3rem 0.6rem;
        border-radius: 9999px;
        background: var(--gray-100);
        color: var(--gray-600);
        align-items: center;
        gap: 0.4rem;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .dark .node-subscription-database-status { background: var(--gray-800); color: var(--gray-300); }
    .node-subscription-database-status i { width: 0.45rem; height: 0.45rem; border-radius: 50%; background: var(--gray-400); }
    .node-subscription-database-status[data-installed="true"] { background: color-mix(in srgb, var(--success-500) 12%, transparent); color: var(--success-700); }
    .node-subscription-database-status[data-installed="true"] i { background: var(--success-500); }
    .node-subscription-database button {
        display: inline-flex;
        min-height: 2.35rem;
        padding: 0.55rem 0.9rem;
        border: 0;
        border-radius: 0.6rem;
        background: var(--danger-600);
        color: white;
        align-items: center;
        justify-content: center;
        gap: 0.45rem;
        font-size: 0.82rem;
        font-weight: 650;
        cursor: pointer;
    }
    .node-subscription-database button:disabled { cursor: wait; opacity: 0.65; }
    .node-subscription-database-spinner { width: 0.9rem; height: 0.9rem; border: 2px solid rgba(255, 255, 255, 0.4); border-top-color: white; border-radius: 50%; animation: node-subscription-spin 0.7s linear infinite; }
    .node-subscription-database-message { margin-top: 0.75rem; padding: 0.7rem 0.85rem; border-radius: 0.6rem; font-size: 0.82rem; }
    .node-subscription-database-message[data-status="success"] { background: color-mix(in srgb, var(--success-500) 12%, transparent); color: var(--success-700); }
    .node-subscription-database-message[data-status="error"] { background: color-mix(in srgb, var(--danger-500) 12%, transparent); color: var(--danger-700); }
    @keyframes node-subscription-spin { to { transform: rotate(360deg); } }
    @media (max-width: 640px) {
        .node-subscription-database-card { padding: 1rem; }
        .node-subscription-database-icon { display: none; }
        .node-subscription-database button { width: 100%; }
    }
</style>
