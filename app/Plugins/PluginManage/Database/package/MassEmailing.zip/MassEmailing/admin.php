@php
    $mailTableInstalled = \App\Plugins\MassEmailing\Models\Mail::schema()->hasTable( 'mails' );
    $sendLogTableInstalled = \App\Plugins\MassEmailing\Models\SendLog::schema()->hasTable( 'send_logs' );
    $recipientTableInstalled = \App\Plugins\MassEmailing\Models\SendLogRecipient::schema()->hasTable( 'send_log_recipients' );
    $tableInstalled = $mailTableInstalled && $sendLogTableInstalled && $recipientTableInstalled;
@endphp

{{-- 邮件群发器数据表管理模块 --}}
<div
    class="mass-emailing-database"
    x-data="{
        running: false,
        installed: @js( $tableInstalled ),
        message: '',
        messageStatus: '',
        async rebuild() {
            if ( this.running ) { return; }
            if ( !confirm( '确定重建插件数据表吗？\n\n现有邮箱配置和发件日志将被永久删除，此操作无法撤销。' ) ) { return; }
            this.running = true;
            this.message = '';
            this.messageStatus = '';
            try {
                const response = await fetch( `{{ url( config( 'app.admin_path' ).'/plugins/mass-emailing/rebuild-tables' ) }}`, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': this.$refs.token.value,
                    },
                } );
                const data = await response.json();
                const succeeded = response.ok && data.status === 'success';
                this.installed = succeeded ? true : this.installed;
                this.messageStatus = succeeded ? 'success' : 'error';
                this.message = data.data?.message || data.message || '操作已完成。';
            }catch ( error ) {
                this.messageStatus = 'error';
                this.message = '请求失败，请稍后重试。';
            }finally {
                this.running = false;
            }
        },
    }"
>
    <input x-ref="token" type="hidden" value="{{ csrf_token() }}">

    <section class="mass-emailing-database-card">
        <div class="mass-emailing-database-content">
            <div class="mass-emailing-database-heading">
                <div>
                    <span>数据存储</span>
                    <h2>邮箱配置与发件日志表</h2>
                </div>
                <span class="mass-emailing-database-status" x-bind:data-installed="installed">
                    <i></i>
                    <span x-text="installed ? '已安装' : '未安装'">{{ $tableInstalled ? '已安装' : '未安装' }}</span>
                </span>
            </div>
            <p>用于保存邮箱服务器配置，以及发件内容、接收人、进度和发送报告。</p>
            <button type="button" x-on:click="rebuild()" x-bind:disabled="running">
                <span x-show="running" class="mass-emailing-database-spinner"></span>
                <span x-text="running ? '重建中…' : '重建插件数据表'">重建插件数据表</span>
            </button>
        </div>
    </section>

    <div
        class="mass-emailing-database-message"
        x-cloak
        x-show="message !== ''"
        x-bind:data-status="messageStatus"
        x-text="message"
    ></div>
</div>

<style>
    /* 邮件群发器数据表管理模块 */
    .mass-emailing-database { display: flex; flex-direction: column; color: var(--gray-700); }
    .dark .mass-emailing-database { color: var(--gray-300); }
    .mass-emailing-database-card { padding: 1.25rem; border: 1px solid var(--gray-200); border-radius: 1rem; background: white; }
    .dark .mass-emailing-database-card { border-color: var(--gray-700); background: var(--gray-900); }
    .mass-emailing-database-heading { display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; }
    .mass-emailing-database-heading > div > span { color: var(--primary-600); font-size: 0.7rem; font-weight: 700; letter-spacing: 0.08em; }
    .mass-emailing-database h2 { margin-top: 0.15rem; color: var(--gray-950); font-size: 1.15rem; font-weight: 700; }
    .dark .mass-emailing-database h2 { color: white; }
    .mass-emailing-database-content > p { margin: 0.55rem 0 1rem; color: var(--gray-600); font-size: 0.85rem; }
    .dark .mass-emailing-database-content > p { color: var(--gray-400); }
    .mass-emailing-database-status { display: inline-flex; padding: 0.3rem 0.6rem; border-radius: 9999px; background: var(--gray-100); color: var(--gray-600); align-items: center; gap: 0.4rem; font-size: 0.75rem; font-weight: 600; }
    .dark .mass-emailing-database-status { background: var(--gray-800); color: var(--gray-300); }
    .mass-emailing-database-status i { width: 0.45rem; height: 0.45rem; border-radius: 50%; background: var(--gray-400); }
    .mass-emailing-database-status[data-installed="true"] { background: color-mix(in srgb, var(--success-500) 12%, transparent); color: var(--success-700); }
    .mass-emailing-database-status[data-installed="true"] i { background: var(--success-500); }
    .mass-emailing-database button { display: inline-flex; min-height: 2.35rem; padding: 0.55rem 0.9rem; border: 0; border-radius: 0.6rem; background: var(--danger-600); color: white; align-items: center; justify-content: center; gap: 0.45rem; font-size: 0.82rem; font-weight: 650; cursor: pointer; }
    .mass-emailing-database button:disabled { cursor: wait; opacity: 0.65; }
    .mass-emailing-database-spinner { width: 0.9rem; height: 0.9rem; border: 2px solid rgba(255, 255, 255, 0.4); border-top-color: white; border-radius: 50%; animation: mass-emailing-spin 0.7s linear infinite; }
    .mass-emailing-database-message { margin-top: 0.75rem; padding: 0.7rem 0.85rem; border-radius: 0.6rem; font-size: 0.82rem; }
    .mass-emailing-database-message[data-status="success"] { background: color-mix(in srgb, var(--success-500) 12%, transparent); color: var(--success-700); }
    .mass-emailing-database-message[data-status="error"] { background: color-mix(in srgb, var(--danger-500) 12%, transparent); color: var(--danger-700); }
    @keyframes mass-emailing-spin { to { transform: rotate(360deg); } }
    @media (max-width: 640px) {
        .mass-emailing-database-heading { flex-direction: column; }
        .mass-emailing-database button { width: 100%; }
    }
</style>
