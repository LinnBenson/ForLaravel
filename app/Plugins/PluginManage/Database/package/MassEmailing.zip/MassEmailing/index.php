<?php

use App\Filament\Concerns\AdminLevel;
use App\Plugins\MassEmailing\Controllers\AdminController;
use App\Providers\PluginProvider;
use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Models\SendLogRecipient;
use App\Plugins\MassEmailing\Support\CheckConnectivityJob;
use App\Plugins\MassEmailing\Support\SendLogManagement;
use App\Plugins\MassEmailing\Support\SmtpManagement;
use Filament\Panel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;

/**
 * Mass Emailing
 * F2A 验证管理器
 */
return new class extends PluginProvider {
    /**
     * 插件信息
     */
    public function __construct() {
        $this->name = '邮件群发器';
        $this->description = '多邮件的群发工具';
        $this->version = '1.0.1';
        $this->author = 'Heisenberg';
        $this->setType( 1 );
    }

    /**
     * 注册插件 Hook。
     * @return void
     */
    public function boot(): void {
        $this->hook( 'APP_SERVICE_PROVIDER_BOOT', 'register' );
        $this->hook( 'ADMIN_PANEL_PROVIDER_PANEL', 'registerAdminPage' );
    }

    /**
     * 注册插件管理路由。
     * @return void
     */
    public function register(): void {
        $databasePath = "{$this->path}Database/database.sqlite";
        if ( !file_exists( $databasePath ) && file_put_contents( $databasePath, '' ) === false ) {
            throw new RuntimeException( 'Unable to create the SQLite database file.' );
        }
        config()->set( 'database.connections.mass_emailing', [
            'driver' => 'sqlite',
            'url' => null,
            'database' => $databasePath,
            'prefix' => 'Hsb_',
            'foreign_key_constraints' => true,
            'busy_timeout' => 5000,
            'journal_mode' => 'WAL',
            'synchronous' => 'NORMAL',
        ] );
        app( 'view' )->addNamespace( 'MassEmailing', "{$this->path}Views" );
        Route::middleware( AdminLevel::class.':70000' )
            ->prefix( config( 'app.admin_path' ).'/plugins/mass-emailing' )
            ->name( 'plugins.mass-emailing.' )
            ->group( function (): void {
                Route::post( '/rebuild-tables', [AdminController::class, 'rebuild'] )->name( 'rebuild-tables' );
            } );
    }

    /**
     * 注册 SMTP 管理与发件日志后台页面。
     * @param Panel $panel Filament 后台面板
     * @return void
     */
    public function registerAdminPage( Panel $panel ): void {
        config()->set( 'filament.navigation_levels.mass_emailing_smtp', 70000 );
        config()->set( 'filament.navigation_levels.mass_emailing_send_logs', 70000 );
        $panel->pages( [
            SmtpManagement::class,
            SendLogManagement::class,
        ] );
    }

    /**
     * 异步检测全部已启用 SMTP 的连通性。
     * @return bool 是否成功提交队列任务
     */
    public function CheckConnectivity(): bool {
        try {
            CheckConnectivityJob::dispatch();
            return true;
        }catch ( \Throwable $throwable ) {
            Log::error( 'SMTP 连通性检测任务提交失败。', [
                'exception' => $throwable::class,
                'message' => $throwable->getMessage(),
            ] );
            return false;
        }
    }

    /**
     * 安装插件。
     * 创建邮箱配置与发件日志数据表。
     * @return bool 安装成功返回 true
     */
    public function install(): bool {
        $this->register();
        Mail::up();
        SendLog::up();
        SendLogRecipient::up();
        return true;
    }

    /**
     * 卸载插件。
     * 删除邮箱配置与发件日志数据表。
     * @return bool 卸载成功返回 true
     */
    public function uninstall(): bool {
        $this->register();
        SendLogRecipient::down();
        SendLog::down();
        Mail::down();
        return true;
    }

};
