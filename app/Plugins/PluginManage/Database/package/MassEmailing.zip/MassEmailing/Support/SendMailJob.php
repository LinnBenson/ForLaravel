<?php

namespace App\Plugins\MassEmailing\Support;

use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Models\SendLogRecipient;
use App\Plugins\MassEmailing\Services\SmtpConnectivityService;
use App\Plugins\MassEmailing\Services\SmtpMailSendingService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * SendMailJob
 * 使用被分配的 SMTP 发送单个接收人的邮件。
 * @package App\Plugins\MassEmailing\Support
 */
class SendMailJob implements ShouldQueue {
    use Queueable;

    public int $tries = 1;
    public int $timeout = 45;

    private const MAX_ATTEMPTS = 3;

    public function __construct( private int $recipientId, private int $mailId ) {}

    /**
     * 执行单封邮件发送。
     * 同一个 SMTP 由队列锁保证同一时刻只发送一封。
     * @param SmtpMailSendingService $service SMTP 发件服务
     * @param SmtpConnectivityService $connectivityService SMTP 连通性检测服务
     * @return void
     */
    public function handle( SmtpMailSendingService $service, SmtpConnectivityService $connectivityService ): void {
        $recipient = SendLogRecipient::query()->with( 'sendLog' )->find( $this->recipientId );
        if ( !$recipient || !$recipient->sendLog || $recipient->status !== SendLog::REPORT_PENDING ) { return; }
        $mail = null;
        try {
            $mail = $this->resolveMail();
            $lock = Cache::lock( "mass-emailing-smtp-{$this->mailId}", 60 );
            if ( !$lock->get() ) {
                self::dispatch( $this->recipientId, $this->mailId )->delay( 1 );
                return;
            }
            try {
                $service->send( $mail, $recipient->sendLog, $recipient->recipient );
            }finally {
                $lock->release();
            }
            $this->complete( $recipient, SendLog::REPORT_SUCCESS );
        }catch ( Throwable $throwable ) {
            $this->refreshMailConnectivity( $mail, $connectivityService );
            $this->retryOrFail( $recipient, $throwable );
        }
    }

    /**
     * 发件失败后复检并更新当前 SMTP 连通状态。
     * 检测异常仅记录日志，不覆盖原始发件错误及后续重试流程。
     * @param Mail|null $mail 本次使用的 SMTP 配置
     * @param SmtpConnectivityService $service SMTP 连通性检测服务
     * @return void
     */
    private function refreshMailConnectivity( ?Mail $mail, SmtpConnectivityService $service ): void {
        if ( !$mail ) { return; }
        try {
            $service->check( $mail );
        }catch ( Throwable $throwable ) {
            Log::warning( '发件失败后的 SMTP 连通性复检未完成。', [
                'mail_id' => $mail->getKey(),
                'exception' => $throwable::class,
                'message' => $throwable->getMessage(),
            ] );
        }
    }

    /**
     * 获取当前 SMTP，失效时切换至下一个在线 SMTP。
     * @return Mail SMTP 配置
     */
    private function resolveMail(): Mail {
        $mail = Mail::query()
            ->whereKey( $this->mailId )
            ->where( 'status', true )
            ->where( 'connection_status', SmtpConnectivityService::STATUS_ONLINE )
            ->first();
        if ( $mail ) { return $mail; }
        $alternate = $this->nextMail();
        if ( !$alternate ) { throw new RuntimeException( '没有可用于发送的在线 SMTP 配置。' ); }
        $this->mailId = (int) $alternate->getKey();
        return $alternate;
    }

    /**
     * 发送失败时重试并切换 SMTP，达到上限后记录失败。
     * @param SendLogRecipient $recipient 接收人明细
     * @param Throwable $throwable 发送异常
     * @return void
     */
    private function retryOrFail( SendLogRecipient $recipient, Throwable $throwable ): void {
        $attempts = $recipient->attempts + 1;
        $error = Str::limit( preg_replace( '/[\x00-\x1F\x7F]+/u', ' ', $throwable->getMessage() ) ?? '发送失败', 1000, '' );
        if ( $attempts < self::MAX_ATTEMPTS ) {
            $alternate = $this->nextMail();
            if ( $alternate ) { $this->mailId = (int) $alternate->getKey(); }
            $recipient->forceFill( [
                'mail_id' => $this->mailId,
                'attempts' => $attempts,
                'error' => $error,
            ] )->save();
            self::dispatch( (int) $recipient->getKey(), $this->mailId )->delay( 5 );
            return;
        }
        $this->complete( $recipient, SendLog::REPORT_FAILED, $attempts, $error );
    }

    /**
     * 获取使用次数最少的其他在线 SMTP。
     * @return Mail|null 备用 SMTP
     */
    private function nextMail(): ?Mail {
        $mails = Mail::query()
            ->where( 'status', true )
            ->where( 'connection_status', SmtpConnectivityService::STATUS_ONLINE )
            ->orderBy( 'usage_count' )
            ->orderBy( 'id' )
            ->get();
        if ( $mails->isEmpty() ) { return null; }
        return $mails->first( fn ( Mail $mail ): bool => (int) $mail->getKey() !== $this->mailId ) ?? $mails->first();
    }

    /**
     * 保存单封结果并同步 SendLog JSON 报告和总体进度。
     * @param SendLogRecipient $recipient 接收人明细
     * @param int $status 发送状态
     * @param int|null $attempts 尝试次数
     * @param string|null $error 失败原因
     * @return void
     */
    private function complete( SendLogRecipient $recipient, int $status, ?int $attempts = null, ?string $error = null ): void {
        DB::connection( Mail::CONNECTION )->transaction( function () use ( $recipient, $status, $attempts, $error ): void {
            $recipient->forceFill( [
                'mail_id' => $this->mailId,
                'status' => $status,
                'attempts' => $attempts ?? $recipient->attempts + 1,
                'error' => $error,
                'sent_at' => now(),
            ] )->save();
            if ( $status === SendLog::REPORT_SUCCESS ) {
                Mail::query()->whereKey( $this->mailId )->increment( 'usage_count' );
            }
            $rows = SendLogRecipient::query()
                ->where( 'send_log_id', $recipient->send_log_id )
                ->get( ['recipient', 'status'] );
            $report = $rows->mapWithKeys( fn ( SendLogRecipient $row ): array => [$row->recipient => $row->status] )->all();
            SendLog::query()->whereKey( $recipient->send_log_id )->update( [
                'report' => json_encode( $report, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
                'schedule' => $rows->where( 'status', '!=', SendLog::REPORT_PENDING )->count(),
                'updated_at' => now(),
            ] );
        } );
    }
}
