<?php

namespace App\Plugins\MassEmailing\Support;

use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Services\SmtpConnectivityService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * CheckConnectivityJob
 * 调度并异步检测已启用 SMTP 配置的连通性。
 * @package App\Plugins\MassEmailing\Support
 */
class CheckConnectivityJob implements ShouldQueue {
    use Queueable;

    public int $tries = 1;

    public int $timeout = 30;

    public function __construct( private ?int $mailId = null ) {}

    /**
     * 执行全部 SMTP 连通性检测。
     * @param SmtpConnectivityService $service SMTP 连通性检测服务
     * @return void
     */
    public function handle( SmtpConnectivityService $service ): void {
        if ( $this->mailId === null ) {
            $this->dispatchEnabledMailJobs();
            return;
        }
        $mail = Mail::query()->find( $this->mailId );
        if ( !$mail || !$mail->status ) { return; }
        try {
            $service->check( $mail );
        }catch ( Throwable $throwable ) {
            Log::error( 'SMTP 异步连通性检测执行失败。', [
                'mail_id' => $this->mailId,
                'exception' => $throwable::class,
                'message' => $throwable->getMessage(),
            ] );
        }
    }

    /**
     * 为每个已启用 SMTP 配置派发独立检测任务。
     * @return void
     */
    private function dispatchEnabledMailJobs(): void {
        $dispatched = 0;
        Mail::query()->where( 'status', true )->eachById( function ( Mail $mail ) use ( &$dispatched ): void {
            self::dispatch( (int) $mail->getKey() );
            $dispatched++;
        } );
        Log::info( 'SMTP 连通性检测子任务派发完成。', ['dispatched' => $dispatched] );
    }
}
