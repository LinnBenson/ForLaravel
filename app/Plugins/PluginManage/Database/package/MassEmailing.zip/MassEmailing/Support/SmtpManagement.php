<?php

namespace App\Plugins\MassEmailing\Support;

use App\Filament\Concerns\HasNavigationLevel;
use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Services\SmtpBatchImportService;
use App\Plugins\MassEmailing\Services\SmtpConnectivityService;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\CreateAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Table;
use InvalidArgumentException;
use Throwable;
use UnitEnum;

/**
 * SmtpManagement
 * SMTP 邮箱服务器配置管理页面。
 * @package App\Plugins\MassEmailing\Support
 */
class SmtpManagement extends Page implements HasTable {
    use HasNavigationLevel {
        canAccess as protected canAccessByNavigationLevel;
    }
    use InteractsWithTable;

    protected static string $navigationPermission = 'mass_emailing_smtp';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedEnvelope;

    protected static ?string $slug = 'smtp-management';

    protected static ?int $navigationSort = 30;

    protected string $view = 'MassEmailing::smtp-management';

    /**
     * 获取页面头部操作。
     * @return array<int, Action|CreateAction> 头部操作列表
     */
    protected function getHeaderActions(): array {
        return [
            CreateAction::make()
                ->label( '新增 SMTP' )
                ->icon( Heroicon::OutlinedPlus )
                ->model( Mail::class )
                ->schema( self::formSchema() )
                ->createAnother( false )
                ->modalHeading( '新增 SMTP' )
                ->modalSubmitActionLabel( '创建' )
                ->modalCancelActionLabel( '取消' )
                ->modalWidth( '2xl' )
                ->successNotificationTitle( 'SMTP 创建成功' ),
            Action::make( 'batchImport' )
                ->label( '批量导入' )
                ->icon( Heroicon::OutlinedArrowUpTray )
                ->schema( [
                    Textarea::make( 'content' )
                        ->label( 'SMTP 配置' )
                        ->placeholder( "smtp.google.com|465|a@b.com|smtps|password\nsmtp.google.com|465|a1@b.com|smtps|password" )
                        ->helperText( '每行一条：服务器|端口|邮箱用户名|协议|密码；邮件名称自动取 @ 前的内容。' )
                        ->rows( 10 )
                        ->required(),
                ] )
                ->modalHeading( '批量导入 SMTP' )
                ->modalSubmitActionLabel( '开始导入' )
                ->modalCancelActionLabel( '取消' )
                ->modalWidth( '3xl' )
                ->action( fn ( array $data ): mixed => $this->batchImportSmtp( (string) $data['content'] ) ),
            Action::make( 'checkAll' )
                ->label( '检测全部' )
                ->icon( Heroicon::OutlinedSignal )
                ->requiresConfirmation()
                ->modalHeading( '检测全部 SMTP？' )
                ->modalDescription( '任务将在后台队列中检测所有已启用 SMTP 的连接、TLS 和账号认证。' )
                ->modalSubmitActionLabel( '提交任务' )
                ->modalCancelActionLabel( '取消' )
                ->action( fn (): mixed => $this->checkAllSmtp() ),
        ];
    }

    /**
     * 判断是否允许访问 SMTP 管理页面。
     * 数据表不存在时隐藏菜单并阻止页面查询。
     * @return bool 是否允许访问
     */
    public static function canAccess(): bool {
        return Mail::schema()->hasTable( 'mails' ) && static::canAccessByNavigationLevel();
    }

    /**
     * 配置 SMTP 管理表格。
     * @param Table $table Filament 表格
     * @return Table Filament 表格
     */
    public function table( Table $table ): Table {
        return $table
            ->query( Mail::query() )
            ->defaultSort( 'id', 'desc' )
            ->columns( [
                TextColumn::make( 'name' )
                    ->label( '邮件名称' )
                    ->searchable()
                    ->sortable(),
                TextColumn::make( 'server' )
                    ->label( '邮箱服务器' )
                    ->searchable()
                    ->copyable(),
                TextColumn::make( 'port' )
                    ->label( '端口' )
                    ->sortable(),
                TextColumn::make( 'username' )
                    ->label( '邮箱用户名' )
                    ->searchable()
                    ->copyable(),
                TextColumn::make( 'scheme' )
                    ->label( '邮箱协议' )
                    ->formatStateUsing( fn ( string $state ): string => strtoupper( $state ) )
                    ->badge()
                    ->sortable(),
                TextColumn::make( 'connection_status' )
                    ->label( '连通状态' )
                    ->formatStateUsing( fn ( string $state ): string => match ( $state ) {
                        SmtpConnectivityService::STATUS_ONLINE => '正常',
                        SmtpConnectivityService::STATUS_OFFLINE => '异常',
                        default => '未检测',
                    } )
                    ->badge()
                    ->color( fn ( string $state ): string => match ( $state ) {
                        SmtpConnectivityService::STATUS_ONLINE => 'success',
                        SmtpConnectivityService::STATUS_OFFLINE => 'danger',
                        default => 'gray',
                    } )
                    ->description( fn ( Mail $record ): ?string => $record->last_checked_at?->format( 'Y.m.d H:i:s' ) )
                    ->tooltip( fn ( Mail $record ): ?string => $record->last_error )
                    ->extraCellAttributes( ['class' => 'smtp-connection-status-cell'] )
                    ->sortable(),
                TextColumn::make( 'usage_count' )
                    ->label( '使用次数' )
                    ->numeric()
                    ->sortable(),
                ToggleColumn::make( 'status' )
                    ->label( '可用性' )
                    ->sortable(),
                TextColumn::make( 'created_at' )
                    ->label( '创建时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable(),
                TextColumn::make( 'updated_at' )
                    ->label( '更新时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable()
                    ->toggleable( isToggledHiddenByDefault: true ),
            ] )
            ->filters( [
                SelectFilter::make( 'scheme' )
                    ->label( '邮箱协议' )
                    ->options( self::schemeOptions() )
                    ->native( false ),
                TernaryFilter::make( 'status' )
                    ->label( '可用性' )
                    ->trueLabel( '可用' )
                    ->falseLabel( '不可用' )
                    ->placeholder( '全部状态' ),
            ] )
            ->recordActions( [
                Action::make( 'checkConnection' )
                    ->label( '检测' )
                    ->icon( Heroicon::OutlinedSignal )
                    ->color( 'primary' )
                    ->action( fn ( Mail $record ): mixed => $this->checkSmtp( $record ) ),
                EditAction::make()
                    ->label( '编辑' )
                    ->schema( self::formSchema() )
                    ->modalHeading( '编辑 SMTP' )
                    ->modalSubmitActionLabel( '保存' )
                    ->modalCancelActionLabel( '取消' )
                    ->modalWidth( '2xl' )
                    ->mutateDataUsing( function ( array $data ): array {
                        $data['connection_status'] = SmtpConnectivityService::STATUS_UNKNOWN;
                        $data['last_checked_at'] = null;
                        $data['last_error'] = null;
                        return $data;
                    } )
                    ->successNotificationTitle( 'SMTP 更新成功' ),
                DeleteAction::make()
                    ->label( '删除' ),
            ] )
            ->recordActionsColumnLabel( '操作' )
            ->toolbarActions( [
                BulkActionGroup::make( [
                    DeleteBulkAction::make()
                        ->label( '删除所选' ),
                ] ),
            ] )
            ->defaultPaginationPageOption( 25 )
            ->paginationPageOptions( [25, 50, 100] )
            ->emptyStateHeading( '暂无 SMTP 配置' )
            ->emptyStateDescription( '创建 SMTP 配置后，可用于邮件群发任务。' );
    }

    /**
     * 检测单个 SMTP 连通性。
     * @param Mail $mail SMTP 配置
     * @return void
     */
    public function checkSmtp( Mail $mail ): void {
        try {
            $result = app( SmtpConnectivityService::class )->check( $mail );
            Notification::make()
                ->title( $result['success'] ? 'SMTP 连通正常' : 'SMTP 连通异常' )
                ->body( "{$result['message']} 耗时 {$result['duration_ms']} ms" )
                ->color( $result['success'] ? 'success' : 'danger' )
                ->send();
        }catch ( Throwable $throwable ) {
            report( $throwable );
            Notification::make()->title( 'SMTP 检测失败' )->danger()->send();
        }
    }

    /**
     * 检测全部已启用 SMTP 连通性。
     * @return void
     */
    public function checkAllSmtp(): void {
        $queued = plugin( 'MassEmailing' )->CheckConnectivity();
        Notification::make()
            ->title( $queued ? 'SMTP 检测任务已提交' : 'SMTP 检测任务提交失败' )
            ->body( $queued ? '队列将依次检测所有已启用的 SMTP 配置。' : '请检查队列及系统日志后重试。' )
            ->color( $queued ? 'success' : 'danger' )
            ->send();
    }

    /**
     * 批量导入 SMTP 配置。
     * @param string $content SMTP 多行文本
     * @return void
     */
    public function batchImportSmtp( string $content ): void {
        try {
            $result = app( SmtpBatchImportService::class )->import( $content );
            Notification::make()
                ->title( 'SMTP 批量导入完成' )
                ->body( "成功导入 {$result['imported']} 条，跳过重复 {$result['skipped']} 条。" )
                ->success()
                ->send();
        }catch ( InvalidArgumentException $exception ) {
            Notification::make()
                ->title( 'SMTP 批量导入失败' )
                ->body( $exception->getMessage() )
                ->danger()
                ->send();
        }catch ( Throwable $throwable ) {
            report( $throwable );
            Notification::make()->title( 'SMTP 批量导入失败' )->danger()->send();
        }
    }

    /**
     * 获取 SMTP 表单结构。
     * @return array<int, TextInput|Select> 表单组件
     */
    private static function formSchema(): array {
        return [
            TextInput::make( 'name' )
                ->label( '邮件名称' )
                ->maxLength( 255 )
                ->required(),
            TextInput::make( 'server' )
                ->label( '邮箱服务器' )
                ->placeholder( 'smtp.example.com' )
                ->maxLength( 255 )
                ->required(),
            TextInput::make( 'port' )
                ->label( '邮箱端口' )
                ->numeric()
                ->minValue( 1 )
                ->maxValue( 65535 )
                ->default( 465 )
                ->required(),
            Select::make( 'scheme' )
                ->label( '邮箱协议' )
                ->options( self::schemeOptions() )
                ->default( 'smtps' )
                ->native( false )
                ->required(),
            TextInput::make( 'username' )
                ->label( '邮箱用户名' )
                ->maxLength( 255 )
                ->required(),
            TextInput::make( 'password' )
                ->label( '邮箱密码' )
                ->password()
                ->revealable()
                ->maxLength( 1000 )
                ->required(),
        ];
    }

    /**
     * 获取邮箱协议选项。
     * @return array<string, string> 邮箱协议选项
     */
    private static function schemeOptions(): array {
        return [
            'smtp' => 'SMTP',
            'smtps' => 'SMTPS',
            'tls' => 'TLS',
            'ssl' => 'SSL',
        ];
    }

    /**
     * 页面信息。
     */
    public function getBreadcrumbs(): array { return [__( 'filament.groups.other' ), 'SMTP 管理']; }
    public static function getNavigationLabel(): string { return 'SMTP 管理'; }
    public function getTitle(): string { return 'SMTP 管理'; }
    public static function getNavigationGroup(): string|UnitEnum|null { return __( 'filament.groups.other' ); }
}
