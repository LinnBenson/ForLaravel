<?php

namespace App\Plugins\MassEmailing\Support;

use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Models\SendLogRecipient;
use App\Plugins\MassEmailing\Services\SmtpConnectivityService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\Middleware\WithoutOverlapping;
use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * DispatchSendLogJob
 * 按 SMTP 轮询顺序分配接收人并派发单封发送任务。
 * @package App\Plugins\MassEmailing\Support
 */
class DispatchSendLogJob implements ShouldQueue {
    use Queueable;

    public int $tries = 1;
    public int $timeout = 60;

    public function __construct( private int $sendLogId ) {}

    /** @return array<int, WithoutOverlapping> 队列中间件 */
    public function middleware(): array {
        return [( new WithoutOverlapping( "mass-emailing-dispatch-{$this->sendLogId}" ) )->expireAfter( 120 )];
    }

    /**
     * 执行群发任务调度。
     * 第一轮依次使用所有 SMTP，之后再进入下一轮。
     * @return void
     */
    public function handle(): void {
        $sendLog = SendLog::query()->find( $this->sendLogId );
        if ( !$sendLog ) { return; }
        $mailIds = Mail::query()
            ->where( 'status', true )
            ->where( 'connection_status', SmtpConnectivityService::STATUS_ONLINE )
            ->orderBy( 'usage_count' )
            ->orderBy( 'id' )
            ->pluck( 'id' )
            ->map( fn ( int|string $id ): int => (int) $id )
            ->all();
        if ( $mailIds === [] ) { throw new RuntimeException( '没有可用于群发的在线 SMTP 配置。' ); }
        $index = 0;
        SendLogRecipient::query()
            ->where( 'send_log_id', $sendLog->getKey() )
            ->where( 'status', SendLog::REPORT_PENDING )
            ->orderBy( 'id' )
            ->eachById( function ( SendLogRecipient $recipient ) use ( $mailIds, &$index ): void {
                $mailId = $mailIds[$index % count( $mailIds )];
                $recipient->forceFill( ['mail_id' => $mailId] )->save();
                SendMailJob::dispatch( (int) $recipient->getKey(), $mailId );
                $index++;
            } );
        Log::info( '群发邮件子任务派发完成。', [
            'send_log_id' => $this->sendLogId,
            'recipient_jobs' => $index,
            'smtp_count' => count( $mailIds ),
        ] );
    }
}
