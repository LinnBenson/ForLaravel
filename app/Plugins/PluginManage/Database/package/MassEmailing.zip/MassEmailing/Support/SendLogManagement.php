<?php

namespace App\Plugins\MassEmailing\Support;

use App\Filament\Concerns\HasNavigationLevel;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Services\MassMailCreationService;
use App\Plugins\MassEmailing\Services\SendLogResendService;
use App\Plugins\MassEmailing\Services\SpreadsheetEmailReaderService;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Actions\ActionGroup;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\FileUpload;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Illuminate\Support\Str;
use InvalidArgumentException;
use Livewire\Features\SupportFileUploads\TemporaryUploadedFile;
use Throwable;
use UnitEnum;

/**
 * SendLogManagement
 * 群发邮件发送日志后台页面。
 * @package App\Plugins\MassEmailing\Support
 */
class SendLogManagement extends Page implements HasTable {
    use HasNavigationLevel {
        canAccess as protected canAccessByNavigationLevel;
    }
    use InteractsWithTable;

    protected static string $navigationPermission = 'mass_emailing_send_logs';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPaperAirplane;

    protected static ?string $slug = 'send-logs';

    protected static ?int $navigationSort = 31;

    protected string $view = 'MassEmailing::send-log-management';

    /**
     * 获取页面头部操作。
     * @return array<int, Action> 页面操作
     */
    protected function getHeaderActions(): array {
        return [
            Action::make( 'createMassMail' )
                ->label( '创建群发' )
                ->icon( Heroicon::OutlinedPlus )
                ->schema( [
                    TextInput::make( 'title' )
                        ->label( '邮箱标题' )
                        ->maxLength( 255 )
                        ->required(),
                    Textarea::make( 'content' )
                        ->label( '发件内容' )
                        ->rows( 10 )
                        ->required()
                        ->columnSpanFull(),
                    FileUpload::make( 'recipient_document' )
                        ->label( '导入接收邮箱文档' )
                        ->helperText( '支持 CSV、XLSX、ODS；上传后实时读取所有非空单元格，只提取完整合法邮箱并自动去重。' )
                        ->acceptedFileTypes( [
                            'text/csv',
                            'text/plain',
                            'application/csv',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'application/vnd.oasis.opendocument.spreadsheet',
                        ] )
                        ->maxSize( 20480 )
                        ->storeFiles( false )
                        ->dehydrated( false )
                        ->live()
                        ->afterStateUpdated( function ( TemporaryUploadedFile|null $state, Set $set, Get $get ): void {
                            if ( !$state ) { return; }
                            try {
                                $emails = app( SpreadsheetEmailReaderService::class )->read( $state );
                                if ( $emails === [] ) {
                                    Notification::make()->title( '文档中没有识别到有效邮箱' )->warning()->send();
                                    return;
                                }
                                $existing = preg_split( '/[\s,;]+/u', trim( (string) $get( 'recipients' ) ) ) ?: [];
                                $merged = [];
                                foreach ( [...$existing, ...$emails] as $email ) {
                                    $email = strtolower( trim( $email ) );
                                    if ( $email !== '' ) { $merged[$email] = $email; }
                                }
                                $set( 'recipients', implode( "\n", $merged ) );
                                Notification::make()->title( "已从文档识别 {$state->getClientOriginalName()}" )->body( '提取并合并 '.count( $emails ).' 个有效邮箱。' )->success()->send();
                            }catch ( InvalidArgumentException $exception ) {
                                Notification::make()->title( '接收邮箱文档读取失败' )->body( $exception->getMessage() )->danger()->send();
                            }
                        } )
                        ->columnSpanFull(),
                    Textarea::make( 'recipients' )
                        ->label( '接收邮箱' )
                        ->helperText( '每行一个邮箱，也支持使用逗号、分号或空格分隔；系统会自动校验并去重。' )
                        ->rows( 12 )
                        ->required()
                        ->columnSpanFull(),
                ] )
                ->modalHeading( '创建邮件群发任务' )
                ->modalDescription( '任务创建后，将按照在线 SMTP 列表依次轮询分配并在队列中发送。' )
                ->modalSubmitActionLabel( '创建并发送' )
                ->modalCancelActionLabel( '取消' )
                ->modalWidth( '4xl' )
                ->action( fn ( array $data ): mixed => $this->createMassMail( $data ) ),
        ];
    }

    /**
     * 判断是否允许访问发件日志页面。
     * @return bool 是否允许访问
     */
    public static function canAccess(): bool {
        return SendLog::schema()->hasTable( 'send_logs' ) && static::canAccessByNavigationLevel();
    }

    /**
     * 配置发件日志表格。
     * @param Table $table Filament 表格
     * @return Table Filament 表格
     */
    public function table( Table $table ): Table {
        return $table
            ->query( SendLog::query() )
            ->defaultSort( 'id', 'desc' )
            ->columns( [
                TextColumn::make( 'title' )
                    ->label( '邮箱标题' )
                    ->searchable()
                    ->limit( 30 )
                    ->tooltip( fn ( SendLog $record ): string => $record->title )
                    ->action( $this->viewLogAction( 'viewTitle' ) ),
                TextColumn::make( 'content' )
                    ->label( '发件内容' )
                    ->searchable()
                    ->limit( 40 )
                    ->wrap()
                    ->tooltip( fn ( SendLog $record ): string => Str::limit( $record->content, 300 ) )
                    ->action( $this->viewLogAction( 'viewContent' ) ),
                TextColumn::make( 'recipient_count' )
                    ->label( '接收人' )
                    ->state( fn ( SendLog $record ): string => "{$record->recipient_count} 人" )
                    ->badge(),
                TextColumn::make( 'report' )
                    ->label( '发件报告' )
                    ->state( fn ( SendLog $record ): string => $this->reportSummary( $record ) )
                    ->wrap(),
                TextColumn::make( 'schedule' )
                    ->label( '发送进度' )
                    ->state( fn ( SendLog $record ): string => $record->schedule_label )
                    ->badge()
                    ->color( fn ( SendLog $record ): string => $record->recipient_count > 0 && $record->schedule >= $record->recipient_count ? 'success' : 'warning' )
                    ->sortable(),
                TextColumn::make( 'created_at' )
                    ->label( '创建时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable(),
                TextColumn::make( 'updated_at' )
                    ->label( '更新时间' )
                    ->dateTime( 'Y.m.d H:i:s' )
                    ->sortable()
                    ->toggleable( isToggledHiddenByDefault: true ),
            ] )
            ->recordActions( [
                ActionGroup::make( [
                    $this->viewLogAction( 'view' ),
                    Action::make( 'resend' )
                        ->label( '重新发送' )
                        ->icon( Heroicon::OutlinedArrowPath )
                        ->color( 'warning' )
                        ->requiresConfirmation()
                        ->modalHeading( '确认重新发送？' )
                        ->modalDescription( '该行的发送报告、进度及全部接收人发送状态将被重置，并重新提交到队列。' )
                        ->modalSubmitActionLabel( '重置并重新发送' )
                        ->action( fn ( SendLog $record ): mixed => $this->resendMassMail( $record ) ),
                    Action::make( 'retryFailed' )
                        ->label( '补发失败' )
                        ->icon( Heroicon::OutlinedPaperAirplane )
                        ->color( 'primary' )
                        ->visible( fn ( SendLog $record ): bool => $record->reportCount( SendLog::REPORT_FAILED ) > 0 )
                        ->requiresConfirmation()
                        ->modalHeading( '确认补发失败邮箱？' )
                        ->modalDescription( '将复制原标题与内容创建一条新日志，并且只向原日志中发送失败的邮箱补发。原日志保持不变。' )
                        ->modalSubmitActionLabel( '创建并补发' )
                        ->action( fn ( SendLog $record ): mixed => $this->retryFailedMassMail( $record ) ),
                    DeleteAction::make()->label( '删除' ),
                ] )
                    ->icon( Heroicon::OutlinedEllipsisVertical )
                    ->tooltip( '操作' ),
            ] )
            ->recordActionsColumnLabel( '操作' )
            ->toolbarActions( [
                BulkActionGroup::make( [
                    DeleteBulkAction::make()->label( '删除所选' ),
                ] ),
            ] )
            ->defaultPaginationPageOption( 25 )
            ->paginationPageOptions( [25, 50, 100] )
            ->emptyStateHeading( '暂无发件日志' )
            ->emptyStateDescription( '创建群发任务后，邮件内容、接收人及发送结果将显示在这里。' );
    }

    /**
     * 创建发件日志详情操作。
     * @param string $name 操作名称
     * @return Action 查看操作
     */
    private function viewLogAction( string $name ): Action {
        return Action::make( $name )
            ->label( '查看' )
            ->icon( Heroicon::OutlinedEye )
            ->color( 'gray' )
            ->modalHeading( fn ( SendLog $record ): string => $record->title )
            ->modalContent( fn ( SendLog $record ) => view( 'MassEmailing::send-log-details', [
                'record' => $record,
                'recipients' => $record->recipients()->with( 'mail' )->orderBy( 'id' )->get(),
            ] ) )
            ->modalWidth( '5xl' )
            ->modalSubmitAction( false )
            ->modalCancelActionLabel( '关闭' );
    }

    /**
     * 创建并提交群发任务。
     * @param array{title: string, content: string, recipients: string} $data 群发表单数据
     * @return void
     */
    public function createMassMail( array $data ): void {
        try {
            $sendLog = app( MassMailCreationService::class )->create( $data['title'], $data['content'], $data['recipients'] );
            DispatchSendLogJob::dispatch( (int) $sendLog->getKey() );
            Notification::make()
                ->title( '群发任务已创建' )
                ->body( "共 {$sendLog->recipient_count} 个接收邮箱，队列将按 SMTP 轮询顺序发送。" )
                ->success()
                ->send();
        }catch ( InvalidArgumentException $exception ) {
            Notification::make()->title( '群发任务创建失败' )->body( $exception->getMessage() )->danger()->send();
        }catch ( Throwable $throwable ) {
            report( $throwable );
            Notification::make()->title( '群发任务创建失败' )->body( '请检查可用 SMTP 和队列状态。' )->danger()->send();
        }
    }

    /**
     * 重置并重新提交群发任务。
     * @param SendLog $sendLog 发件日志
     * @return void
     */
    public function resendMassMail( SendLog $sendLog ): void {
        try {
            $sendLog = app( SendLogResendService::class )->reset( $sendLog );
            DispatchSendLogJob::dispatch( (int) $sendLog->getKey() );
            Notification::make()
                ->title( '群发任务已重新提交' )
                ->body( "共 {$sendLog->recipient_count} 个接收邮箱，发送报告和进度已重置。" )
                ->success()
                ->send();
        }catch ( Throwable $throwable ) {
            report( $throwable );
            Notification::make()->title( '重新发送失败' )->body( $throwable->getMessage() )->danger()->send();
        }
    }

    /**
     * 创建新日志并补发原日志中失败的邮箱。
     * @param SendLog $sendLog 原发件日志
     * @return void
     */
    public function retryFailedMassMail( SendLog $sendLog ): void {
        try {
            $newSendLog = app( SendLogResendService::class )->createFailedRetry( $sendLog );
            DispatchSendLogJob::dispatch( (int) $newSendLog->getKey() );
            Notification::make()
                ->title( '失败邮箱补发任务已创建' )
                ->body( "已创建新日志 #{$newSendLog->getKey()}，共补发 {$newSendLog->recipient_count} 个邮箱。" )
                ->success()
                ->send();
        }catch ( Throwable $throwable ) {
            report( $throwable );
            Notification::make()->title( '补发失败任务创建失败' )->body( $throwable->getMessage() )->danger()->send();
        }
    }

    /**
     * 获取发件报告摘要。
     * @param SendLog $record 发件日志
     * @return string 报告摘要
     */
    private function reportSummary( SendLog $record ): string {
        $success = $record->reportCount( SendLog::REPORT_SUCCESS );
        $failed = $record->reportCount( SendLog::REPORT_FAILED );
        $pending = $record->reportCount( SendLog::REPORT_PENDING );
        return "成功 {$success} / 失败 {$failed} / 未发送 {$pending}";
    }

    public function getBreadcrumbs(): array { return [__( 'filament.groups.other' ), '发件日志']; }
    public static function getNavigationLabel(): string { return '发件日志'; }
    public function getTitle(): string { return '发件日志'; }
    public static function getNavigationGroup(): string|UnitEnum|null { return __( 'filament.groups.other' ); }
}
