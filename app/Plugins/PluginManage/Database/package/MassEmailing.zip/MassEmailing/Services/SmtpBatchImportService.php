<?php

namespace App\Plugins\MassEmailing\Services;

use App\Plugins\MassEmailing\Models\Mail;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * SmtpBatchImportService
 * 解析多行 SMTP 文本并批量写入插件数据库。
 * @package App\Plugins\MassEmailing\Services
 */
class SmtpBatchImportService {
    private const SCHEMES = ['smtp', 'smtps', 'tls', 'ssl'];

    /**
     * 批量导入 SMTP 配置。
     * 每行格式为：服务器|端口|用户名|协议|密码。
     * @param string $content SMTP 多行文本
     * @return array{imported: int, skipped: int} 导入结果
     */
    public function import( string $content ): array {
        $rows = $this->parse( $content );
        return DB::connection( Mail::CONNECTION )->transaction( function () use ( $rows ): array {
            $imported = 0;
            $skipped = 0;
            $seen = [];
            foreach ( $rows as $row ) {
                $identity = implode( '|', [$row['server'], (string) $row['port'], $row['username'], $row['scheme']] );
                if ( isset( $seen[$identity] ) || $this->exists( $row ) ) {
                    $skipped++;
                    continue;
                }
                $seen[$identity] = true;
                Mail::query()->create( $row + [
                    'status' => true,
                    'connection_status' => SmtpConnectivityService::STATUS_ONLINE,
                ] );
                $imported++;
            }
            return ['imported' => $imported, 'skipped' => $skipped];
        } );
    }

    /**
     * 解析并校验 SMTP 多行文本。
     * @param string $content SMTP 多行文本
     * @return array<int, array{name: string, server: string, port: int, username: string, scheme: string, password: string}> SMTP 数据
     */
    private function parse( string $content ): array {
        $lines = preg_split( '/\R/u', trim( $content ) ) ?: [];
        $rows = [];
        foreach ( $lines as $index => $line ) {
            $line = trim( $line );
            if ( $line === '' ) { continue; }
            $lineNumber = $index + 1;
            $parts = explode( '|', $line, 5 );
            if ( count( $parts ) !== 5 ) {
                throw new InvalidArgumentException( "第 {$lineNumber} 行格式错误，应包含服务器、端口、用户名、协议和密码。" );
            }
            [$server, $port, $username, $scheme, $password] = $parts;
            $server = trim( $server );
            $port = trim( $port );
            $username = str_replace( '\\@', '@', trim( $username ) );
            $scheme = strtolower( trim( $scheme ) );
            $password = trim( $password );
            $name = strstr( $username, '@', true );
            if ( $server === '' || mb_strlen( $server ) > 255 ) {
                throw new InvalidArgumentException( "第 {$lineNumber} 行邮箱服务器无效。" );
            }
            if ( !ctype_digit( $port ) || (int) $port < 1 || (int) $port > 65535 ) {
                throw new InvalidArgumentException( "第 {$lineNumber} 行邮箱端口无效。" );
            }
            if ( $name === false || $name === '' || mb_strlen( $username ) > 255 ) {
                throw new InvalidArgumentException( "第 {$lineNumber} 行邮箱用户名无效，必须包含 @。" );
            }
            if ( !in_array( $scheme, self::SCHEMES, true ) ) {
                throw new InvalidArgumentException( "第 {$lineNumber} 行邮箱协议无效，仅支持 smtp、smtps、tls、ssl。" );
            }
            if ( $password === '' || mb_strlen( $password ) > 1000 ) {
                throw new InvalidArgumentException( "第 {$lineNumber} 行邮箱密码无效。" );
            }
            $rows[] = [
                'name' => $name,
                'server' => $server,
                'port' => (int) $port,
                'username' => $username,
                'scheme' => $scheme,
                'password' => $password,
            ];
        }
        if ( $rows === [] ) { throw new InvalidArgumentException( '请至少填写一行 SMTP 配置。' ); }
        return $rows;
    }

    /**
     * 判断 SMTP 配置是否已经存在。
     * @param array{server: string, port: int, username: string, scheme: string} $row SMTP 数据
     * @return bool 是否存在
     */
    private function exists( array $row ): bool {
        return Mail::query()
            ->where( 'server', $row['server'] )
            ->where( 'port', $row['port'] )
            ->where( 'username', $row['username'] )
            ->where( 'scheme', $row['scheme'] )
            ->exists();
    }
}
