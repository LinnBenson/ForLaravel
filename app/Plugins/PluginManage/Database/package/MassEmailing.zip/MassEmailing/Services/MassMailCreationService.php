<?php

namespace App\Plugins\MassEmailing\Services;

use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Models\SendLogRecipient;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * MassMailCreationService
 * 校验接收邮箱并创建群发日志及接收人明细。
 * @package App\Plugins\MassEmailing\Services
 */
class MassMailCreationService {
    /**
     * 创建群发任务数据。
     * @param string $title 邮件标题
     * @param string $content 邮件内容
     * @param string $recipientsText 接收邮箱文本
     * @return SendLog 发件日志
     */
    public function create( string $title, string $content, string $recipientsText ): SendLog {
        $hasOnlineMail = Mail::query()
            ->where( 'status', true )
            ->where( 'connection_status', SmtpConnectivityService::STATUS_ONLINE )
            ->exists();
        if ( !$hasOnlineMail ) { throw new InvalidArgumentException( '没有已启用且连通正常的 SMTP 配置。' ); }
        $recipients = $this->parseRecipients( $recipientsText );
        return DB::connection( Mail::CONNECTION )->transaction( function () use ( $title, $content, $recipients ): SendLog {
            $report = array_fill_keys( $recipients, SendLog::REPORT_PENDING );
            $sendLog = SendLog::query()->create( [
                'title' => trim( $title ),
                'content' => $content,
                'receive' => $recipients,
                'report' => $report,
                'schedule' => 0,
            ] );
            foreach ( $recipients as $recipient ) {
                SendLogRecipient::query()->create( [
                    'send_log_id' => $sendLog->getKey(),
                    'recipient' => $recipient,
                    'status' => SendLog::REPORT_PENDING,
                    'attempts' => 0,
                ] );
            }
            return $sendLog;
        } );
    }

    /**
     * 解析、校验并去重接收邮箱。
     * @param string $recipientsText 接收邮箱文本
     * @return array<int, string> 接收邮箱列表
     */
    private function parseRecipients( string $recipientsText ): array {
        $values = preg_split( '/[\s,;]+/u', trim( $recipientsText ) ) ?: [];
        $recipients = [];
        foreach ( $values as $value ) {
            $recipient = strtolower( trim( $value ) );
            if ( $recipient === '' ) { continue; }
            if ( filter_var( $recipient, FILTER_VALIDATE_EMAIL ) === false || mb_strlen( $recipient ) > 255 ) {
                throw new InvalidArgumentException( "接收邮箱格式无效：{$recipient}" );
            }
            $recipients[$recipient] = $recipient;
        }
        if ( $recipients === [] ) { throw new InvalidArgumentException( '请至少填写一个有效的接收邮箱。' ); }
        if ( count( $recipients ) > 10000 ) { throw new InvalidArgumentException( '单个群发任务最多支持 10000 个接收邮箱。' ); }
        return array_values( $recipients );
    }
}
