<?php

namespace App\Plugins\MassEmailing\Services;

use InvalidArgumentException;
use Illuminate\Http\UploadedFile;
use OpenSpout\Reader\AbstractReader;
use OpenSpout\Reader\CSV\Reader as CsvReader;
use OpenSpout\Reader\ODS\Reader as OdsReader;
use OpenSpout\Reader\XLSX\Reader as XlsxReader;
use Throwable;

/**
 * SpreadsheetEmailReaderService
 * 流式读取 CSV、XLSX、ODS 文档并提取所有合法邮箱单元格。
 * @package App\Plugins\MassEmailing\Services
 */
class SpreadsheetEmailReaderService {
    private const MAX_CELLS = 1000000;
    private const MAX_EMAILS = 10000;

    /**
     * 从临时上传文档中提取邮箱。
     * @param UploadedFile $upload 上传文档
     * @return array<int, string> 去重后的邮箱列表
     */
    public function read( UploadedFile $upload ): array {
        $reader = $this->makeReader( strtolower( $upload->getClientOriginalExtension() ) );
        $emails = [];
        $cells = 0;
        try {
            $reader->open( $upload->getRealPath() );
            foreach ( $reader->getSheetIterator() as $sheet ) {
                foreach ( $sheet->getRowIterator() as $row ) {
                    foreach ( $row->getCells() as $cell ) {
                        $cells++;
                        if ( $cells > self::MAX_CELLS ) {
                            throw new InvalidArgumentException( '文档单元格超过 1000000 个，请拆分后重新上传。' );
                        }
                        $value = $cell->getValue();
                        if ( !is_string( $value ) ) { continue; }
                        $email = strtolower( trim( $value ) );
                        if ( $email === '' || filter_var( $email, FILTER_VALIDATE_EMAIL ) === false ) { continue; }
                        $emails[$email] = $email;
                        if ( count( $emails ) > self::MAX_EMAILS ) {
                            throw new InvalidArgumentException( '文档中的邮箱超过 10000 个，请拆分为多个群发任务。' );
                        }
                    }
                }
            }
        }catch ( InvalidArgumentException $exception ) {
            throw $exception;
        }catch ( Throwable $throwable ) {
            throw new InvalidArgumentException( '文档读取失败，请确认文件格式及内容有效。', previous: $throwable );
        }finally {
            $reader->close();
        }
        return array_values( $emails );
    }

    /**
     * 根据扩展名创建流式表格读取器。
     * @param string $extension 文件扩展名
     * @return AbstractReader 表格读取器
     */
    private function makeReader( string $extension ): AbstractReader {
        return match ( $extension ) {
            'csv' => new CsvReader(),
            'xlsx' => new XlsxReader(),
            'ods' => new OdsReader(),
            default => throw new InvalidArgumentException( '仅支持 CSV、XLSX 和 ODS 表格文档。' ),
        };
    }
}
