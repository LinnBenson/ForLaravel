<?php

namespace App\Plugins\MassEmailing\Services;

use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Models\SendLogRecipient;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * SendLogResendService
 * 重置发件日志及全部接收人状态，以便重新派发群发任务。
 * @package App\Plugins\MassEmailing\Services
 */
class SendLogResendService {
    public function __construct( private MassMailCreationService $creationService ) {}

    /**
     * 重置指定发件日志。
     * @param SendLog $sendLog 发件日志
     * @return SendLog 重置后的发件日志
     */
    public function reset( SendLog $sendLog ): SendLog {
        return DB::connection( Mail::CONNECTION )->transaction( function () use ( $sendLog ): SendLog {
            $lockedLog = SendLog::query()->lockForUpdate()->find( $sendLog->getKey() );
            if ( !$lockedLog ) { throw new RuntimeException( '发件日志不存在或已被删除。' ); }
            $recipients = $lockedLog->recipients()->pluck( 'recipient' )->all();
            if ( $recipients === [] ) { throw new RuntimeException( '该发件日志没有可重新发送的接收人。' ); }
            SendLogRecipient::query()
                ->where( 'send_log_id', $lockedLog->getKey() )
                ->update( [
                    'mail_id' => null,
                    'status' => SendLog::REPORT_PENDING,
                    'attempts' => 0,
                    'error' => null,
                    'sent_at' => null,
                    'updated_at' => now(),
                ] );
            $lockedLog->forceFill( [
                'report' => array_fill_keys( $recipients, SendLog::REPORT_PENDING ),
                'schedule' => 0,
                'updated_at' => now(),
            ] )->save();
            return $lockedLog->refresh();
        } );
    }

    /**
     * 使用原日志中发送失败的接收人创建一条新群发日志。
     * 原日志及其发送报告保持不变。
     * @param SendLog $sendLog 原发件日志
     * @return SendLog 新建的补发日志
     */
    public function createFailedRetry( SendLog $sendLog ): SendLog {
        $sourceLog = SendLog::query()->find( $sendLog->getKey() );
        if ( !$sourceLog ) { throw new RuntimeException( '原发件日志不存在或已被删除。' ); }
        $recipients = $sourceLog->recipients()
            ->where( 'status', SendLog::REPORT_FAILED )
            ->orderBy( 'id' )
            ->pluck( 'recipient' )
            ->all();
        if ( $recipients === [] ) { throw new RuntimeException( '该发件日志没有发送失败的邮箱。' ); }
        return $this->creationService->create(
            $sourceLog->title,
            $sourceLog->content,
            implode( "\n", $recipients ),
        );
    }
}
