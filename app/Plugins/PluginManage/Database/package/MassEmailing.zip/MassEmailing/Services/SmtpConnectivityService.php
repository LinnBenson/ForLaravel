<?php

namespace App\Plugins\MassEmailing\Services;

use App\Plugins\MassEmailing\Models\Mail;
use Carbon\CarbonImmutable;
use RuntimeException;
use Symfony\Component\Mailer\Transport\Smtp\EsmtpTransport;
use Throwable;

/**
 * SmtpConnectivityService
 * SMTP 服务器连接、TLS 和账号认证检测服务。
 * @package App\Plugins\MassEmailing\Services
 */
class SmtpConnectivityService {
    public const STATUS_UNKNOWN = 'unknown';
    public const STATUS_ONLINE = 'online';
    public const STATUS_OFFLINE = 'offline';

    private const TIMEOUT_SECONDS = 5.0;

    /**
     * 按 SMTP 配置 ID 执行连通性检测。
     * @param int $mailId SMTP 配置 ID
     * @return array{success: bool, status: string, message: string, checked_at: string, duration_ms: int} 检测结果
     */
    public function checkById( int $mailId ): array {
        $mail = Mail::query()->find( $mailId );
        if ( !$mail ) { throw new RuntimeException( 'SMTP 配置不存在。' ); }
        return $this->check( $mail );
    }

    /**
     * 执行 SMTP 连通性检测。
     * 建立 SMTP 连接并完成 TLS 与账号认证，不发送邮件。
     * @param Mail $mail SMTP 配置
     * @param bool $persist 是否保存检测结果
     * @return array{success: bool, status: string, message: string, checked_at: string, duration_ms: int} 检测结果
     */
    public function check( Mail $mail, bool $persist = true ): array {
        $startedAt = microtime( true );
        $checkedAt = CarbonImmutable::now();
        $transport = null;
        try {
            $transport = $this->makeTransport( $mail );
            $transport->start();
            $result = $this->result( true, '连接与认证成功。', $checkedAt, $startedAt );
        }catch ( Throwable $throwable ) {
            $result = $this->result( false, $this->sanitizeError( $throwable ), $checkedAt, $startedAt );
        }finally {
            if ( $transport instanceof EsmtpTransport ) { $transport->stop(); }
        }
        if ( $persist && $mail->exists ) { $this->persistResult( $mail, $result, $checkedAt ); }
        return $result;
    }

    /**
     * 创建 SMTP 运输实例。
     * @param Mail $mail SMTP 配置
     * @return EsmtpTransport SMTP 运输实例
     */
    private function makeTransport( Mail $mail ): EsmtpTransport {
        $scheme = strtolower( trim( (string) $mail->scheme ) );
        $implicitTls = in_array( $scheme, ['smtps', 'ssl'], true );
        $transport = new EsmtpTransport( (string) $mail->server, (int) $mail->port, $implicitTls );
        $transport->getStream()
            ->setTimeout( self::TIMEOUT_SECONDS )
            ->setStreamOptions( [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ],
            ] );
        $transport->setUsername( (string) $mail->username );
        $transport->setPassword( (string) $mail->password );
        if ( $scheme === 'tls' ) {
            $transport->setAutoTls( true );
            $transport->setRequireTls( true );
        }elseif ( $scheme === 'smtp' ) {
            $transport->setAutoTls( false );
        }
        return $transport;
    }

    /**
     * 生成结构化检测结果。
     * @param bool $success 是否检测成功
     * @param string $message 检测信息
     * @param CarbonImmutable $checkedAt 检测时间
     * @param float $startedAt 开始时间
     * @return array{success: bool, status: string, message: string, checked_at: string, duration_ms: int} 检测结果
     */
    private function result( bool $success, string $message, CarbonImmutable $checkedAt, float $startedAt ): array {
        return [
            'success' => $success,
            'status' => $success ? self::STATUS_ONLINE : self::STATUS_OFFLINE,
            'message' => $message,
            'checked_at' => $checkedAt->format( 'Y-m-d H:i:s' ),
            'duration_ms' => (int) round( ( microtime( true ) - $startedAt ) * 1000 ),
        ];
    }

    /**
     * 保存 SMTP 检测结果。
     * @param Mail $mail SMTP 配置
     * @param array{success: bool, status: string, message: string, checked_at: string, duration_ms: int} $result 检测结果
     * @param CarbonImmutable $checkedAt 检测时间
     * @return void
     */
    private function persistResult( Mail $mail, array $result, CarbonImmutable $checkedAt ): void {
        $mail->forceFill( [
            'connection_status' => $result['status'],
            'last_checked_at' => $checkedAt,
            'last_error' => $result['success'] ? null : $result['message'],
        ] )->save();
    }

    /**
     * 清理可展示的错误信息。
     * 移除控制字符并限制长度，不记录或返回 SMTP 密码。
     * @param Throwable $throwable SMTP 检测异常
     * @return string 安全错误信息
     */
    private function sanitizeError( Throwable $throwable ): string {
        $message = preg_replace( '/[\x00-\x1F\x7F]+/u', ' ', $throwable->getMessage() );
        $message = trim( (string) $message );
        return mb_substr( $message === '' ? 'SMTP 连接或认证失败。' : $message, 0, 500 );
    }
}
