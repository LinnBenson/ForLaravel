<?php

namespace App\Plugins\MassEmailing\Services;

use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use Symfony\Component\Mailer\Transport\Smtp\EsmtpTransport;
use Symfony\Component\Mime\Email;

/**
 * SmtpMailSendingService
 * 使用指定 SMTP 配置发送单封群发邮件。
 * @package App\Plugins\MassEmailing\Services
 */
class SmtpMailSendingService {
    /**
     * 发送单封邮件。
     * @param Mail $mail SMTP 配置
     * @param SendLog $sendLog 发件日志
     * @param string $recipient 接收邮箱
     * @return void
     */
    public function send( Mail $mail, SendLog $sendLog, string $recipient ): void {
        $transport = $this->makeTransport( $mail );
        try {
            $transport->send(
                ( new Email() )
                    ->from( $mail->username )
                    ->to( $recipient )
                    ->subject( $sendLog->title )
                    ->text( $sendLog->content ),
            );
        }finally {
            $transport->stop();
        }
    }

    /**
     * 创建 SMTP 运输实例。
     * 发件时跳过 TLS 证书验证，兼容证书链不完整或自签名的 SMTP 服务。
     * @param Mail $mail SMTP 配置
     * @return EsmtpTransport SMTP 运输实例
     */
    private function makeTransport( Mail $mail ): EsmtpTransport {
        $scheme = strtolower( trim( (string) $mail->scheme ) );
        $implicitTls = in_array( $scheme, ['smtps', 'ssl'], true );
        $transport = new EsmtpTransport( $mail->server, $mail->port, $implicitTls );
        $transport->getStream()
            ->setTimeout( 15.0 )
            ->setStreamOptions( [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ],
            ] );
        $transport->setUsername( $mail->username );
        $transport->setPassword( $mail->password );
        if ( $scheme === 'tls' ) {
            $transport->setAutoTls( true );
            $transport->setRequireTls( true );
        }elseif ( $scheme === 'smtp' ) {
            $transport->setAutoTls( false );
        }
        return $transport;
    }
}
