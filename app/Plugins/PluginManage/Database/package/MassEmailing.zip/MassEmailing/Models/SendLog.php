<?php

namespace App\Plugins\MassEmailing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;
use Illuminate\Support\Facades\Schema;

/**
 * SendLog
 * 群发邮件内容、接收人、进度和结果记录模型。
 * @package App\Plugins\MassEmailing\Models
 */
class SendLog extends Model {
    public const CONNECTION = Mail::CONNECTION;

    public const REPORT_PENDING = 0;
    public const REPORT_SUCCESS = 1;
    public const REPORT_FAILED = 2;

    protected $connection = self::CONNECTION;

    protected $table = 'send_logs';

    protected $casts = [
        'receive' => 'array',
        'report' => 'array',
        'schedule' => 'integer',
    ];

    /** @var array<int, string> */
    protected $fillable = [
        'title',
        'content',
        'receive',
        'report',
        'schedule',
    ];

    protected static function booted(): void {
        static::deleting( fn ( SendLog $sendLog ) => $sendLog->recipients()->delete() );
    }

    public function recipients(): HasMany {
        return $this->hasMany( SendLogRecipient::class );
    }

    /**
     * 获取接收人总数。
     * @return int 接收人数量
     */
    public function getRecipientCountAttribute(): int {
        return count( $this->receive ?? [] );
    }

    /**
     * 获取发送进度文本。
     * @return string 已发送数量/总计数量
     */
    public function getScheduleLabelAttribute(): string {
        return "{$this->schedule}/{$this->recipient_count}";
    }

    /**
     * 统计指定发送状态的接收人数。
     * @param int $status 发送状态
     * @return int 接收人数
     */
    public function reportCount( int $status ): int {
        return count( array_filter(
            $this->report ?? [],
            fn ( int|string|null $value ): bool => (int) $value === $status,
        ) );
    }

    /**
     * 获取插件数据库结构构建器。
     * @return Builder 数据库结构构建器
     */
    public static function schema(): Builder {
        return Schema::connection( self::CONNECTION );
    }

    /**
     * 安装发件日志表。
     * @return void
     */
    public static function up(): void {
        $schema = self::schema();
        if ( $schema->hasTable( 'send_logs' ) ) { return; }
        $schema->create( 'send_logs', function ( Blueprint $table ): void {
            $table->id()->comment( '发件日志ID' );
            $table->string( 'title' )->comment( '邮箱标题' );
            $table->longText( 'content' )->comment( '发件内容' );
            $table->json( 'receive' )->comment( '接收人JSON' );
            $table->json( 'report' )->default( '{}' )->comment( '发件报告JSON：0未发送，1成功，2失败' );
            $table->unsignedInteger( 'schedule' )->default( 0 )->comment( '已发送数量' );
            $table->timestamps();
        } );
    }

    /**
     * 卸载发件日志表。
     * @return void
     */
    public static function down(): void {
        $schema = self::schema();
        if ( !$schema->hasTable( 'send_logs' ) ) { return; }
        $schema->drop( 'send_logs' );
    }
}
