<?php

namespace App\Plugins\MassEmailing\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;
use Illuminate\Support\Facades\Schema;

/**
 * SendLogRecipient
 * 发件日志接收人明细及单封发送状态模型。
 * @package App\Plugins\MassEmailing\Models
 */
class SendLogRecipient extends Model {
    public const CONNECTION = Mail::CONNECTION;

    protected $connection = self::CONNECTION;

    protected $table = 'send_log_recipients';

    protected $casts = [
        'status' => 'integer',
        'attempts' => 'integer',
        'sent_at' => 'datetime',
    ];

    /** @var array<int, string> */
    protected $fillable = [
        'send_log_id',
        'mail_id',
        'recipient',
        'status',
        'attempts',
        'error',
        'sent_at',
    ];

    public function sendLog(): BelongsTo {
        return $this->belongsTo( SendLog::class );
    }

    public function mail(): BelongsTo {
        return $this->belongsTo( Mail::class );
    }

    /**
     * 获取插件数据库结构构建器。
     * @return Builder 数据库结构构建器
     */
    public static function schema(): Builder {
        return Schema::connection( self::CONNECTION );
    }

    /**
     * 安装接收人发送明细表并兼容已有日志。
     * @return void
     */
    public static function up(): void {
        $schema = self::schema();
        if ( !$schema->hasTable( 'send_log_recipients' ) ) {
            $schema->create( 'send_log_recipients', function ( Blueprint $table ): void {
                $table->id()->comment( '接收人明细ID' );
                $table->unsignedBigInteger( 'send_log_id' )->comment( '发件日志ID' );
                $table->unsignedBigInteger( 'mail_id' )->nullable()->comment( '分配的SMTP配置ID' );
                $table->string( 'recipient' )->comment( '接收邮箱' );
                $table->unsignedTinyInteger( 'status' )->default( SendLog::REPORT_PENDING )->comment( '状态：0未发送，1成功，2失败' );
                $table->unsignedTinyInteger( 'attempts' )->default( 0 )->comment( '发送尝试次数' );
                $table->text( 'error' )->nullable()->comment( '最后发送错误' );
                $table->timestamp( 'sent_at' )->nullable()->comment( '发送完成时间' );
                $table->timestamps();
                $table->unique( ['send_log_id', 'recipient'] );
                $table->index( ['status', 'mail_id'] );
            } );
        }
        self::backfillExistingLogs();
    }

    /**
     * 为已有 JSON 发件日志补充接收人明细。
     * @return void
     */
    private static function backfillExistingLogs(): void {
        if ( !SendLog::schema()->hasTable( 'send_logs' ) ) { return; }
        SendLog::query()->eachById( function ( SendLog $sendLog ): void {
            foreach ( $sendLog->receive ?? [] as $recipient ) {
                $recipient = trim( (string) $recipient );
                if ( $recipient === '' ) { continue; }
                $status = (int) ( ( $sendLog->report ?? [] )[$recipient] ?? SendLog::REPORT_PENDING );
                self::query()->firstOrCreate(
                    ['send_log_id' => $sendLog->getKey(), 'recipient' => $recipient],
                    [
                        'status' => $status,
                        'attempts' => $status === SendLog::REPORT_PENDING ? 0 : 1,
                        'sent_at' => $status === SendLog::REPORT_PENDING ? null : $sendLog->updated_at,
                    ],
                );
            }
        } );
    }

    /**
     * 卸载接收人发送明细表。
     * @return void
     */
    public static function down(): void {
        $schema = self::schema();
        if ( !$schema->hasTable( 'send_log_recipients' ) ) { return; }
        $schema->drop( 'send_log_recipients' );
    }
}
