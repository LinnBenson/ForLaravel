<?php

namespace App\Plugins\MassEmailing\Models;

use App\Plugins\MassEmailing\Services\SmtpConnectivityService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Mail
 * 群发邮件的邮箱服务器配置模型。
 * @package App\Plugins\MassEmailing\Models
 */
class Mail extends Model {
    public const CONNECTION = 'mass_emailing';

    protected $connection = self::CONNECTION;

    protected $table = 'mails';

    protected $casts = [
        'port' => 'integer',
        'usage_count' => 'integer',
        'status' => 'boolean',
        'last_checked_at' => 'datetime',
    ];

    /** @var array<int, string> */
    protected $fillable = [
        'name',
        'server',
        'port',
        'username',
        'password',
        'scheme',
        'usage_count',
        'status',
        'connection_status',
        'last_checked_at',
        'last_error',
    ];

    protected static function booted(): void {
        static::creating( function ( Mail $mail ): void {
            if ( $mail->getAttribute( 'usage_count' ) === null ) {
                $mail->setAttribute( 'usage_count', 0 );
            }
            if ( !$mail->getAttribute( 'connection_status' ) ) {
                $mail->setAttribute( 'connection_status', SmtpConnectivityService::STATUS_ONLINE );
            }
        } );
    }

    /**
     * 获取插件数据库结构构建器。
     * @return Builder 数据库结构构建器
     */
    public static function schema(): Builder {
        return Schema::connection( self::CONNECTION );
    }

    /**
     * 安装邮箱配置表。
     * @return void
     */
    public static function up(): void {
        $schema = self::schema();
        if ( $schema->hasTable( 'mails' ) ) {
            self::upgrade();
            self::convertEncryptedPasswordsToPlaintext();
            return;
        }
        $schema->create( 'mails', function ( Blueprint $table ): void {
            $table->id()->comment( '邮箱配置ID' );
            $table->string( 'name' )->comment( '邮件名称' );
            $table->string( 'server' )->comment( '邮箱服务器' );
            $table->unsignedInteger( 'port' )->comment( '邮箱端口' );
            $table->string( 'username' )->comment( '邮箱用户名' );
            $table->text( 'password' )->comment( '邮箱密码（明文）' );
            $table->string( 'scheme', 16 )->comment( '邮箱协议' );
            $table->unsignedBigInteger( 'usage_count' )->default( 0 )->comment( '成功发送使用次数' );
            $table->boolean( 'status' )->default( true )->comment( '可用性：0不可用，1可用' );
            $table->string( 'connection_status', 16 )->default( SmtpConnectivityService::STATUS_ONLINE )->comment( '连通状态' );
            $table->timestamp( 'last_checked_at' )->nullable()->comment( '最后检测时间' );
            $table->text( 'last_error' )->nullable()->comment( '最后检测错误' );
            $table->timestamps();

            $table->index( 'status' );
        } );
    }

    /**
     * 升级已存在的邮箱配置表。
     * 为旧版数据表补充使用次数与连通性检测字段。
     * @return void
     */
    private static function upgrade(): void {
        $schema = self::schema();
        $hasUsageCount = $schema->hasColumn( 'mails', 'usage_count' );
        $hasConnectionStatus = $schema->hasColumn( 'mails', 'connection_status' );
        $hasLastCheckedAt = $schema->hasColumn( 'mails', 'last_checked_at' );
        $hasLastError = $schema->hasColumn( 'mails', 'last_error' );
        if ( $hasUsageCount && $hasConnectionStatus && $hasLastCheckedAt && $hasLastError ) { return; }
        $schema->table( 'mails', function ( Blueprint $table ) use ( $hasUsageCount, $hasConnectionStatus, $hasLastCheckedAt, $hasLastError ): void {
            if ( !$hasUsageCount ) {
                $table->unsignedBigInteger( 'usage_count' )->default( 0 )->comment( '成功发送使用次数' );
            }
            if ( !$hasConnectionStatus ) {
                $table->string( 'connection_status', 16 )->default( 'unknown' )->comment( '连通状态' );
            }
            if ( !$hasLastCheckedAt ) {
                $table->timestamp( 'last_checked_at' )->nullable()->comment( '最后检测时间' );
            }
            if ( !$hasLastError ) {
                $table->text( 'last_error' )->nullable()->comment( '最后检测错误' );
            }
        } );
    }

    /**
     * 将旧版加密密码转换为明文。
     * 已经是明文的密码保持不变，用于兼容旧版插件数据。
     * @return void
     */
    private static function convertEncryptedPasswordsToPlaintext(): void {
        DB::connection( self::CONNECTION )
            ->table( 'mails' )
            ->select( ['id', 'password'] )
            ->orderBy( 'id' )
            ->chunkById( 100, function ( iterable $mails ): void {
                foreach ( $mails as $mail ) {
                    try {
                        $password = Crypt::decryptString( (string) $mail->password );
                    }catch ( DecryptException ) {
                        continue;
                    }
                    DB::connection( self::CONNECTION )
                        ->table( 'mails' )
                        ->where( 'id', (int) $mail->id )
                        ->update( ['password' => $password] );
                }
            } );
    }

    /**
     * 卸载邮箱配置表。
     * @return void
     */
    public static function down(): void {
        $schema = self::schema();
        if ( !$schema->hasTable( 'mails' ) ) { return; }
        $schema->drop( 'mails' );
    }
}
