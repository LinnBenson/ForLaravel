<x-filament-panels::page>
    {{-- SMTP 配置管理表格 --}}
    {{ $this->table }}

    <style>
        /* SMTP 连通状态检测时间 */
        .smtp-connection-status-cell .fi-ta-text-description {
            margin-top: 0.125rem;
            color: var(--gray-500);
            font-size: 0.6875rem;
            line-height: 1rem;
            white-space: nowrap;
        }
        .dark .smtp-connection-status-cell .fi-ta-text-description {
            color: var(--gray-400);
        }
    </style>
</x-filament-panels::page>
