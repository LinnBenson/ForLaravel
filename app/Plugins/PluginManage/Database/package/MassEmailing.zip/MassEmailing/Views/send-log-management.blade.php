<x-filament-panels::page>
    {{-- 发件日志管理表格 --}}
    {{ $this->table }}
</x-filament-panels::page>
