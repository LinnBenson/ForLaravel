@php
    $statusLabels = [0 => '未发送', 1 => '成功', 2 => '失败'];
@endphp

{{-- 发件日志详情 --}}
<div class="send-log-details">
    <section>
        <h3>发件内容</h3>
        <div class="send-log-details-content">{{ $record->content }}</div>
    </section>
    <section>
        <div class="send-log-details-heading">
            <h3>接收人与发件报告</h3>
            <span>{{ $record->schedule_label }}</span>
        </div>
        <div class="send-log-details-report">
            @forelse ( $recipients as $recipient )
                <div>
                    <span>
                        {{ $recipient->recipient }}
                        @if ( $recipient->mail )
                            <small>{{ $recipient->mail->name }}</small>
                        @endif
                        @if ( $recipient->error )
                            <small title="{{ $recipient->error }}">{{ \Illuminate\Support\Str::limit( $recipient->error, 100 ) }}</small>
                        @endif
                    </span>
                    <strong data-status="{{ $recipient->status }}">{{ $statusLabels[$recipient->status] ?? '未知' }}</strong>
                </div>
            @empty
                <p>暂无接收人。</p>
            @endforelse
        </div>
    </section>
</div>

<style>
    /* 发件日志详情弹窗 */
    .send-log-details { display: grid; gap: 1rem; color: var(--gray-700); }
    .dark .send-log-details { color: var(--gray-300); }
    .send-log-details section { padding: 1rem; border: 1px solid var(--gray-200); border-radius: 0.75rem; background: white; }
    .dark .send-log-details section { border-color: var(--gray-700); background: var(--gray-900); }
    .send-log-details h3 { color: var(--gray-950); font-size: 0.875rem; font-weight: 700; }
    .dark .send-log-details h3 { color: white; }
    .send-log-details-heading { display: flex; align-items: center; justify-content: space-between; gap: 1rem; }
    .send-log-details-heading > span { color: var(--primary-600); font-size: 0.8rem; font-weight: 700; }
    .send-log-details-content { margin-top: 0.75rem; font-size: 0.875rem; line-height: 1.6; white-space: pre-wrap; overflow-wrap: anywhere; }
    .send-log-details-report { display: grid; margin-top: 0.75rem; gap: 0.5rem; }
    .send-log-details-report > div { display: flex; padding: 0.65rem 0.75rem; border-radius: 0.5rem; background: var(--gray-50); align-items: center; justify-content: space-between; gap: 1rem; }
    .dark .send-log-details-report > div { background: var(--gray-800); }
    .send-log-details-report span { font-size: 0.82rem; overflow-wrap: anywhere; }
    .send-log-details-report span small { display: block; margin-top: 0.15rem; color: var(--gray-500); font-size: 0.7rem; }
    .send-log-details-report strong { color: var(--gray-600); font-size: 0.75rem; }
    .send-log-details-report strong[data-status="1"] { color: var(--success-600); }
    .send-log-details-report strong[data-status="2"] { color: var(--danger-600); }
</style>
