<?php

namespace App\Plugins\MassEmailing\Controllers;

use App\Http\Controllers\Controller;
use App\Plugins\MassEmailing\Models\Mail;
use App\Plugins\MassEmailing\Models\SendLog;
use App\Plugins\MassEmailing\Models\SendLogRecipient;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * AdminController
 * 邮件群发器数据表管理控制器。
 * @package App\Plugins\MassEmailing\Controllers
 */
class AdminController extends Controller {
    /**
     * 重建插件数据表。
     * 删除现有邮箱配置和发件日志后重新创建当前版本结构。
     * @return JsonResponse|string JSON 响应
     */
    public function rebuild(): JsonResponse|string {
        try {
            DB::connection( Mail::CONNECTION )->transaction( function (): void {
                SendLogRecipient::down();
                SendLog::down();
                Mail::down();
                Mail::up();
                SendLog::up();
                SendLogRecipient::up();
            } );
            return echoJson( true, ['message' => '邮箱配置及发件日志表重建成功。'] );
        }catch ( Throwable $throwable ) {
            report( $throwable );
            return echoJson( false, ['message' => '插件数据表重建失败，请查看系统日志。'], 500 );
        }
    }
}
