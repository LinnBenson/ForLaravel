# MassEmailing

## 群发数据结构

- `SendLog` 保存邮件标题、内容、接收人 JSON、报告 JSON 和总体进度。
- `SendLogRecipient` 保存每个接收邮箱的 SMTP 分配、状态、尝试次数、错误和完成时间。
- 状态值：`0` 未发送、`1` 成功、`2` 失败。
- 单条新增和批量导入的 SMTP 默认连通状态为 `online`，无需预先检测即可参与发送；实际发件失败后仍会自动复检并更新状态。
- `Mail.usage_count` 记录 SMTP 成功发送次数，默认值为 `0`；只有邮件发送成功才会原子加一，失败不会增加。

## 创建群发任务

```php
$sendLog = app( \App\Plugins\MassEmailing\Services\MassMailCreationService::class )->create(
    '邮件标题',
    '邮件内容',
    "a@example.com\nb@example.com",
);

\App\Plugins\MassEmailing\Support\DispatchSendLogJob::dispatch( $sendLog->getKey() );
```

调度任务只选择已启用且连通状态为 `online` 的 SMTP，并按照使用次数升序、ID 升序开始轮询分配，所有 SMTP 各参与一次后才进入下一轮。`SendMailJob` 使用 SMTP 独立锁，同一个 SMTP 同一时刻只发送一封邮件；发送失败后会立即通过 `SmtpConnectivityService` 复检并更新当前 SMTP 的连通状态，然后最多尝试三次并优先切换到使用次数更少的其他在线 SMTP。发件人直接使用 SMTP 配置的 `username`，发件连接跳过 TLS 证书验证。

后台发件日志的“重新发送”操作通过 `SendLogResendService` 在事务中重置该日志的报告、进度，以及全部接收人的 SMTP 分配、状态、尝试次数、错误和发送时间，事务完成后重新派发 `DispatchSendLogJob`。

发件日志行操作统一收纳在三点菜单中。“补发失败”只读取原日志中状态为失败的接收人，复制原标题与内容创建一条独立的新日志并派发，原日志、报告和进度不会被修改；没有失败接收人时不显示该操作。

## 接收邮箱文档导入

创建群发任务时可上传 CSV、XLSX 或 ODS 文档。`SpreadsheetEmailReaderService` 使用 OpenSpout 流式读取全部工作表中的所有非空单元格，对字符串执行前后空格清理，仅保留完整合法邮箱并自动去重，然后合并填入接收邮箱文本框。单个文档最多扫描 1000000 个单元格、提取 10000 个邮箱，文件大小限制为 20 MB。
