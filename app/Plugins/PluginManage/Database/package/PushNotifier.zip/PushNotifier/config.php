<?php
return [
    'entrance' => '/plugins/push-notifier',
    'token' => '22f11b74-58ce-44eb-9bd6-79a8154bd193',
    'default' => 'bark',
    'api' => [
        'telegram' => [
            'token' => '',
            'recipient' => '',
        ],
        'bark' => [
            'host' => '',
            'recipient' => '',
        ],
        'email' => [
            'recipient' => '',
        ],
        'ntfy' => [
            'host' => '',
            'user' => '',
            'password' => '',
            'recipient' => '',
        ]
    ],
];
