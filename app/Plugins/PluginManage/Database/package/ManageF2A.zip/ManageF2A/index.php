<?php

use App\Providers\PluginProvider;

/**
 * Manage F2A
 * F2A 验证管理器
 */
return new class extends PluginProvider {
    /**
     * 插件信息
     */
    public function __construct() {
        $this->name = 'F2A 管理器';
        $this->description = 'F2A 验证管理器';
        $this->version = '1.0.0';
        $this->author = 'Todu.io';
        $this->setType( 1 );
    }

};
