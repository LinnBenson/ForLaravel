<?php
/**
 * 'f2a' => [
 *    '默认分类 - A' => [
 *       'name1' => 'key1',
 *       'name2' => 'key2'
 *    ],
 *    '默认分类 - B' => [
 *       'name1' => 'key1',
 *       'name2' => 'key2'
 *    ]
 * ]
 **/
return [
    'f2a' => [],
];
