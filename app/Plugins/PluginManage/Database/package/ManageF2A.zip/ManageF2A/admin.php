@php
    $f2aAccounts = $plugin->config( 'f2a', [] );
    $f2aAccounts = is_array( $f2aAccounts ) ? $f2aAccounts : [];
    $f2aAccountRows = [];
    foreach ( $f2aAccounts as $category => $accounts ) {
        if ( !is_array( $accounts ) ) { continue; }
        foreach ( $accounts as $name => $secret ) {
            if ( !is_scalar( $secret ) ) { continue; }
            $f2aAccountRows[] = ['category' => (string) $category, 'name' => (string) $name, 'secret' => (string) $secret];
        }
    }
@endphp

{{-- F2A 实时验证码管理界面 --}}
<div
    class="manage-f2a"
    x-data="{
        accounts: {!! e( json_encode( $f2aAccountRows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) !!}.map( ( account ) => ( {
            category: account.category,
            name: account.name,
            secret: String( account.secret ),
            code: '',
            invalid: false,
        } ) ),
        activeCategory: '全部',
        searchQuery: '',
        get categories() {
            return ['全部', ...new Set( this.accounts.map( ( account ) => account.category ) )];
        },
        get filteredAccounts() {
            const categoryAccounts = this.activeCategory === '全部'
                ? this.accounts
                : this.accounts.filter( ( account ) => account.category === this.activeCategory );
            const query = this.searchQuery.trim().toLowerCase();
            if ( query === '' ) { return categoryAccounts; }
            const secretQuery = query.replace( /[\s\-=]/g, '' );
            return categoryAccounts.filter( ( account ) => {
                const nameMatched = account.name.toLowerCase().includes( query );
                const secretMatched = account.secret.toLowerCase().replace( /[\s\-=]/g, '' ).includes( secretQuery );
                return nameMatched || secretMatched;
            } );
        },
        remaining: 30,
        progress: 100,
        copied: '',
        timer: null,
        period: null,
        async start() {
            await this.refresh();
            this.timer = window.setInterval( () => this.refresh(), 1000 );
        },
        async refresh() {
            const now = Math.floor( Date.now() / 1000 );
            const period = Math.floor( now / 30 );
            this.remaining = 30 - ( now % 30 );
            this.progress = ( this.remaining / 30 ) * 100;
            if ( this.period === period ) { return; }
            this.period = period;
            await Promise.all( this.accounts.map( async ( account ) => {
                try {
                    account.code = await this.generateTotp( account.secret, period );
                    account.invalid = false;
                }catch ( error ) {
                    account.code = '------';
                    account.invalid = true;
                }
            } ) );
        },
        decodeBase32( value ) {
            const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
            const secret = value.toUpperCase().replace( /[\s\-=]/g, '' );
            if ( secret.length < 8 || !/^[A-Z2-7]+$/.test( secret ) ) { throw new Error( 'Invalid Base32 secret' ); }
            let bits = '';
            for ( const character of secret ) {
                bits += alphabet.indexOf( character ).toString( 2 ).padStart( 5, '0' );
            }
            const bytes = [];
            for ( let index = 0; index + 8 <= bits.length; index += 8 ) {
                bytes.push( parseInt( bits.slice( index, index + 8 ), 2 ) );
            }
            return new Uint8Array( bytes );
        },
        rotateLeft( value, bits ) {
            return ( value << bits ) | ( value >>> ( 32 - bits ) );
        },
        sha1( input ) {
            const bytes = Array.from( input );
            const bitLength = bytes.length * 8;
            bytes.push( 128 );
            while ( bytes.length % 64 !== 56 ) { bytes.push( 0 ); }
            for ( let shift = 56; shift >= 0; shift -= 8 ) {
                bytes.push( shift >= 32 ? 0 : ( bitLength >>> shift ) & 255 );
            }
            let h0 = 0x67452301;
            let h1 = 0xefcdab89;
            let h2 = 0x98badcfe;
            let h3 = 0x10325476;
            let h4 = 0xc3d2e1f0;
            for ( let block = 0; block < bytes.length; block += 64 ) {
                const words = new Array( 80 ).fill( 0 );
                for ( let index = 0; index < 16; index++ ) {
                    const offset = block + index * 4;
                    words[index] = ( bytes[offset] << 24 ) | ( bytes[offset + 1] << 16 ) |
                        ( bytes[offset + 2] << 8 ) | bytes[offset + 3];
                }
                for ( let index = 16; index < 80; index++ ) {
                    words[index] = this.rotateLeft( words[index - 3] ^ words[index - 8] ^ words[index - 14] ^ words[index - 16], 1 );
                }
                let a = h0;
                let b = h1;
                let c = h2;
                let d = h3;
                let e = h4;
                for ( let index = 0; index < 80; index++ ) {
                    let f;
                    let k;
                    if ( index < 20 ) {
                        f = ( b & c ) | ( ( ~b ) & d );
                        k = 0x5a827999;
                    }else if ( index < 40 ) {
                        f = b ^ c ^ d;
                        k = 0x6ed9eba1;
                    }else if ( index < 60 ) {
                        f = ( b & c ) | ( b & d ) | ( c & d );
                        k = 0x8f1bbcdc;
                    }else {
                        f = b ^ c ^ d;
                        k = 0xca62c1d6;
                    }
                    const temporary = ( this.rotateLeft( a, 5 ) + f + e + k + words[index] ) | 0;
                    e = d;
                    d = c;
                    c = this.rotateLeft( b, 30 );
                    b = a;
                    a = temporary;
                }
                h0 = ( h0 + a ) | 0;
                h1 = ( h1 + b ) | 0;
                h2 = ( h2 + c ) | 0;
                h3 = ( h3 + d ) | 0;
                h4 = ( h4 + e ) | 0;
            }
            const result = [];
            for ( const word of [h0, h1, h2, h3, h4] ) {
                result.push( ( word >>> 24 ) & 255, ( word >>> 16 ) & 255, ( word >>> 8 ) & 255, word & 255 );
            }
            return result;
        },
        hmacSha1( key, message ) {
            let keyBytes = Array.from( key );
            if ( keyBytes.length > 64 ) { keyBytes = this.sha1( keyBytes ); }
            while ( keyBytes.length < 64 ) { keyBytes.push( 0 ); }
            const innerKey = keyBytes.map( ( byte ) => byte ^ 0x36 );
            const outerKey = keyBytes.map( ( byte ) => byte ^ 0x5c );
            return this.sha1( outerKey.concat( this.sha1( innerKey.concat( Array.from( message ) ) ) ) );
        },
        generateTotp( secret, counter ) {
            const message = new Uint8Array( 8 );
            new DataView( message.buffer ).setUint32( 4, counter, false );
            const hash = this.hmacSha1( this.decodeBase32( secret ), message );
            const offset = hash[hash.length - 1] & 15;
            const number = ( ( hash[offset] & 127 ) << 24 ) |
                ( hash[offset + 1] << 16 ) |
                ( hash[offset + 2] << 8 ) |
                hash[offset + 3];
            return String( number % 1000000 ).padStart( 6, '0' );
        },
        formatCode( code ) {
            return code && code.length === 6 ? `${code.slice( 0, 3 )}${code.slice( 3 )}` : '------';
        },
        maskSecret( secret ) {
            const value = secret.toUpperCase().replace( /[\s\-=]/g, '' );
            if ( value.length <= 6 ) { return `F2A ${value}`; }
            return `F2A ${value.slice( 0, 3 )}***${value.slice( -3 )}`;
        },
        async copyCode( account ) {
            if ( account.invalid || !account.code ) { return; }
            try {
                await window.navigator.clipboard.writeText( account.code );
            }catch ( error ) {
                const input = document.createElement( 'textarea' );
                input.value = account.code;
                input.style.position = 'fixed';
                input.style.opacity = '0';
                document.body.appendChild( input );
                input.select();
                document.execCommand( 'copy' );
                input.remove();
            }
            this.copied = `${account.category}:${account.name}`;
            window.setTimeout( () => this.copied = '', 1500 );
        },
    }"
    x-init="start()"
>
    {{-- 安全控制台概览 --}}
    <header class="manage-f2a-console">
        <div class="manage-f2a-console-main">
            <span class="manage-f2a-console-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M9 12.75 11.25 15 15 9.75m5.25 2.25c0 5.25-3.438 8.438-8.25 9.75C7.188 20.438 3.75 17.25 3.75 12V5.858c0-.519.337-.978.833-1.132l6.75-2.077a2.25 2.25 0 0 1 1.334 0l6.75 2.077c.496.154.833.613.833 1.132V12Z" />
                </svg>
            </span>
            <div>
                <div class="manage-f2a-console-status"><i></i><span>AUTHENTICATOR ONLINE</span></div>
                <h2>动态安全令牌</h2>
                <p><strong x-text="accounts.length">0</strong> 个密钥 · <strong x-text="categories.length - 1">0</strong> 个分类</p>
            </div>
        </div>
        <div class="manage-f2a-countdown">
            <div><strong x-text="remaining">30</strong><small>SEC</small></div>
            <span>下次轮换</span>
        </div>
        <div class="manage-f2a-progress"><i x-bind:style="`width: ${progress}%`"></i></div>
    </header>

    {{-- 分类切换与当前分类搜索 --}}
    <div class="manage-f2a-controls">
    <nav class="manage-f2a-categories" x-show="categories.length > 1" aria-label="验证码分类">
        <template x-for="category in categories" x-bind:key="category">
            <button
                type="button"
                x-bind:data-active="activeCategory === category"
                x-on:click="activeCategory = category"
            >
                <i></i>
                <span x-text="category"></span>
                <small x-text="category === '全部' ? accounts.length : accounts.filter( ( account ) => account.category === category ).length"></small>
            </button>
        </template>
    </nav>
        <label class="manage-f2a-search">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m21 21-4.35-4.35m1.35-5.4a6.75 6.75 0 1 1-13.5 0 6.75 6.75 0 0 1 13.5 0Z" />
            </svg>
            <input
                type="search"
                x-model.debounce.180ms="searchQuery"
                placeholder="搜索备注或密钥"
                autocomplete="off"
                aria-label="搜索当前分类的备注或密钥"
            >
            <button type="button" x-cloak x-show="searchQuery !== ''" x-on:click="searchQuery = ''" aria-label="清空搜索">×</button>
        </label>
    </div>

    <div class="manage-f2a-list" x-show="accounts.length > 0">
        <template x-for="account in filteredAccounts" x-bind:key="`${account.category}:${account.name}`">
            <article
                class="manage-f2a-account"
                x-bind:data-invalid="account.invalid"
                x-bind:tabindex="account.invalid ? -1 : 0"
                x-bind:aria-disabled="account.invalid"
                x-on:click="copyCode( account )"
                x-on:keydown.enter.prevent="copyCode( account )"
                x-on:keydown.space.prevent="copyCode( account )"
                role="button"
            >
                <header>
                    <span class="manage-f2a-category"><i></i><span x-text="account.category"></span></span>
                    <span class="manage-f2a-secret" x-text="maskSecret( account.secret )"></span>
                </header>
                <div class="manage-f2a-account-body">
                    <div class="manage-f2a-account-info">
                        <h3 x-text="account.name"></h3>
                        <p x-text="account.invalid ? '密钥格式无效' : 'Authenticator'"></p>
                    </div>
                    <div
                        class="manage-f2a-code"
                    >
                        <span x-text="formatCode( account.code )">------</span>
                        <small x-text="copied === `${account.category}:${account.name}` ? 'COPIED' : 'COPY'"></small>
                    </div>
                </div>
            </article>
        </template>
    </div>

    <div class="manage-f2a-empty" x-show="accounts.length === 0">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" d="M16.5 10.5V6.75a4.5 4.5 0 0 0-9 0v3.75m-.75 10.125h10.5A2.625 2.625 0 0 0 19.875 18V11.625A2.625 2.625 0 0 0 17.25 9h-10.5a2.625 2.625 0 0 0-2.625 2.625V18a2.625 2.625 0 0 0 2.625 2.625Z" />
        </svg>
        <h3>还没有配置账号</h3>
        <p>请在插件 config.php 的 f2a 数组中添加“分类 => [备注 => 密钥]”。</p>
    </div>

    <div class="manage-f2a-empty manage-f2a-search-empty" x-cloak x-show="accounts.length > 0 && filteredAccounts.length === 0">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" d="m21 21-4.35-4.35m1.35-5.4a6.75 6.75 0 1 1-13.5 0 6.75 6.75 0 0 1 13.5 0Z" />
        </svg>
        <h3>当前分类没有匹配项</h3>
        <p>可尝试输入备注中的部分文字或密钥片段。</p>
    </div>
</div>

<style>
    /* F2A 验证码管理页面 */
    .manage-f2a { display: flex; width: 100%; flex-direction: column; gap: 1rem; color: var(--gray-800); }
    .dark .manage-f2a { color: var(--gray-200); }
    .manage-f2a-header {
        display: flex;
        padding: 1.25rem;
        border: 1px solid color-mix(in srgb, var(--primary-500) 22%, transparent);
        border-radius: 1rem;
        background: linear-gradient(135deg, color-mix(in srgb, var(--primary-500) 12%, transparent), color-mix(in srgb, var(--primary-400) 3%, transparent));
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }
    .manage-f2a-label { color: var(--primary-600); font-size: 0.68rem; font-weight: 700; letter-spacing: 0.09em; }
    .manage-f2a-header h2 { margin-top: 0.2rem; color: var(--gray-950); font-size: 1.2rem; font-weight: 700; }
    .dark .manage-f2a-header h2 { color: white; }
    .manage-f2a-header p { margin-top: 0.3rem; color: var(--gray-600); font-size: 0.8rem; }
    .dark .manage-f2a-header p { color: var(--gray-400); }
    .manage-f2a-timer {
        display: flex;
        width: 3.6rem;
        height: 3.6rem;
        flex: 0 0 auto;
        border-radius: 50%;
        background: conic-gradient(var(--primary-500) var(--progress), color-mix(in srgb, var(--gray-400) 20%, transparent) 0);
        box-shadow: inset 0 0 0 0.32rem color-mix(in srgb, white 94%, transparent);
        align-items: baseline;
        justify-content: center;
        flex-direction: row;
        padding-top: 1rem;
    }
    .dark .manage-f2a-timer { box-shadow: inset 0 0 0 0.32rem var(--gray-900); }
    .manage-f2a-timer strong { font-size: 1rem; font-weight: 750; }
    .manage-f2a-timer span { margin-left: 0.1rem; color: var(--gray-500); font-size: 0.58rem; }
    /* 分类切换栏 */
    .manage-f2a-categories {
        display: flex;
        overflow-x: auto;
        padding: 0.3rem;
        border: 1px solid var(--gray-200);
        border-radius: 0.75rem;
        background: var(--gray-50);
        gap: 0.35rem;
        scrollbar-width: thin;
    }
    .dark .manage-f2a-categories { border-color: var(--gray-700); background: var(--gray-900); }
    .manage-f2a-categories button {
        display: inline-flex;
        min-height: 2rem;
        padding: 0.35rem 0.7rem;
        border: 0;
        border-radius: 0.5rem;
        background: transparent;
        color: var(--gray-600);
        align-items: center;
        gap: 0.4rem;
        font-size: 0.72rem;
        font-weight: 650;
        white-space: nowrap;
        cursor: pointer;
    }
    .dark .manage-f2a-categories button { color: var(--gray-300); }
    .manage-f2a-categories button[data-active="true"] { background: var(--primary-600); color: white; box-shadow: 0 1px 2px color-mix(in srgb, var(--primary-900) 20%, transparent); }
    .manage-f2a-categories button small { display: inline-flex; min-width: 1.15rem; height: 1.15rem; padding: 0 0.3rem; border-radius: 999px; background: color-mix(in srgb, currentColor 11%, transparent); align-items: center; justify-content: center; font-size: 0.58rem; }
    .manage-f2a-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.75rem; }
    .manage-f2a-account {
        display: flex;
        min-width: 0;
        padding: 1rem;
        border: 1px solid var(--gray-200);
        border-radius: 0.85rem;
        background: white;
        align-items: center;
        justify-content: space-between;
        gap: 0.85rem;
    }
    .dark .manage-f2a-account { border-color: var(--gray-700); background: var(--gray-900); }
    .manage-f2a-account[data-invalid="true"] { border-color: color-mix(in srgb, var(--danger-500) 45%, transparent); }
    .manage-f2a-account-info { display: flex; min-width: 0; align-items: center; gap: 0.7rem; }
    .manage-f2a-account-icon { display: flex; width: 2.25rem; height: 2.25rem; flex: 0 0 auto; border-radius: 0.65rem; background: color-mix(in srgb, var(--primary-500) 13%, transparent); color: var(--primary-600); align-items: center; justify-content: center; }
    .manage-f2a-account-icon svg { width: 1.2rem; height: 1.2rem; }
    .manage-f2a-account-info > div { min-width: 0; }
    .manage-f2a-account h3 { overflow: hidden; color: var(--gray-900); font-size: 0.84rem; font-weight: 650; text-overflow: ellipsis; white-space: nowrap; }
    .dark .manage-f2a-account h3 { color: white; }
    .manage-f2a-account p { margin-top: 0.15rem; color: var(--gray-500); font-size: 0.68rem; }
    .manage-f2a-code { display: flex; flex: 0 0 auto; border: 0; background: transparent; color: var(--primary-600); flex-direction: column; align-items: flex-end; cursor: pointer; }
    .manage-f2a-code span { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 1.25rem; font-weight: 750; letter-spacing: 0.045em; }
    .manage-f2a-code small { margin-top: 0.1rem; color: var(--gray-400); font-size: 0.58rem; }
    .manage-f2a-code:disabled { color: var(--danger-500); cursor: not-allowed; }
    .manage-f2a-empty { display: flex; padding: 2.5rem 1rem; border: 1px dashed var(--gray-300); border-radius: 0.85rem; color: var(--gray-500); align-items: center; flex-direction: column; text-align: center; }
    .dark .manage-f2a-empty { border-color: var(--gray-700); }
    .manage-f2a-empty svg { width: 2rem; height: 2rem; margin-bottom: 0.65rem; color: var(--gray-400); }
    .manage-f2a-empty h3 { color: var(--gray-700); font-size: 0.88rem; font-weight: 650; }
    .dark .manage-f2a-empty h3 { color: var(--gray-300); }
    .manage-f2a-empty p { margin-top: 0.3rem; font-size: 0.72rem; }
    @media (max-width: 700px) {
        .manage-f2a-list { grid-template-columns: 1fr; }
        .manage-f2a-header { padding: 1rem; }
    }
    @media (max-width: 420px) {
        .manage-f2a-account { align-items: flex-start; flex-direction: column; }
        .manage-f2a-code { width: 100%; flex-direction: row; align-items: center; justify-content: flex-start; gap: 0.45rem; }
        .manage-f2a-code small { margin-top: 0; white-space: nowrap; }
    }

    /* 科技安全控制台主题 */
    .manage-f2a { gap: 0.75rem; }
    .manage-f2a-console {
        display: grid;
        overflow: hidden;
        padding: 1rem 1.1rem 0.85rem;
        border: 1px solid color-mix(in srgb, var(--primary-500) 28%, var(--gray-200));
        border-radius: 0.9rem;
        background:
            linear-gradient(90deg, color-mix(in srgb, var(--primary-500) 5%, transparent) 1px, transparent 1px),
            linear-gradient(color-mix(in srgb, var(--primary-500) 5%, transparent) 1px, transparent 1px),
            linear-gradient(135deg, color-mix(in srgb, var(--primary-500) 9%, white), white);
        background-size: 24px 24px, 24px 24px, auto;
        grid-template-columns: 1fr auto;
        position: relative;
        gap: 1rem;
    }
    .dark .manage-f2a-console {
        border-color: color-mix(in srgb, var(--primary-500) 35%, var(--gray-700));
        background:
            linear-gradient(90deg, color-mix(in srgb, var(--primary-500) 8%, transparent) 1px, transparent 1px),
            linear-gradient(color-mix(in srgb, var(--primary-500) 8%, transparent) 1px, transparent 1px),
            linear-gradient(135deg, color-mix(in srgb, var(--primary-500) 10%, var(--gray-950)), var(--gray-950));
        background-size: 24px 24px, 24px 24px, auto;
    }
    .manage-f2a-console-main { display: flex; min-width: 0; align-items: center; gap: 0.8rem; }
    .manage-f2a-console-icon { display: flex; width: 2.7rem; height: 2.7rem; flex: 0 0 auto; border: 1px solid color-mix(in srgb, var(--primary-500) 30%, transparent); border-radius: 0.7rem; background: color-mix(in srgb, var(--primary-500) 12%, transparent); color: var(--primary-600); align-items: center; justify-content: center; }
    .manage-f2a-console-icon svg { width: 1.45rem; height: 1.45rem; }
    .manage-f2a-console-status { display: flex; color: var(--success-600); align-items: center; gap: 0.35rem; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.58rem; font-weight: 700; letter-spacing: 0.09em; }
    .manage-f2a-console-status i { width: 0.38rem; height: 0.38rem; border-radius: 50%; background: var(--success-500); box-shadow: 0 0 0 0.2rem color-mix(in srgb, var(--success-500) 14%, transparent), 0 0 0.7rem var(--success-500); }
    .manage-f2a-console h2 { margin-top: 0.12rem; color: var(--gray-950); font-size: 1rem; font-weight: 750; }
    .dark .manage-f2a-console h2 { color: white; }
    .manage-f2a-console-main p { margin-top: 0.12rem; color: var(--gray-500); font-size: 0.66rem; }
    .manage-f2a-console-main p strong { color: var(--gray-700); font-weight: 700; }
    .dark .manage-f2a-console-main p strong { color: var(--gray-300); }
    .manage-f2a-countdown { display: flex; min-width: 4rem; align-items: flex-end; justify-content: center; flex-direction: column; }
    .manage-f2a-countdown > div { display: flex; color: var(--primary-600); align-items: baseline; gap: 0.18rem; }
    .manage-f2a-countdown strong { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 1.65rem; font-weight: 800; line-height: 1; }
    .manage-f2a-countdown small { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.52rem; font-weight: 700; }
    .manage-f2a-countdown > span { margin-top: 0.2rem; color: var(--gray-500); font-size: 0.58rem; }
    .manage-f2a-progress { overflow: hidden; height: 0.18rem; border-radius: 999px; background: color-mix(in srgb, var(--gray-500) 13%, transparent); grid-column: 1 / -1; }
    .manage-f2a-progress i { display: block; height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--primary-400), var(--primary-600)); box-shadow: 0 0 0.6rem var(--primary-500); transition: width 0.3s linear; }
    .manage-f2a-controls { display: flex; min-width: 0; align-items: stretch; gap: 0.55rem; }
    .manage-f2a-categories { padding: 0.25rem; border-radius: 0.7rem; background: color-mix(in srgb, var(--gray-100) 75%, transparent); gap: 0.25rem; scrollbar-width: none; }
    .manage-f2a-categories::-webkit-scrollbar { display: none; }
    .manage-f2a-controls .manage-f2a-categories { min-width: 0; flex: 1; }
    .manage-f2a-categories button { min-height: 1.9rem; padding: 0.3rem 0.62rem; border: 1px solid transparent; border-radius: 0.45rem; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.66rem; }
    .manage-f2a-categories button > i { width: 0.32rem; height: 0.32rem; border-radius: 50%; background: var(--gray-400); }
    .manage-f2a-categories button[data-active="true"] { border-color: color-mix(in srgb, var(--primary-400) 55%, transparent); background: color-mix(in srgb, var(--primary-500) 12%, transparent); color: var(--primary-700); box-shadow: none; }
    .dark .manage-f2a-categories button[data-active="true"] { color: var(--primary-300); }
    .manage-f2a-categories button[data-active="true"] > i { background: var(--primary-500); box-shadow: 0 0 0.4rem var(--primary-500); }
    .manage-f2a-search { display: flex; width: 13rem; min-width: 10rem; padding: 0 0.55rem; border: 1px solid var(--gray-200); border-radius: 0.7rem; background: white; color: var(--gray-400); align-items: center; gap: 0.4rem; }
    .dark .manage-f2a-search { border-color: var(--gray-700); background: var(--gray-900); }
    .manage-f2a-search:focus-within { border-color: color-mix(in srgb, var(--primary-500) 65%, transparent); box-shadow: 0 0 0 0.18rem color-mix(in srgb, var(--primary-500) 10%, transparent); color: var(--primary-500); }
    .manage-f2a-search svg { width: 0.9rem; height: 0.9rem; flex: 0 0 auto; }
    .manage-f2a-search input { width: 100%; min-width: 0; padding: 0.42rem 0; border: 0; outline: 0; background: transparent; color: var(--gray-800); font-size: 0.68rem; }
    .dark .manage-f2a-search input { color: var(--gray-200); }
    .manage-f2a-search input::placeholder { color: var(--gray-400); }
    .manage-f2a-search input::-webkit-search-cancel-button { display: none; }
    .manage-f2a-search button { display: flex; width: 1.15rem; height: 1.15rem; flex: 0 0 auto; border: 0; border-radius: 50%; background: var(--gray-100); color: var(--gray-500); align-items: center; justify-content: center; font-size: 0.8rem; cursor: pointer; }
    .dark .manage-f2a-search button { background: var(--gray-800); color: var(--gray-300); }
    .manage-f2a-list { gap: 0.55rem; }
    .manage-f2a-account { display: block; overflow: hidden; padding: 0; border-color: color-mix(in srgb, var(--gray-300) 72%, transparent); border-radius: 0.7rem; background: linear-gradient(135deg, white, color-mix(in srgb, var(--primary-500) 2.5%, white)); cursor: pointer; transition: border-color 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease; }
    .manage-f2a-account:hover { border-color: color-mix(in srgb, var(--primary-500) 48%, transparent); box-shadow: 0 0.45rem 1rem color-mix(in srgb, var(--primary-900) 7%, transparent); transform: translateY(-1px); }
    .manage-f2a-account:focus-visible { border-color: var(--primary-500); outline: 0; box-shadow: 0 0 0 0.2rem color-mix(in srgb, var(--primary-500) 16%, transparent); }
    .manage-f2a-account[data-invalid="true"],
    .manage-f2a-account[data-invalid="true"]:hover,
    .manage-f2a-account[data-invalid="true"]:focus-visible {
        border-color: color-mix(in srgb, var(--danger-500) 68%, transparent);
        outline: 0;
        box-shadow: 0 0 0 0.16rem color-mix(in srgb, var(--danger-500) 10%, transparent);
        cursor: not-allowed;
        transform: none;
    }
    .manage-f2a-account[data-invalid="true"] .manage-f2a-category > i { background: var(--danger-500); box-shadow: 0 0 0.35rem var(--danger-500); }
    .manage-f2a-account[data-invalid="true"] .manage-f2a-code span { color: var(--danger-500); }
    .manage-f2a-account[data-invalid="true"] .manage-f2a-code small { border-color: color-mix(in srgb, var(--danger-500) 35%, transparent); color: var(--danger-600); }
    .dark .manage-f2a-account { border-color: var(--gray-700); background: linear-gradient(135deg, var(--gray-900), color-mix(in srgb, var(--primary-500) 5%, var(--gray-900))); }
    .dark .manage-f2a-account[data-invalid="true"] { border-color: color-mix(in srgb, var(--danger-500) 72%, transparent); }
    .manage-f2a-account > header { display: flex; min-width: 0; padding: 0.45rem 0.65rem; border-bottom: 1px solid color-mix(in srgb, var(--gray-300) 45%, transparent); background: color-mix(in srgb, var(--gray-100) 55%, transparent); align-items: center; justify-content: space-between; gap: 0.5rem; }
    .dark .manage-f2a-account > header { border-color: var(--gray-800); background: color-mix(in srgb, var(--gray-800) 65%, transparent); }
    .manage-f2a-category { display: flex; overflow: hidden; min-width: 0; color: var(--gray-600); align-items: center; gap: 0.35rem; font-size: 0.62rem; font-weight: 700; }
    .manage-f2a-category > i { width: 0.32rem; height: 0.32rem; flex: 0 0 auto; border-radius: 50%; background: var(--primary-500); box-shadow: 0 0 0.35rem var(--primary-500); }
    .manage-f2a-category > span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .manage-f2a-secret { flex: 0 0 auto; color: var(--gray-400); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.56rem; font-weight: 650; letter-spacing: 0.035em; }
    .manage-f2a-account-body { display: flex; min-width: 0; padding: 0.7rem 0.75rem; align-items: center; justify-content: space-between; gap: 0.65rem; }
    .manage-f2a-account-info { display: block; min-width: 0; }
    .manage-f2a-account h3 { font-size: 0.78rem; font-weight: 700; }
    .manage-f2a-account p { margin-top: 0.12rem; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.56rem; letter-spacing: 0.02em; }
    .manage-f2a-code { flex-direction: row; align-items: center; gap: 0.45rem; }
    .manage-f2a-code span { font-size: 1.18rem; font-weight: 800; letter-spacing: 0.08em; line-height: 1; }
    .manage-f2a-code small { min-width: 2.7rem; margin-top: 0; padding: 0.18rem 0.3rem; border: 1px solid color-mix(in srgb, var(--primary-500) 22%, transparent); border-radius: 0.3rem; color: var(--primary-600); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.48rem; font-weight: 700; text-align: center; }
    .manage-f2a-empty { padding: 2rem 1rem; }
    .manage-f2a-search-empty { padding: 1.5rem 1rem; }
    @media (max-width: 700px) {
        .manage-f2a { gap: 0.6rem; }
        .manage-f2a-console { padding: 0.8rem 0.85rem 0.7rem; }
        .manage-f2a-console-icon { width: 2.35rem; height: 2.35rem; }
        .manage-f2a-account { align-items: initial; flex-direction: initial; }
        .manage-f2a-account-body { padding: 0.7rem; }
        .manage-f2a-code { width: auto; flex-direction: row; align-items: center; justify-content: flex-end; }
        .manage-f2a-categories { scrollbar-width: none; }
        .manage-f2a-categories::-webkit-scrollbar { display: none; }
        .manage-f2a-controls { flex-direction: column; }
        .manage-f2a-search { width: 100%; min-height: 2.25rem; }
    }
    @media (max-width: 420px) {
        .manage-f2a-console-status span { font-size: 0.52rem; }
        .manage-f2a-console h2 { font-size: 0.88rem; }
        .manage-f2a-console-main p { font-size: 0.58rem; }
        .manage-f2a-countdown strong { font-size: 1.4rem; }
        .manage-f2a-account-body { align-items: flex-end; }
        .manage-f2a-code span { font-size: 1.05rem; }
        .manage-f2a-code small { min-width: auto; }
    }
</style>
